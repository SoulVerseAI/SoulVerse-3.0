import React from 'react';
import { Soul, RoleplayStyle } from '../../types';
import { CheckIcon } from '../icons/Icons';

const styleOptions: {id: RoleplayStyle, name: string, description: string}[] = [
  { id: 'Default', name: 'Default Style', description: 'The standard SoulVerse roleplay format with narration and character tags.' },
  { id: 'Script', name: 'Script Style', description: 'Character names followed by dialogue. Actions are in parentheses. Ex: "Character: (Sighs) Hello."' },
  { id: 'Novel', name: 'Novel Style', description: 'Descriptive, third-person prose. Dialogue is in quotation marks. Ex: \'He sighed. "Hello."\'' },
  { id: 'Star', name: 'Star Style (*)', description: 'Actions and emotes are surrounded by asterisks. Ex: "*waves* Hello there!"' },
  { id: 'Short', name: 'Short / Chat Style', description: 'Brief, concise sentences, similar to a chat room. Ex: "*walks away*"'},
];

interface StyleSelectorPanelProps {
    activeSoul: Soul | null;
    onUpdateSoul: (updates: Partial<Soul>) => void;
}

export const StyleSelectorPanel: React.FC<StyleSelectorPanelProps> = ({ activeSoul, onUpdateSoul }) => {
    if (!activeSoul) return <div className="p-4 text-center text-neutral-400">No Soul selected.</div>;

    const currentStyle = activeSoul.roleplayStyle || 'Default';

    const handleSelectStyle = (styleId: RoleplayStyle) => {
        onUpdateSoul({ roleplayStyle: styleId });
    };

    return (
        <div className="p-2 md:p-4 space-y-2">
            {styleOptions.map((style) => {
                const isSelected = style.id === currentStyle;
                return (
                    <button
                        key={style.id}
                        onClick={() => handleSelectStyle(style.id)}
                        role="option"
                        aria-selected={isSelected}
                        className={`w-full text-left p-3 transition-colors rounded-lg flex items-start
                            ${isSelected ? 'bg-neutral-700' : 'hover:bg-neutral-700/60 text-white'}
                        `}
                    >
                        <div className="flex-1">
                            <div className="flex items-center justify-between">
                                <span className="font-semibold text-white">{style.name}</span>
                                {isSelected && <CheckIcon className="w-5 h-5 text-blue-400 flex-shrink-0" />}
                            </div>
                            <p className="text-xs text-neutral-400 mt-1">{style.description}</p>
                        </div>
                    </button>
                );
            })}
        </div>
    );
};
