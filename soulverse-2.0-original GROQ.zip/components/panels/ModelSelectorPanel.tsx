import React, { useState, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { Soul, AccountSettings, SubscriptionTier } from '../../types';
import { CheckIcon, ChevronDownIcon } from '../icons/Icons';

export type ModelTier = 'Free' | 'Premium' | 'Ultra' | 'Max' | 'Admin' | 'System';

export interface ModelOption {
  id: string;
  name: string;
  shortName?: string;
  description: string;
  modelString: string;
  enableThinking: boolean;
  requiredTier: ModelTier;
  isSelectable: boolean;
  dynamism?: number;
}

// =======================
// MODELE
// =======================

export const modelOptions: ModelOption[] = [
  // --- TIER 0: SYSTEM (Niewidoczny dla użytkownika) ---
  {
    id: 'lite-legacy',
    name: 'VLM LITE LEGACY',
    description: 'Internal system model.',
    modelString: 'gemini-flash-lite-latest',
    enableThinking: false,
    requiredTier: 'System',
    isSelectable: false,
  },

  // --- TIER 1: FREE ---
  {
    id: 'lite-free',
    name: 'VLM LITE',
    shortName: 'LITE',
    description: 'A quick and responsive mind for standard conversations. A great starting point.',
    modelString: 'gemini-flash-lite-latest',
    enableThinking: false,
    requiredTier: 'Free',
    isSelectable: true,
  },
  {
    id: "vlm-groq",
    name: "VLM GROQ",
    shortName: "GROQ",
    description: "External Llama 3.3 70B model running on Groq API.",
    modelString: "llama-3.3-70b",
    enableThinking: false,
    requiredTier: "Free",
    isSelectable: true,
    dynamism: 0.8,
  },
  
  // --- TIER 2: PREMIUM ---
  {
    id: 'v2-char',
    name: 'VLM 2.0 (Character)',
    description: 'A consistent and reliable mind for playing a single character with emotional depth.',
    modelString: 'gemini-2.5-flash',
    enableThinking: false,
    requiredTier: 'Premium',
    isSelectable: true,
  },
  {
    id: 'v2-narrator',
    name: 'VLM 2.0 (Narrator)',
    description: 'A balanced storyteller for managing simple scenes and a few NPCs with clarity.',
    modelString: 'gemini-2.5-flash',
    enableThinking: true,
    requiredTier: 'Premium',
    isSelectable: true,
  },
  {
    id: 'v2.5-rpg',
    name: 'VLM 2.5 (RPG)',
    description: 'An imaginative Game Master for managing complex scenes, multiple plots, and several NPCs.',
    modelString: 'gemini-2.0-flash',
    enableThinking:  false,
    requiredTier: 'Premium',
    isSelectable: true,
  },

  // --- TIER 3: ULTRA ---
  {
    id: 'v3-char',
    name: 'VLM 3.0 (Character)',
    description: 'An advanced mind for a single NPC, powered by a superior model for unparalleled nuance in dialogue.',
    modelString: 'gemini-flash-latest',
    enableThinking: false,
    requiredTier: 'Ultra',
    isSelectable: true,
  },
  {
    id: 'v3-narrator',
    name: 'VLM 3.0 (Narrator)',
    description: 'A masterful storyteller for weaving intricate plots, deep lore, and managing multiple complex NPCs.',
    modelString: 'gemini-flash-latest',
    enableThinking: true,
    requiredTier: 'Ultra',
    isSelectable: true,
  },
  {
    id: 'v3.5-rpg',
    name: 'VLM 3.5 (RPG)',
    description: 'A superior Game Master powered by a more advanced model, creating highly coherent and tactical worlds.',
    modelString: 'gemini-flash-latest',
    enableThinking: true,
    requiredTier: 'Ultra',
    isSelectable: true,
  },

  // --- TIER 4: MAX ---
  {
    id: 'max-char',
    name: 'VLM MAX (Character)',
    description: 'The pinnacle of single-character roleplay. Unparalleled depth, memory, and emotional realism.',
    modelString: 'gemini-2.5-pro', 
    enableThinking: false, 
    requiredTier: 'Max',
    isSelectable: true,
    dynamism: 0.9,
  },
  {
    id: 'max-narrator',
    name: 'VLM MAX (Narrator)',
    description: 'A world-class narrator for managing epic scenes with multiple complex characters and plotlines.',
    modelString: 'gemini-3-flash-preview',
    enableThinking: true,
    requiredTier: 'Max',
    isSelectable: true,
    dynamism: 1.0,
  },
  {
    id: 'max-rpg',
    name: 'VLM MAX (RPG)',
    description: 'The ultimate creative Game Master. Creates deep, reactive worlds and truly epic, unpredictable plots.',
    modelString: 'gemini-2.5-flash-lite-preview-09-2025',
    enableThinking: true,
    requiredTier: 'Max',
    isSelectable: true,
    dynamism: 0.7,
  },
    
  // --- ADMIN ONLY ---
  {
    id: 'admin-experimental',
    name: 'VLM ADMIN',
    description: 'Admin-only access to the most powerful and unconstrained model for testing purposes.',
    modelString: 'gemini-3.5-flash', 
    enableThinking: false,
    requiredTier: 'Admin',
    isSelectable: true,
  },
];

// =======================
// LOGIKA
// =======================

interface ModelSelectorPanelProps {
  activeSoul: Soul | null;
  onUpdateSoul: (updates: Partial<Soul>) => void;
  accountSettings: AccountSettings;
}

const subscriptionTierToLevel = (tier: SubscriptionTier): number => {
  switch (tier) {
    case 'Free': return 0;
    case 'Premium': return 1;
    case 'Ultra': return 2;
    case 'Max': return 3;
    default: return 0;
  }
};

const modelTierToLevel = (tier: ModelTier): number => {
  switch (tier) {
    case 'Free': return 0;
    case 'Premium': return 1;
    case 'Ultra': return 2;
    case 'Max': return 3;
    case 'Admin': return 99;
    case 'System': return 100;
    default: return 0;
  }
};

const getTierColor = (tier: ModelTier) => {
  switch (tier) {
    case 'Free': return 'text-neutral-400';
    case 'Premium': return 'text-blue-400';
    case 'Ultra': return 'text-purple-400';
    case 'Max': return 'text-yellow-400';
    case 'Admin': return 'text-red-400';
    default: return 'text-neutral-400';
  }
};

// =======================
// COMPONENT
// =======================

export const ModelSelectorPanel: React.FC<ModelSelectorPanelProps> = ({
  activeSoul,
  onUpdateSoul,
  accountSettings
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({});

  if (!activeSoul || !accountSettings) {
    return <div className="p-4 text-center text-neutral-400">No Soul selected.</div>;
  }

  const userLevel = accountSettings.adminMode
    ? 99
    : subscriptionTierToLevel(accountSettings.subscriptionTier);

  const availableModels = modelOptions.filter(
    model => model.isSelectable && modelTierToLevel(model.requiredTier) <= userLevel
  );

  // ✅ LEPSZE DOPASOWANIE MODELU
  const currentModelId = (() => {
    const soulModel = activeSoul.model || '';
    if (soulModel === 'llama-3.3-70b' || soulModel === 'vlm-groq') {
      return 'vlm-groq';
    }
    const soulThinking = activeSoul.enableThinking === true;
    const soulDynamism = activeSoul.dynamism ?? 0.8;

    // 1. Szukamy wszystkich modeli, które pasują do stringa modelu
    const matchingModels = modelOptions.filter(m => 
      m.isSelectable && m.modelString === soulModel
    );

    if (matchingModels.length === 0) return 'lite-free';

    // Znajdź najdłuższy pasujący string modelu (aby uniknąć dopasowania 'gemini-2.5-flash' do 'gemini-2.5-flash-lite')
    const maxLength = Math.max(...matchingModels.map(m => m.modelString.length));
    const bestStringMatches = matchingModels.filter(m => m.modelString.length === maxLength);

    if (bestStringMatches.length === 1) return bestStringMatches[0].id;

    // 2. Jeśli jest więcej dopasowań, dopasuj po enableThinking
    const exactMatch = bestStringMatches.filter(m => (m.enableThinking === true) === soulThinking);
    
    if (exactMatch.length === 0) return bestStringMatches[0].id;
    if (exactMatch.length === 1) return exactMatch[0].id;

    // 3. Jeśli nadal jest więcej dopasowań, dopasuj po dynamism
    return exactMatch.reduce((best, current) => {
      const bestDiff = Math.abs((best.dynamism ?? 0.8) - soulDynamism);
      const currentDiff = Math.abs((current.dynamism ?? 0.8) - soulDynamism);
      return currentDiff < bestDiff ? current : best;
    }).id;
  })();

  const selectedModel =
    modelOptions.find(m => m.id === currentModelId) ||
    modelOptions[0];

  const handleSelectModel = (model: ModelOption) => {
    onUpdateSoul({
      model: model.modelString,
      enableThinking: model.enableThinking,
      dynamism: model.dynamism ?? 0.8,
    });
    setIsDropdownOpen(false);
  };

  useEffect(() => {
    const updatePosition = () => {
      if (triggerRef.current) {
        const rect = triggerRef.current.getBoundingClientRect();
        setDropdownStyle({
          position: 'absolute',
          top: `${rect.bottom + 4}px`,
          left: `${rect.left}px`,
          width: `${rect.width}px`,
          zIndex: 200,
        });
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node) &&
        !triggerRef.current?.contains(e.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    };

    if (isDropdownOpen) {
      updatePosition();
      document.addEventListener('mousedown', handleClickOutside);
      window.addEventListener('resize', updatePosition);
      window.addEventListener('scroll', updatePosition, true);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
    };
  }, [isDropdownOpen]);

  const DropdownMenu = isDropdownOpen
    ? ReactDOM.createPortal(
        <div
          ref={dropdownRef}
          style={dropdownStyle}
          className="mt-2 bg-neutral-800 border border-neutral-700 rounded-lg shadow-xl max-h-80 overflow-y-auto"
          onMouseDown={(e) => e.nativeEvent.stopPropagation()}
        >
          {availableModels.map(model => {
            const isSelected = model.id === currentModelId;
            const tierColor = getTierColor(model.requiredTier);

            return (
              <button
                key={model.id}
                onMouseDown={() => handleSelectModel(model)}
                className={`w-full text-left p-3 flex justify-between hover:bg-neutral-700 ${
                  isSelected ? 'bg-neutral-700' : ''
                }`}
              >
                <div className="flex flex-col">
                  <span className="font-semibold text-white">{model.name}</span>
                  <span className={`text-xs ${tierColor}`}>
                    {model.requiredTier} Tier
                  </span>
                </div>

                {isSelected && <CheckIcon className="w-5 h-5 text-blue-400" />}
              </button>
            );
          })}
        </div>,
        document.body
      )
    : null;

  const selectedTierColor = getTierColor(selectedModel.requiredTier);

  return (
    <div className="p-4 space-y-4">
      <button
        ref={triggerRef}
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="w-full flex justify-between p-3 bg-neutral-900 border-2 border-blue-500 rounded-lg"
      >
        <span className={`${selectedTierColor} font-semibold`}>
          {selectedModel.name}
        </span>
        <ChevronDownIcon className="w-5 h-5 text-neutral-400" />
      </button>

      {DropdownMenu}

      <p className="text-sm text-neutral-400">{selectedModel.description}</p>
    </div>
  );
};