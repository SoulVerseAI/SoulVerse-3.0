
import React, { useMemo } from 'react';
import { AccountSettings, ChatMessage, Soul } from '../../types';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface FavoritesPanelProps {
    messages: ChatMessage[];
    accountSettings: AccountSettings;
    activeSoul: Soul | null;
    onGoToMessage: (messageId: string) => void;
}

const getFirstParagraph = (text: string) => {
    return text.split('\n\n')[0];
};

const formatTimestamp = (ts: string) => {
    if (!ts) return '';
    return new Date(ts).toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
    });
};

export const FavoritesPanel: React.FC<FavoritesPanelProps> = ({ messages, accountSettings, activeSoul, onGoToMessage }) => {
    const favoriteMessages = useMemo(() => {
        const favoriteIds = new Set(accountSettings.favoriteMessages || []);
        return messages
            .filter(m => favoriteIds.has(m.id))
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }, [messages, accountSettings.favoriteMessages]);

    return (
        <div className="p-2 md:p-4">
            {favoriteMessages.length > 0 ? (
                <div className="space-y-3 max-h-[70vh] overflow-y-auto">
                    {favoriteMessages.map(msg => (
                        <button 
                            key={msg.id}
                            onClick={() => onGoToMessage(msg.id)}
                            className="w-full text-left bg-neutral-800/50 p-3 md:p-4 rounded-lg hover:bg-neutral-700/60 transition-colors"
                        >
                            <div className="flex justify-between items-start mb-2">
                                <span className="font-bold text-base text-white">
                                    {msg.sender === 'ai' ? (activeSoul?.name || 'Soul') : accountSettings.userName}
                                </span>
                                <span className="text-xs text-neutral-500 flex-shrink-0 ml-4">
                                    {formatTimestamp(msg.timestamp)}
                                </span>
                            </div>
                             <div className="text-sm text-neutral-300 prose prose-sm prose-invert max-w-none prose-p:my-0 break-words line-clamp-3">
                                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                    {getFirstParagraph(msg.text)}
                                </ReactMarkdown>
                            </div>
                        </button>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 px-4">
                    <p className="text-sm text-neutral-400">
                        You haven't favorited any messages yet.
                    </p>
                    <p className="text-xs text-neutral-500 mt-1">Click on a message in the chat to reveal the heart icon.</p>
                </div>
            )}
        </div>
    );
};
