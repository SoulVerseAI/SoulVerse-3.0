// components/Multiplayer/botPrompt.ts

export const BOT_NAMES = ['SoulAssist', 'SoulAD'];

export const SOUL_ASSIST_COMMANDS: Record<string, string> = {
  '/info': `Available commands:
- /help: Get basic help and information.
- /formatting: Learn how to format your roleplay messages.
- /rp: Get tips for better roleplaying.`,
  '/help': 'SoulVerse is an interactive AI world. You can create and chat with unique characters. If you need more assistance, please join our Discord server.',
  '/formatting': `Use asterisks for actions, like *he smiled*. Dialogue does not need quotation marks. For example: *She looks at you and nods.* Hello there.`,
  '/rp': 'To have a better roleplay experience, try to be descriptive in your actions and dialogue. The more detail you provide, the more immersive the story will be.',
};

export const SOUL_AD_CONFIG = {
  message: "Join to our Discord Server https://discord.gg/wp7rcqQD",
  interval: 30 * 60 * 1000, // 30 minutes
};