import React, { useState, useEffect, useRef } from 'react';
import { BOT_NAMES } from './botPrompt';

export const OnlineUsersList: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    // Add "You" to the list for display
    const displayUsers = [...BOT_NAMES, "You"].sort();

    return (
        <div ref={dropdownRef} className="relative">
            <button 
                onClick={() => setIsOpen(prev => !prev)}
                className="px-4 py-1.5 bg-black/30 backdrop-blur-md rounded-full text-sm font-semibold text-white border border-white/10 hover:bg-white/20 transition-colors"
            >
                Online: {displayUsers.length}
            </button>
            {isOpen && (
                <div className="absolute top-full right-0 mt-2 w-48 bg-neutral-800/50 backdrop-blur-lg border border-neutral-600/50 rounded-lg shadow-2xl p-2 z-50">
                    <ul className="max-h-64 overflow-y-auto custom-scrollbar">
                        {displayUsers.map(user => (
                            <li key={user} className="px-2 py-1 text-neutral-300 text-sm">
                                {user}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};
