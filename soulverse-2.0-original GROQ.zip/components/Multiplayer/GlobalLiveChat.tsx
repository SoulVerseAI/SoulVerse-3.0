import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ResizerArrowsIcon, ChevronDownIcon } from '../icons/Icons';
import { SOUL_ASSIST_COMMANDS, SOUL_AD_CONFIG } from './botPrompt';

interface ChatMessage {
    user: string;
    text: string;
    timestamp: number;
}

const CHAT_WIDTH_PX = 390;

export const GlobalLiveChat: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [height, setHeight] = useState(180);
    const [isResizingHeight, setIsResizingHeight] = useState(false);
    const [isCommandPopupOpen, setIsCommandPopupOpen] = useState(false);
    const [isMinimized, setIsMinimized] = useState(false);

    const chatContainerRef = useRef<HTMLDivElement>(null);
    const commandPopupRef = useRef<HTMLDivElement>(null);
    const commandButtonRef = useRef<HTMLButtonElement>(null);
    const lastClientY = useRef(0);

    // Reklamy SoulAD
    useEffect(() => {
        const interval = setInterval(() => {
            setMessages(prev => [
                ...prev,
                { user: 'SoulAD', text: SOUL_AD_CONFIG.message, timestamp: Date.now() }
            ]);
        }, SOUL_AD_CONFIG.interval);
        return () => clearInterval(interval);
    }, []);

    // Auto scroll
    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [messages]);

    // Zamknij popup po kliknięciu poza
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                commandPopupRef.current &&
                !commandPopupRef.current.contains(event.target as Node) &&
                commandButtonRef.current &&
                !commandButtonRef.current.contains(event.target as Node)
            ) {
                setIsCommandPopupOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmed = input.trim();
        if (!trimmed) return;

        setMessages(prev => [
            ...prev,
            { user: 'You', text: trimmed, timestamp: Date.now() }
        ]);
        setInput('');

        if (trimmed.startsWith('/')) {
            const command = trimmed.split(' ')[0] as keyof typeof SOUL_ASSIST_COMMANDS;
            setTimeout(() => {
                const response =
                    SOUL_ASSIST_COMMANDS[command] ||
                    `Unknown command: "${command}". Type /info for a list of commands.`;
                setMessages(prev => [
                    ...prev,
                    { user: 'SoulAssist', text: response, timestamp: Date.now() }
                ]);
            }, 400);
        }
    };

    // Resizing
    const handleMouseDownHeight = useCallback((e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsResizingHeight(true);
        lastClientY.current = e.clientY;
    }, []);

    const handleMouseMoveHeight = useCallback((e: MouseEvent) => {
        const delta = lastClientY.current - e.clientY;
        lastClientY.current = e.clientY;
        setHeight(h => Math.max(150, Math.min(600, h + delta)));
    }, []);

    const handleMouseUpHeight = useCallback(() => {
        setIsResizingHeight(false);
    }, []);

    useEffect(() => {
        if (isResizingHeight) {
            document.addEventListener('mousemove', handleMouseMoveHeight);
            document.addEventListener('mouseup', handleMouseUpHeight);
        } else {
            document.removeEventListener('mousemove', handleMouseMoveHeight);
            document.removeEventListener('mouseup', handleMouseUpHeight);
        }
        return () => {
            document.removeEventListener('mousemove', handleMouseMoveHeight);
            document.removeEventListener('mouseup', handleMouseUpHeight);
        };
    }, [isResizingHeight, handleMouseMoveHeight, handleMouseUpHeight]);

    return (
        <div
            className="card-dark-glass fixed bottom-32 left-0 z-[150] flex flex-col shadow-2xl rounded-r-xl overflow-hidden transition-all duration-300"
            style={{
                height: isMinimized ? '48px' : `${height}px`,
                width: isMinimized ? '240px' : `${CHAT_WIDTH_PX}px`,
                minHeight: '48px'
            }}
        >
            <div className={`flex-shrink-0 px-3 py-2 bg-neutral-900/70 backdrop-blur-md flex items-center justify-between ${isMinimized ? 'cursor-pointer' : ''}`} onClick={isMinimized ? () => setIsMinimized(false) : undefined}>
                <h3 className="font-semibold text-white ml-1">Global Chat</h3>
                <div className="flex items-center">
                    {!isMinimized && (
                        <button
                            onMouseDown={handleMouseDownHeight}
                            className="cursor-ns-resize text-yellow-400/60 hover:text-yellow-400 p-1"
                            aria-label="Resize chat height"
                        >
                            <ResizerArrowsIcon className="w-5 h-5" />
                        </button>
                    )}
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            setIsMinimized(!isMinimized);
                        }}
                        className="p-1 text-neutral-300 hover:text-white"
                        aria-label={isMinimized ? "Expand chat" : "Minimize chat"}
                    >
                        {isMinimized ? <ChevronDownIcon className="w-5 h-5 transform rotate-180" /> : <ChevronDownIcon className="w-5 h-5" />}
                    </button>
                </div>
            </div>

            {!isMinimized && (
                <>
                    {/* Główna sekcja wiadomości */}
                    <div
                        ref={chatContainerRef}
                        className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar"
                    >
                        {messages.map((msg, i) => (
                            <div key={i} className="text-sm break-words">
                                <span
                                    className={`font-bold ${
                                        msg.user === 'You'
                                            ? 'text-cyan-400'
                                            : msg.user === 'SoulAssist'
                                            ? 'text-yellow-400'
                                            : msg.user === 'SoulAD'
                                            ? 'text-pink-400'
                                            : 'text-purple-400'
                                    }`}
                                >
                                    {msg.user}:
                                </span>
                                <span className="text-neutral-200 ml-1">{msg.text}</span>
                            </div>
                        ))}
                    </div>

                    {/* Input przyklejony do dołu */}
                    <form
                        onSubmit={handleSendMessage}
                        className="relative flex-shrink-0 p-2 flex items-center gap-2 bg-neutral-900/70 backdrop-blur-md"
                    >
                        {isCommandPopupOpen && (
                            <div
                                ref={commandPopupRef}
                                className="absolute bottom-full left-0 mb-2 w-full bg-neutral-900/90 border border-neutral-700 rounded-lg p-3 shadow-lg"
                            >
                                <h4 className="font-semibold text-white text-sm mb-2">Slash Commands</h4>
                                <div className="space-y-1 text-xs">
                                    {Object.entries(SOUL_ASSIST_COMMANDS).map(([command, desc]) => (
                                        <div key={command}>
                                            <span className="font-mono text-cyan-400">{command}</span>
                                            <span className="text-neutral-400 ml-2">
                                                {desc.split('\n')[0]}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        <button
                            ref={commandButtonRef}
                            type="button"
                            onClick={() => setIsCommandPopupOpen(p => !p)}
                            className="p-2 rounded-full hover:bg-neutral-700/60 transition-colors"
                            aria-label="Show commands"
                        >
                            <img
                                src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2Ficons%2Fcomment.png?alt=media&token=28148ebd-f85a-42f4-a759-59281876aed2"
                                alt="Commands"
                                className="w-5 h-5"
                            />
                        </button>

                        <input
                            type="text"
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            placeholder="Say something or type /info"
                            className="w-full bg-transparent border-none py-1.5 pl-2 pr-4 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none"
                        />
                    </form>
                </>
            )}
        </div>
    );
};
