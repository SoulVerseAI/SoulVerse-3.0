
// FIX: Import `React` to make types like `React.DragEvent` available.
import React, { useState, useCallback } from 'react';

export const useDragAndDrop = () => {
    const [draggedItem, setDraggedItem] = useState<any | null>(null);
    const [draggedItemType, setDraggedItemType] = useState<string | null>(null);
    const [draggedPosition, setDraggedPosition] = useState<{ x: number, y: number } | null>(null);

    const handleDragStart = useCallback((e: React.DragEvent<HTMLDivElement>, item: any, type: string) => {
        setDraggedItem(item);
        setDraggedItemType(type);
        setDraggedPosition({ x: e.clientX, y: e.clientY });

        // Hide default drag image
        const img = new Image();
        img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
        e.dataTransfer.setDragImage(img, 0, 0);
    }, []);

    const handleDrag = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        // Prevent update if position is 0,0 which happens on drag end in some browsers
        if (e.clientX === 0 && e.clientY === 0) return; 
        setDraggedPosition({ x: e.clientX, y: e.clientY });
    }, []);

    const handleDragEnd = useCallback(() => {
        setDraggedItem(null);
        setDraggedItemType(null);
        setDraggedPosition(null);
    }, []);

    return {
        draggedItem,
        draggedItemType,
        draggedPosition,
        isDragging: !!draggedItem,
        handleDragStart,
        handleDrag,
        handleDragEnd,
    };
};
