import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { createSelectorFunctions } from 'auto-zustand-selectors-hook';

interface World {
  id: string;
  name: string;
  description: string;
  color: string;
}

interface SoulVerseState {
  didInit: boolean;
  images: World[] | null; // Keep name `images` to reduce refactoring, but type is `World`
  layout: string;
  layouts: Record<string, Record<string, number[]>> | null;
  nodePositions: Record<string, number[]> | null;
  targetImage: string | null;
  isSidebarOpen: boolean;
}

const useStoreImpl = create<SoulVerseState>()(
  immer(() => ({
    didInit: false,
    images: null,
    layout: 'sphere',
    layouts: null,
    nodePositions: null,
    targetImage: null,
    isSidebarOpen: false,
  }))
);

const useStore = createSelectorFunctions(useStoreImpl);
export default useStore;
