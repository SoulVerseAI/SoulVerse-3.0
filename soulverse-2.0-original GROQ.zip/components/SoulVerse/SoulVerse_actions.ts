
import useStore from './SoulVerse_store';

const get = useStore.getState;
const set = useStore.setState;

export const init = async () => {
  if (get().didInit) {
    return;
  }

  // FIX: Switched to standard zustand setState syntax to resolve TypeScript error.
  set({ didInit: true });

  try {
    const [images, sphere] = await Promise.all(
      ['/public/SoulVerse_meta.json', '/public/SoulVerse_sphere.json'].map(
        path => fetch(path).then(res => {
          if (!res.ok) {
            throw new Error(`Failed to load ${path}: ${res.statusText}`);
          }
          return res.json();
        })
      )
    );

    // FIX: Switched to standard zustand setState syntax to resolve TypeScript error.
    set({
      images,
      layouts: {
        sphere,
      },
      nodePositions: Object.fromEntries(
        images.map(({id}: {id: string}) => [id, [0.5, 0.5, 0.5]])
      ),
    });

    setLayout('sphere');
  } catch (error) {
    console.error("Failed to initialize SoulVerse data:", error);
    // You could set an error state here to show a message to the user
  }
};

export const setLayout = (layout: string) =>
  // FIX: Switched to standard zustand setState syntax to resolve TypeScript error.
  set(state => {
    if (state.layouts && state.layouts[layout]) {
        return {
          layout: layout,
          nodePositions: state.layouts[layout],
        };
    }
    return {};
  });

export const setTargetImage = async (targetImage: string | null) => {
  if (targetImage === get().targetImage) {
    targetImage = null;
  }

  // FIX: Switched to standard zustand setState syntax to resolve TypeScript error.
  set({ targetImage: targetImage });
};

// FIX: Added missing setSidebarOpen action to control sidebar visibility.
export const setSidebarOpen = (isOpen: boolean) => set({ isSidebarOpen: isOpen });

init();
