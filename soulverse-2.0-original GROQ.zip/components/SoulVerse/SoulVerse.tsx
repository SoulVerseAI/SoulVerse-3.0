import React from 'react';
import PhotoViz from "./SoulVerse_PhotoViz";
import { XMarkIcon } from '../icons/Icons';

interface SoulVerseProps {
  onClose: () => void;
}

export const SoulVerse: React.FC<SoulVerseProps> = ({ onClose }) => {
  return (
    <main style={{
        width: '100%', 
        height: '100%', 
        position: 'relative', 
        overflow: 'hidden', 
        backgroundColor: 'black'
      }}>
      <video
        autoPlay
        loop
        muted
        playsInline
        src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/SoulVerse%20Function%2F0_Space_Stars_1080x1080%20(video-converter.com).webm?alt=media&token=49004527-df91-4429-a13c-91acaec46141"
        style={{
          position: 'absolute',
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          zIndex: 0
        }}
      />
      <div style={{position: 'relative', zIndex: 1, width: '100%', height: '100%'}}>
        <PhotoViz />
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-50 p-2 rounded-full bg-black/30 hover:bg-black/50 text-white"
          aria-label="Close SoulVerse"
          title="Close SoulVerse"
        >
          <XMarkIcon className="w-6 h-6" />
        </button>
      </div>
    </main>
  );
};