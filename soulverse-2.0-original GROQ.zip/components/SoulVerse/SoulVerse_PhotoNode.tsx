


import React, { useRef, useEffect, useLayoutEffect } from 'react';
import { Billboard, Text, useTexture } from "@react-three/drei";
// FIX: The `variants` prop was causing a TypeScript error.
// We are now passing animation values directly to `initial` and `animate` props to resolve the issue.
// Further FIX: `initial` and `animate` props are causing type errors. Switched to imperative animation with `useEffect`.
import { animate } from 'framer-motion';
import { motion } from "framer-motion-3d";
import { setTargetImage } from "./SoulVerse_actions";
import * as THREE from 'three';

const thumbHeight = 16;
const circleRadius = thumbHeight / 2;

// FIX: Creating geometry imperatively to work around JSX primitive type issue for 'circleGeometry'.
const circleGeom = new THREE.CircleGeometry(circleRadius, 32);

interface WorldNodeProps {
    id: string;
    name: string;
    color: string;
    x?: number;
    y?: number;
    z?: number;
    highlight: boolean;
    dim: boolean;
    visible: boolean;
}

// FIX: Refactored to a const with React.FC type to correctly handle React-specific props like 'key',
// which was causing a type error in SoulVerse_PhotoViz.tsx.
const WorldNode: React.FC<WorldNodeProps> = ({
  id,
  name,
  color,
  x = 0,
  y = 0,
  z = 0,
  highlight,
  dim,
  visible,
}) => {
  const texture = useTexture('https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/SoulVerse%20Function%2Fplanet.png?alt=media&token=3b32177d-4ef0-481d-8735-66a2e72b1719');
  const materialOpacity = highlight ? 1.0 : dim ? 0.2 : 0.8;
  const downPos = useRef(new THREE.Vector2());
  // FIX: Changed the type of groupRef to 'any' to resolve a complex type mismatch with framer-motion-3d,
  // consistent with the pattern in SoulVerse_PhotoViz.tsx.
  const groupRef = useRef<any>(null!);

  // Set initial state before first render to ensure animation starts correctly.
  useLayoutEffect(() => {
    if (groupRef.current) {
      groupRef.current.position.set(x * 500, y * 500, z * 500);
      groupRef.current.scale.setScalar(0.8);
    }
  }, []); // Empty dependency array ensures this runs only once on mount.

  // Animate to new position/scale when props change.
  useEffect(() => {
    if (groupRef.current) {
      const controls = [
        animate(groupRef.current.position.x, x * 600, { duration: 1, ease: "circInOut", onUpdate: v => { if(groupRef.current) groupRef.current.position.x = v } }),
        animate(groupRef.current.position.y, y * 600, { duration: 1, ease: "circInOut", onUpdate: v => { if(groupRef.current) groupRef.current.position.y = v } }),
        animate(groupRef.current.position.z, z * 600, { duration: 1, ease: "circInOut", onUpdate: v => { if(groupRef.current) groupRef.current.position.z = v } }),
        animate(groupRef.current.scale.x, 1, { duration: 1, ease: "circInOut", onUpdate: v => { if(groupRef.current) groupRef.current.scale.setScalar(v) } }),
      ];

      return () => controls.forEach(c => c.stop());
    }
  }, [x, y, z]);

  const handlePointerDown = (e: any) => {
    e.stopPropagation();
    downPos.current.set(e.clientX, e.clientY);
  };

  const handlePointerUp = (e: any) => {
    e.stopPropagation();
    const upPos = new THREE.Vector2(e.clientX, e.clientY);
    if (upPos.distanceTo(downPos.current) < 10) { // Click threshold
      setTargetImage(id);
    }
  };

  return (
    <motion.group
      ref={groupRef}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      visible={visible}
    >
      <Billboard>
        {/* FIX: Replaced the <circleGeometry> JSX primitive with a geometry prop on the mesh to resolve the type error. */}
        <motion.mesh geometry={circleGeom}>
            {/* FIX: The `transition` prop is not valid on `motion.meshStandardMaterial` according to the type definitions, causing an error. The animation of `opacity` will be handled by Framer Motion's default transition or one inherited from a parent motion component. */}
            <motion.meshStandardMaterial
                map={texture}
                transparent={true}
                side={THREE.DoubleSide}
                roughness={0.9}
                metalness={0.1}
                color={highlight ? '#ffffff' : color}
                emissive={highlight ? color : '#000000'}
                emissiveIntensity={highlight ? 0.8 : 0}
                opacity={materialOpacity}
            />
        </motion.mesh>

        <Text
            fontSize={2}
            color="white"
            anchorX="center"
            anchorY="middle"
            position-y={circleRadius + 3}
            position-z={0.1}
        >
            {name}
        </Text>
      </Billboard>
    </motion.group>
  );
}

export default WorldNode;