import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { ShareIcon, UserCircleIcon, XMarkIcon, EyeIcon, SparklesIcon, HeartIcon, PuzzlePieceIcon, UsersIcon, BookOpenIcon, StarIcon, SearchIcon, ExclamationTriangleIcon, ChatBubbleBottomCenterTextIcon, ClipboardIcon, CheckIcon } from '../icons/Icons';
import { Gender, Soul, Post, SharedSoul, SoulRole, AccountSettings, SubscriptionTier } from '../../types';
import { SoulTemplateModal } from '../ui/SoulTemplateModal';
import { Toggle } from '../ui/Toggle';
import { Modal } from '../ui/Modal';
import { SoulTemplate } from '../../types';

interface DiscoverPageProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCreateModal: () => void;
  onCreateFromTemplate: (template: SoulTemplate) => void;
  isMandatory?: boolean;
  accountSettings: AccountSettings;
  templates: SoulTemplate[];
}

const getTagColor = (tag: string) => {
    const hash = tag.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0);
    const colors = [
        'bg-sky-500', 'bg-fuchsia-500', 'bg-green-500', 'bg-amber-500',
        'bg-rose-500', 'bg-indigo-500', 'bg-teal-500', 'bg-cyan-500'
    ];
    return `${colors[Math.abs(hash) % colors.length]} text-white`;
};

const getQualityStyles = (template: SoulTemplate) => {
    // FIX: Property 'subscription' does not exist on type 'SoulTemplate'. Changed to 'quality' and logic to direct comparison.
    const quality = template.quality;
    if (quality === 'Eternal') {
        return {
            border: 'border-amber-400',
            shadow: 'hover:shadow-amber-400/20',
            bg: 'bg-amber-900/50',
            gradientFrom: 'from-amber-900/80',
        };
    }
    if (quality === 'Ascend') {
        return {
            border: 'border-purple-500',
            shadow: 'hover:shadow-purple-500/20',
            bg: 'bg-purple-900/50',
            gradientFrom: 'from-purple-900/80',
        };
    }
    if (quality === 'Spirit') {
        return {
            border: 'border-cyan-400',
            shadow: 'hover:shadow-cyan-400/20',
            bg: 'bg-cyan-900/50',
            gradientFrom: 'from-cyan-900/80',
        };
    }
    // Wisp
    return {
        border: 'border-neutral-500',
        shadow: 'hover:shadow-neutral-500/20',
        bg: 'bg-neutral-800/50',
        gradientFrom: 'from-black/80',
    };
};


const categories = [
    { name: 'All Souls', icon: <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fstarry-night.png?alt=media&token=55936088-8a74-42b2-86c7-033148f57c1a" className="w-5 h-5" /> },
    { name: 'Companions & Partners', icon: <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fconversation.png?alt=media&token=2cd83aeb-bd25-4a56-a799-3454880905ce" className="w-5 h-5" /> },
    { name: 'Interactive Adventures', icon: <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fbook.png?alt=media&token=7ab56ffa-dab7-4d61-99a2-08a5708d6396" className="w-5 h-5" /> },
    { name: 'RPG', icon: <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fdices.png?alt=media&token=722103c5-bc2d-4093-8ad9-e8f97f4cbdea" className="w-5 h-5" /> },
    { name: 'Assistants & Learning', icon: <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fonline-learning.png?alt=media&token=df5768d5-1c62-4203-8ba2-5dfa1f1ec412" className="w-5 h-5" /> },
];

const mapSharedSoulToTemplate = (sharedSoul: SharedSoul): SoulTemplate => ({
    name: sharedSoul.name,
    title: sharedSoul.tagline,
    longDescription: sharedSoul.backstory,
    gender: sharedSoul.gender,
    tags: ['Community'], 
    mainCategory: 'Companions & Partners', 
    backstory: sharedSoul.backstory,
    responseDirective: sharedSoul.responseDirective,
    keyMemories: sharedSoul.keyMemories,
    greeting: sharedSoul.greetingMessage,
    exampleMessage: sharedSoul.greetingMessage,
    bgImageUrls: sharedSoul.avatar ? [sharedSoul.avatar] : [],
    smallAvatarUrl: sharedSoul.avatar || '',
    dynamism: sharedSoul.dynamism,
    creatorName: sharedSoul.creatorName,
    shareCode: sharedSoul.shareCode,
    edition: "Community",
    label: "Shared",
});

const ShareSoulModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    template: SoulTemplate | null;
}> = ({ isOpen, onClose, template }) => {
    const [copiedCode, setCopiedCode] = useState(false);
    const [copiedLink, setCopiedLink] = useState(false);

    if (!isOpen || !template) return null;

    const shareCode = template.shareCode;
    const shareLink = `https://soulverse.app.link/share-code=${template.shareCode}`;

    const handleCopy = (text: string, type: 'code' | 'link') => {
        navigator.clipboard.writeText(text);
        if (type === 'code') {
            setCopiedCode(true);
            setTimeout(() => setCopiedCode(false), 2000);
        } else {
            setCopiedLink(true);
            setTimeout(() => setCopiedLink(false), 2000);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Share Soul" maxWidth="max-w-lg">
            <div className="p-6 space-y-4">
                <p className="text-sm text-center text-neutral-400">Share your Soul with the community!</p>
                <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">Share Code</label>
                    <div className="relative">
                        <input type="text" readOnly value={shareCode} className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-3 pr-10 focus:ring-2 focus:ring-blue-500 focus:outline-none"/>
                        <button onClick={() => handleCopy(shareCode, 'code')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full text-neutral-400 hover:bg-neutral-700 hover:text-white">
                            {copiedCode ? <CheckIcon className="w-5 h-5 text-green-400" /> : <ClipboardIcon className="w-5 h-5" />}
                        </button>
                    </div>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">Share Link</label>
                    <div className="relative">
                        <input type="text" readOnly value={shareLink} className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-3 pr-10 focus:ring-2 focus:ring-blue-500 focus:outline-none"/>
                        <button onClick={() => handleCopy(shareLink, 'link')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full text-neutral-400 hover:bg-neutral-700 hover:text-white">
                            {copiedLink ? <CheckIcon className="w-5 h-5 text-green-400" /> : <ClipboardIcon className="w-5 h-5" />}
                        </button>
                    </div>
                </div>
            </div>
        </Modal>
    );
};


const SoulCard: React.FC<{
    template: SoulTemplate;
    onCreate: (template: SoulTemplate) => void;
    onViewTemplate: (template: SoulTemplate) => void;
    onShare: (template: SoulTemplate) => void;
}> = ({ template, onCreate, onViewTemplate, onShare }) => {
    const [isHovering, setIsHovering] = useState(false);
    const videoRef = useRef<HTMLVideoElement>(null);
    const [mediaState, setMediaState] = useState({ type: 'image', index: 0 });
    const slideshowTimerRef = useRef<number | null>(null);
    const hoverTimeoutRef = useRef<number | null>(null);

    const qualityStyles = getQualityStyles(template);

    const hasVideo = !!template.bgVideoUrl;
    const hasImages = template.bgImageUrls && template.bgImageUrls.length > 0;
    const isSlideshowable = hasImages && (template.bgImageUrls.length > 1 || hasVideo);
    const imageDisplayDuration = 3000;

    const handleMouseEnter = () => {
        if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
        hoverTimeoutRef.current = window.setTimeout(() => {
            setIsHovering(true);
        }, 200);
    };

    const handleMouseLeave = () => {
        if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
        setIsHovering(false);
    };

    const stopSlideshow = useCallback(() => {
        if (slideshowTimerRef.current) {
            clearTimeout(slideshowTimerRef.current);
        }
        if (videoRef.current) {
            videoRef.current.pause();
            videoRef.current.currentTime = 0;
        }
        setMediaState({ type: 'image', index: 0 });
    }, []);

    const [prevIsHovering, setPrevIsHovering] = useState(false);
    if (isHovering !== prevIsHovering) {
        setPrevIsHovering(isHovering);
        if (isHovering && isSlideshowable) {
            setMediaState({ type: 'image', index: 0 });
        }
    }

    useEffect(() => {
        if (!isHovering) {
            const timer = setTimeout(() => {
                stopSlideshow();
            }, 0);
            return () => clearTimeout(timer);
        }
    }, [isHovering, stopSlideshow]);

    useEffect(() => {
        return () => {
            if (slideshowTimerRef.current) clearTimeout(slideshowTimerRef.current);
        };
    }, []);
    
    useEffect(() => {
        if (!isHovering || !isSlideshowable) return;
        if (slideshowTimerRef.current) clearTimeout(slideshowTimerRef.current);
    
        if (mediaState.type === 'image' && hasImages) {
            slideshowTimerRef.current = window.setTimeout(() => {
                const nextImageIndex = (mediaState.index + 1);
                if (nextImageIndex < template.bgImageUrls.length) {
                    setMediaState({ type: 'image', index: nextImageIndex });
                } else {
                    if (hasVideo) {
                        setMediaState({ type: 'video', index: 0 });
                    } else {
                        setMediaState({ type: 'image', index: 0 });
                    }
                }
            }, imageDisplayDuration);
        } else if (mediaState.type === 'video' && videoRef.current) {
            videoRef.current.currentTime = 0;
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
                playPromise.catch(() => {
                    // Gracefully handle interruptions, e.g., rapid mouse out.
                });
            }
        }
    
        return () => {
            if (slideshowTimerRef.current) clearTimeout(slideshowTimerRef.current);
        };
    }, [mediaState, isHovering, isSlideshowable, hasImages, hasVideo, template.bgImageUrls]);

    const handleVideoEnd = useCallback(() => {
        if (isHovering && isSlideshowable) {
            setMediaState({ type: 'image', index: 0 });
        }
    }, [isHovering, isSlideshowable]);
    
    return (
        <div
            className={`rounded-2xl flex flex-col overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group border-2 ${qualityStyles.border} ${qualityStyles.shadow}`}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
        >
            <div 
                className="relative aspect-square overflow-hidden rounded-t-lg bg-neutral-900"
            >
                {isSlideshowable ? (
                    <>
                        {template.bgImageUrls.map((media, index) => { const url = typeof media === 'string' ? media : media.url; return <img key={url} src={url} alt="" className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ken-burns-image ${ isHovering && mediaState.type === 'image' && mediaState.index === index ? 'opacity-100' : 'opacity-0' }`} /> })}
                        {hasImages && ( <img src={typeof template.bgImageUrls[0] === 'string' ? template.bgImageUrls[0] : template.bgImageUrls[0].url} alt="" className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${ !isHovering ? 'opacity-100' : 'opacity-0' }`} /> )}
                        {hasVideo && ( <video ref={videoRef} src={template.bgVideoUrl} onEnded={handleVideoEnd} loop={false} muted playsInline className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${ isHovering && mediaState.type === 'video' ? 'opacity-100' : 'opacity-0' }`} /> )}
                    </>
                ) : (
                    <>
                        {hasImages && ( <img src={typeof template.bgImageUrls[0] === 'string' ? template.bgImageUrls[0] : template.bgImageUrls[0].url} alt="" className="absolute inset-0 w-full h-full object-cover ken-burns-image" /> )}
                        {hasVideo && !hasImages && ( <video ref={videoRef} src={template.bgVideoUrl} loop autoPlay muted playsInline onMouseEnter={e => e.currentTarget.play().catch(()=>{})} onMouseLeave={e => e.currentTarget.pause()} className="absolute inset-0 w-full h-full object-cover" /> )}
                    </>
                )}
                 <div className="absolute top-4 right-4 z-20 flex items-center gap-4 bg-black/50 backdrop-blur-sm rounded-full p-1.5 px-3">
                    <div className="flex items-center gap-1.5"><UsersIcon className="w-4 h-4 text-neutral-300" /><span className="text-sm font-semibold text-white">0</span></div>
                    <div className="flex items-center gap-1.5"><ChatBubbleBottomCenterTextIcon className="w-4 h-4 text-neutral-300" /><span className="text-sm font-semibold text-white">0</span></div>
                </div>

                {(template.label || template.aimodel) && (
                    <div className="absolute top-4 left-4 z-20 flex flex-col items-start gap-2">
                        {template.label && (
                            <div 
                                className={`px-3 py-1 text-white text-lg font-semibold rounded-full ${qualityStyles.bg}`}
                            >
                                {template.label}
                            </div>
                        )}
                        {template.aimodel && (
                            <div
                                className={`inline-block px-2.5 py-1 rounded-lg ${qualityStyles.bg}`}
                            >
                                <div className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
                                    {template.aimodel}
                                </div>
                            </div>
                        )}
                    </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 z-20">
                     <div className={`p-4 pt-8 bg-gradient-to-t ${qualityStyles.gradientFrom} to-transparent`}>
                         <div className="flex flex-wrap gap-1.5 mb-3">
                            {template.tags.map(tag => ( <span key={tag} className={`px-3 py-1 text-sm font-bold rounded-md ${getTagColor(tag)}`} style={{ textShadow: '0px 1px 3px rgba(0, 0, 0, 0.5)' }} >{tag}</span> ))}
                        </div>
                        <h3 className="font-bold text-white text-3xl leading-tight drop-shadow-md">{template.title}</h3>
                    </div>
                </div>
            </div>
            <div className={`p-4 flex items-center gap-4 ${qualityStyles.bg}`}>
                {template.smallAvatarUrl ? ( <img src={template.smallAvatarUrl} alt={template.name} className="w-14 h-14 rounded-full object-cover" /> ) : ( <div className="w-14 h-14 rounded-full bg-neutral-700 flex items-center justify-center"><UserCircleIcon className="w-10 h-10 text-neutral-500" /></div> )}
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-white text-lg truncate">{template.name}</h4>
                        <button onClick={() => onViewTemplate(template)} className="text-neutral-500 hover:text-white transition-colors flex-shrink-0">
                           <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fview.png?alt=media&token=136f5f79-3880-4325-9179-af4136ea65a0" alt="View Details" className="w-6 h-6"/>
                        </button>
                    </div>
                    <p className="text-base text-neutral-300 line-clamp-2">{template.longDescription}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={() => onCreate(template)} className="bg-gradient-cyan-purple text-white py-2 px-5 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity">Create</button>
                    <button onClick={() => onShare(template)} className="p-2 rounded-full text-neutral-500 hover:text-white hover:bg-white/10 transition-colors">
                        <ShareIcon className="w-5 h-5"/>
                    </button>
                </div>
            </div>
        </div>
    );
};


export const DiscoverPage: React.FC<DiscoverPageProps> = ({ isOpen, onClose, onOpenCreateModal, onCreateFromTemplate, isMandatory = false, accountSettings, templates }) => {
  const [inputTerm, setInputTerm] = useState('');
  const [executedTerm, setExecutedTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Souls');
  const [genderFilter, setGenderFilter] = useState<'All' | 'Male' | 'Female'>('All');
  const [useCode, setUseCode] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [soulToView, setSoulToView] = useState<Soul | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [soulToShare, setSoulToShare] = useState<SoulTemplate | null>(null);
  const [allSouls, setAllSouls] = useState<SoulTemplate[]>(templates);

  const searchWrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (searchWrapperRef.current && !searchWrapperRef.current.contains(event.target as Node)) {
            setIsSearchFocused(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const popularTags = useMemo(() => {
      const allTags = allSouls.flatMap(s => s.tags);
      return [...new Set(allTags)].slice(0, 10); // Limit to 10 popular tags
  }, [allSouls]);

  const handleSearch = useCallback(() => {
      setExecutedTerm(inputTerm);
  }, [inputTerm]);

  const handleTagClick = (tag: string) => {
      setInputTerm(prev => prev + `${tag}, `);
  };
  
  const filteredSouls = useMemo(() => {
    return allSouls.filter(template => {
      // FIX: The property `subscription` does not exist on SoulTemplate. Use `quality` instead.
      // Also, implement the logic to check if user's subscription tier can access the template quality.
      const quality = template.quality;
      const tier = accountSettings.subscriptionTier;
      let subscriptionMatch = false;

      if (accountSettings.adminMode || !quality || quality === 'Wisp') {
        subscriptionMatch = true;
      } else if (quality === 'Spirit') {
        subscriptionMatch = tier === 'Premium' || tier === 'Ultra' || tier === 'Max';
      } else if (quality === 'Ascend') {
        subscriptionMatch = tier === 'Ultra' || tier === 'Max';
      } else if (quality === 'Eternal') {
        subscriptionMatch = tier === 'Max';
      }
      
      if(!subscriptionMatch) return false;

      if (useCode) {
        return template.shareCode?.toLowerCase() === executedTerm.toLowerCase().trim();
      }

      const categoryMatch = selectedCategory === 'All Souls' || template.mainCategory === selectedCategory;
      const genderMatch = genderFilter === 'All' || template.gender === genderFilter;
      
      const searchTerms = executedTerm.toLowerCase().split(',').map(t => t.trim()).filter(Boolean);
      const searchMatch = searchTerms.length === 0 || searchTerms.every(term =>
          template.name.toLowerCase().includes(term) ||
          template.title.toLowerCase().includes(term) ||
          template.longDescription.toLowerCase().includes(term) ||
          template.tags.some(tag => tag.toLowerCase().includes(term))
      );
      
      return categoryMatch && genderMatch && searchMatch;
    }).sort((a,b) => a.name.localeCompare(b.name));
  }, [executedTerm, selectedCategory, genderFilter, useCode, allSouls, accountSettings]);
  
  const handleViewTemplate = (template: SoulTemplate) => {
    const tempSoul: Soul = {
      id: 'template-view-' + template.name, name: template.name, description: template.title, model: 'gemini-2.5-pro', gender: template.gender,
      avatar: template.smallAvatarUrl, backstory: template.backstory, responseDirective: template.responseDirective, keyMemories: template.keyMemories,
      greeting: template.greeting, exampleMessage: template.exampleMessage || template.greeting, voiceURI: null, mbti: template.mbti || null,
      enneagram: template.enneagram || null, dynamism: template.dynamism, antiRepeatStrength: 0.00, memoryConsolidation: true, memoryRecall: true,
      maxTokens: 2048, avatarStyle: 'Photoreal', physicalAppearanceDescription: template.longDescription, faceDetailEnhance: 0,
      faceDetailPrompt: '', enableNsfwSelfies: false, selfies: [], followersCount: 0, followingCount: 0, templateName: template.name,
      username: template.name.toLowerCase().replace(/\s+/g, '_'), bio: template.longDescription, profileBannerUrl: template.profileBannerUrl || null,
      posts: [], role: template.role || SoulRole.CHARACTER, characterSheet: template.characterSheet || '',
      soulId: template.soulId, shareCode: template.shareCode, edition: template.edition,
    };
    setSoulToView(tempSoul);
    setIsTemplateModalOpen(true);
  };

  const handleShareTemplate = (template: SoulTemplate) => {
    setSoulToShare(template);
    setIsShareModalOpen(true);
  };

  const content = (
      <main className="w-full max-w-6xl mx-auto pt-8">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white">Create a Soul</h2>
          <p className="text-neutral-400 mt-2">
            Browse our community’s featured Souls, search, or{' '}
            <button onClick={onOpenCreateModal} className="text-blue-400 hover:text-blue-300 font-semibold underline">
              create your Soul from scratch
            </button>
            .
          </p>
        </div>
        
        {!useCode && (
            <div className="mb-8 grid grid-cols-2 sm:grid-cols-5 gap-2">
            {categories.map(category => (
                <button
                key={category.name}
                onClick={() => setSelectedCategory(category.name)}
                className={`flex flex-col items-center justify-center text-center p-3 rounded-lg transition-all duration-200 ${
                    selectedCategory === category.name 
                    ? 'bg-neutral-700/80 ring-2 ring-purple-500' 
                    : 'bg-neutral-800/50 hover:bg-neutral-700/60'
                }`}
                >
                <span className={`mb-1.5 w-8 h-8 flex items-center justify-center ${selectedCategory === category.name ? 'text-purple-400' : 'text-neutral-400'}`}>
                    {category.icon}
                </span>
                <span className={`text-xs font-semibold ${selectedCategory === category.name ? 'text-white' : 'text-neutral-300'}`}>
                    {category.name}
                </span>
                </button>
            ))}
            </div>
        )}

        <div ref={searchWrapperRef} className="mb-4 relative">
            <div className="flex items-center gap-2">
                <input 
                    type="text"
                    placeholder={useCode ? "Enter share code" : "Search keywords..."}
                    value={inputTerm}
                    onFocus={() => setIsSearchFocused(true)}
                    onChange={(e) => setInputTerm(e.target.value)}
                    onKeyDown={(e) => { if(e.key === 'Enter') handleSearch(); }}
                    className="flex-grow bg-neutral-800/60 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
                <button onClick={handleSearch} className="p-3 bg-neutral-800/60 border border-neutral-700 rounded-lg hover:bg-neutral-700/80">
                    <SearchIcon className="w-5 h-5 text-neutral-400"/>
                </button>
            </div>
            {isSearchFocused && !useCode && (
                <div className="absolute top-full mt-2 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 z-10 shadow-lg">
                    <p className="text-xs text-neutral-500 mb-2">Popular Tags</p>
                    <div className="flex flex-wrap gap-1.5">
                        {popularTags.map(tag => (
                            <button key={tag} onClick={() => handleTagClick(tag)} className={`px-2 py-1 text-xs font-semibold rounded-full ${getTagColor(tag)} hover:opacity-80 transition-opacity`}>
                                {tag}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
        
        <div className="mb-8 flex justify-between items-center">
            <div className={`flex items-center gap-4 transition-opacity ${useCode ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
                {(['All', 'Male', 'Female'] as const).map(g => (
                    <button key={g} onClick={() => setGenderFilter(g)} className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${genderFilter === g ? 'border-purple-500' : 'border-neutral-600'}`}>
                            {genderFilter === g && <div className="w-2 h-2 bg-purple-500 rounded-full"></div>}
                        </div>
                        <span className={`text-sm ${genderFilter === g ? 'text-white' : 'text-neutral-400'}`}>{g}</span>
                    </button>
                ))}
            </div>
            <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-neutral-400">Use Code</span>
                <Toggle checked={useCode} onChange={setUseCode} />
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredSouls.length > 0 ? filteredSouls.map(template => (
                <SoulCard key={template.shareCode} template={template} onCreate={onCreateFromTemplate} onViewTemplate={handleViewTemplate} onShare={handleShareTemplate} />
            )) : (
                <div className="md:col-span-2 text-center py-16 px-4 border-2 border-dashed border-neutral-700 rounded-lg">
                    <h3 className="text-xl font-semibold text-white">No Souls Found</h3>
                    <p className="text-neutral-400 mt-2">Try adjusting your search or filter settings.</p>
                </div>
            )}
        </div>
      </main>
  );

  const pageOrModalContent = isMandatory ? (
    <div className="bg-transparent text-white">
      <div className="p-4 md:p-8">
        {content}
      </div>
    </div>
  ) : (
    <div className="w-full h-full overflow-y-auto bg-transparent">
        <div className="p-4 md:p-8 pt-0">
          {content}
        </div>
    </div>
  );

  return (
    <>
      <SoulTemplateModal
        isOpen={isTemplateModalOpen}
        onClose={() => setIsTemplateModalOpen(false)}
        soul={soulToView}
        position="top"
      />
      <ShareSoulModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          template={soulToShare}
      />
      {pageOrModalContent}
    </>
  );
};
