// components/SoulsTemplates/CSTemplates.ts

// NOTE: URLs must point to the 'raw' file content, not the GitHub repository page.
export const characterSheetLinks: Record<string, string> = {
  // D&D 5e Sheet for both adventures
  CURSE_OF_STRAHD: 'https://gist.githubusercontent.com/gregk-fe/b9b2e008d5069403d64c24388432b49c/raw/d021cdd9513a9a140b9c31cee85d10af381d6d30/dnd5e_character_sheet.md',
  WATERDEEP_DRAGON_HEIST: 'https://gist.githubusercontent.com/gregk-fe/b9b2e008d5069403d64c24388432b49c/raw/d021cdd9513a9a140b9c31cee85d10af381d6d30/dnd5e_character_sheet.md',
  
  // Other sheets from DiscoverPageSouls.tsx
  'Blades in the Dark': 'https://gist.githubusercontent.com/gregk-fe/1e075c91f6c6f78f6916c96841e4b3e8/raw/70278788647754d216f9e776e02690d56c429b35/blades_in_the_dark_crew_sheet.md',
  'Shadowrun5e': 'https://raw.githubusercontent.com/Roll20/roll20-character-sheets/master/Shadowrun5e/sheet.json',
  'ALIEN The Roleplaying Game': 'https://raw.githubusercontent.com/Roll20/roll20-character-sheets/master/Alien%20RPG/sheet.html',
  'The Witcher: Monster Hunt': 'https://raw.githubusercontent.com/Roll20/roll20-character-sheets/master/The%20Witcher%20TRPG/sheet.html',
  'Call of Cthulhu 7th Edition': 'https://raw.githubusercontent.com/Roll20/roll20-character-sheets/master/CallOfCthulhu7thEdition/sheet.html',
};
