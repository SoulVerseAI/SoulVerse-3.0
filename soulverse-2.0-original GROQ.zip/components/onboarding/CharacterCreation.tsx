
import React, { useState, useMemo, useEffect } from 'react';
import { AccountSettings, Gender } from '../../types';
import { ProgressBar } from './ProgressBar';

interface CharacterCreationProps {
  accountSettings: AccountSettings;
  onUpdateSettings: (updates: Partial<AccountSettings>) => void;
  onAccept: () => void;
  onBack: () => void;
}

const portraits = {
  female: [
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(1).png?alt=media&token=723e5b49-e42a-4cf9-a78e-b551ebcc5c01',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(2).png?alt=media&token=cdf5d35f-8c38-4e5e-9df4-8641ed16a1a5',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(3).png?alt=media&token=a18cb454-e9ea-43c0-81db-30aae6ae9ef3',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(4).png?alt=media&token=6d981e24-a5a8-4a1f-a56d-ca872af03dd5',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(5).png?alt=media&token=d8449b88-5c1a-47c8-ba32-e6e3b5b58138',
  ],
  male: [
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(1).png?alt=media&token=a7b9463b-6210-403d-af65-def39c67552d',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(2).png?alt=media&token=c382eba4-0dd9-4374-9a69-43e590cb10f7',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(4).png?alt=media&token=8bd934a0-948f-49ae-85ec-b202271ba2dc',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(5).png?alt=media&token=72b86d08-f108-4326-af28-a730bee9191b',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(6).png?alt=media&token=f139d255-2b8d-4509-9c5f-e52eaca6bf9a',
  ],
};

const PortraitButton: React.FC<{ src: string; isSelected: boolean; onClick: () => void }> = ({ src, isSelected, onClick }) => (
    <button onClick={onClick} className={`flex-shrink-0 w-24 h-24 rounded-lg overflow-hidden border-2 transition-all duration-200 ${isSelected ? 'border-purple-500 scale-105 ring-2 ring-purple-400/50' : 'border-neutral-700 hover:border-neutral-500'}`}>
        <img src={src} alt="Portrait option" className="w-full h-full object-cover" />
    </button>
);

export const CharacterCreation: React.FC<CharacterCreationProps> = ({ accountSettings, onUpdateSettings, onAccept, onBack }) => {
    const [name, setName] = useState(accountSettings.userName);
    const [selectedAvatar, setSelectedAvatar] = useState(accountSettings.userAvatar);

    const availablePortraits = useMemo(() => {
        const gender = accountSettings.userGender;
        if (gender === 'Male') return portraits.male;
        if (gender === 'Female') return portraits.female;
        return [...portraits.female, ...portraits.male];
    }, [accountSettings.userGender]);

    if (!selectedAvatar || !availablePortraits.includes(selectedAvatar)) {
        const defaultAvatar = availablePortraits[0];
        setSelectedAvatar(defaultAvatar);
    }

    useEffect(() => {
        if (selectedAvatar && selectedAvatar !== accountSettings.userAvatar) {
            onUpdateSettings({ userAvatar: selectedAvatar });
        }
    }, [selectedAvatar, accountSettings.userAvatar, onUpdateSettings]);

    const handleSelect = (url: string) => {
        setSelectedAvatar(url);
        onUpdateSettings({ userAvatar: url });
    };

    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setName(e.target.value);
    };

    const handleNameBlur = () => {
        onUpdateSettings({ userName: name });
    };


    return (
        <div className="flex flex-col h-full p-6 text-white bg-transparent overflow-y-auto">
            <ProgressBar currentStep={2} totalSteps={3} />
            
            <div className="flex items-center gap-4 p-4 bg-neutral-900/30 border border-neutral-700/60 rounded-lg mb-8">
                <div className="w-20 h-20 rounded-lg overflow-hidden border-2 border-neutral-600 flex-shrink-0">
                    {selectedAvatar && <img src={selectedAvatar} alt="Selected Portrait" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1">
                    <label htmlFor="character-name" className="block text-sm text-neutral-400 mb-1">Character Name</label>
                    <input
                        id="character-name"
                        type="text"
                        value={name}
                        onChange={handleNameChange}
                        onBlur={handleNameBlur}
                        className="w-full bg-transparent border-b-2 border-neutral-600 focus:border-purple-500 focus:outline-none text-xl font-semibold transition-colors"
                    />
                </div>
            </div>

            <div className="space-y-4 flex-1">
                <h3 className="text-lg font-semibold text-neutral-300 border-b-2 border-neutral-700/60 pb-2 mb-4">Select Your Portrait</h3>
                <div className="flex items-center gap-4 pb-4 overflow-x-auto custom-scrollbar">
                    {availablePortraits.map(url => (
                        <PortraitButton key={url} src={url} isSelected={selectedAvatar === url} onClick={() => handleSelect(url)} />
                    ))}
                </div>
            </div>
            
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-neutral-700/60">
                <button onClick={onBack} className="py-2 px-8 rounded-lg text-neutral-300 font-semibold transition-colors bg-neutral-800 hover:bg-neutral-700">
                    Back
                </button>
                <button 
                    onClick={onAccept}
                    className="py-2 px-8 rounded-lg text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                >
                    Accept
                </button>
            </div>
        </div>
    );
};
