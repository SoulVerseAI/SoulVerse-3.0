import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';

const EmailIcon = () => (
    <svg width="80" height="80" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
         <defs>
            <linearGradient id="neon-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#25C5D2" />
                <stop offset="100%" stopColor="#A455F7" />
            </linearGradient>
        </defs>
        <path d="M85 25H15C12.2386 25 10 27.2386 10 30V70C10 72.7614 12.2386 75 15 75H85C87.7614 75 90 72.7614 90 70V30C90 27.2386 87.7614 25 85 25Z" stroke="url(#neon-grad)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M10 30L50 52.5L90 30" stroke="url(#neon-grad)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);


interface CheckMailProps {
    email: string;
    onSendAgain: () => void;
    onNavigateToTerms: () => void;
}

export const CheckMail: React.FC<CheckMailProps> = ({ email, onSendAgain, onNavigateToTerms }) => {
    const [code, setCode] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const { verifyLoginOtp } = useAuth();

    const handleVerify = async (e: React.FormEvent) => {
        e.preventDefault();
        if (code.length < 6) {
            setError('Please enter the 6-digit code from your email.');
            return;
        }

        // Admin-specific token check
        if (email.toLowerCase() === 'gkryniecki@gmail.com' && code !== '235523') {
            setError('Invalid token for admin account.');
            return;
        }

        setIsLoading(true);
        setError('');

        const { error: verifyError } = await verifyLoginOtp(email, code);

        if (verifyError) {
            setError(verifyError.message || 'Invalid or expired code. Please try again.');
        }
        // On success, the AuthContext's onAuthStateChange listener will handle
        // updating the user state, which triggers navigation in App.tsx.
        
        setIsLoading(false);
    };

    return (
        <div className="relative flex flex-col items-center justify-center min-h-screen text-neutral-200 p-4 overflow-hidden">
            <div className="absolute inset-0 z-0">
                <div className="absolute top-0 left-0 w-full h-full bg-cover bg-center" style={{backgroundImage: "url('https://firebasestorage.googleapis.com/v0/b/gen-lang-client-0176412501.firebasestorage.app/o/bg.png?alt=media&token=c1112b32-3b2d-4561-9c16-b84295e86d06')"}}></div>
                <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-purple-500/30 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-cyan-500/30 rounded-full blur-3xl animate-pulse animation-delay-400"></div>
            </div>
            <div className="relative z-10 w-full max-w-md text-center">
                <div className="w-24 h-24 mx-auto mb-8 flex items-center justify-center">
                    <EmailIcon />
                </div>
                <h2 className="text-2xl font-bold text-white">Check your mail</h2>
                <p className="mt-2 text-sm text-neutral-400">
                    We sent a 6-digit verification code to <span className="font-semibold text-white">{email}</span>. The code will expire shortly.
                </p>
                
                <form onSubmit={handleVerify} className="mt-8 space-y-4">
                    <input
                        type="text"
                        value={code}
                        onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                        maxLength={6}
                        className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 text-center text-2xl tracking-[0.5em] focus:ring-2 focus:ring-purple-500 focus:outline-none"
                        placeholder="_ _ _ _ _ _"
                        aria-label="Verification Code"
                        disabled={isLoading}
                    />
                     {error && <p className="text-sm text-red-500">{error}</p>}
                    <button
                        type="submit"
                        disabled={isLoading || code.length < 6}
                        className="w-full py-3 px-4 rounded-full font-semibold text-white transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                    >
                        {isLoading ? 'Verifying...' : 'Verify'}
                    </button>
                </form>
                
                <button onClick={onSendAgain} className="mt-6 text-sm text-neutral-400 hover:text-white underline">
                    Didn't receive an email? Send again
                </button>
                <p className="text-xs text-neutral-500 mt-8">
                    By signing in, you agree to our{' '}
                    <button onClick={onNavigateToTerms} className="underline hover:text-neutral-300">Terms of Service</button>.
                </p>
            </div>
        </div>
    );
};