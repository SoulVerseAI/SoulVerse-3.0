

import React, { useState } from 'react';

interface EnterGiftCodeProps {
    onNext: (code: string) => void;
    onBack: () => void;
}

export const EnterGiftCode: React.FC<EnterGiftCodeProps> = ({ onNext, onBack }) => {
    const [code, setCode] = useState('');

    return (
        <div className="relative flex flex-col items-center justify-start pt-20 min-h-screen text-neutral-200 p-4 overflow-hidden">
            <div className="absolute inset-0 z-0">
                <div className="absolute top-0 left-0 w-full h-full bg-cover bg-center" style={{backgroundImage: "url('https://firebasestorage.googleapis.com/v0/b/gen-lang-client-0176412501.firebasestorage.app/o/bg.png?alt=media&token=c1112b32-3b2d-4561-9c16-b84295e86d06')"}}></div>
                <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-purple-500/30 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-cyan-500/30 rounded-full blur-3xl animate-pulse animation-delay-400"></div>
            </div>
            <div className="relative z-10 w-full max-w-lg mx-auto">
                 <div className="relative h-2 bg-neutral-700 rounded-full mb-10">
                    <div className="absolute top-0 left-0 h-2 bg-gradient-cyan-purple rounded-full" style={{width: '66%'}}></div>
                </div>

                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-white">Enter gift code</h1>
                    <p className="mt-2 text-neutral-400">If you have a gift code, enter it here. You can leave this blank if you don’t have one.</p>
                </div>

                <div className="space-y-2">
                    <label htmlFor="gift-code" className="text-sm font-medium text-neutral-400">Gift code (optional)</label>
                    <input id="gift-code" type="text" value={code} onChange={e => setCode(e.target.value)} placeholder="Gift code (optional)" className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none"/>
                </div>

                <div className="flex justify-between items-center mt-12">
                     <button onClick={onBack} className="py-3 px-10 rounded-full text-neutral-400 font-semibold transition-colors hover:bg-neutral-800">
                        Back
                    </button>
                    <button 
                        onClick={() => onNext(code)}
                        className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90"
                    >
                        Next
                    </button>
                </div>
            </div>
        </div>
    );
};
