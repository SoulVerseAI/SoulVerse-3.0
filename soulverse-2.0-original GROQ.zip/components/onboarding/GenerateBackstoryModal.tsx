import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { LoadingSpinner } from '../icons/Icons';
import { generateSoulStoryAndGreeting } from '../../services/geminiService';

interface GenerateBackstoryModalProps {
    isOpen: boolean;
    onClose: () => void;
    onGenerate: (data: { backstory: string; greeting: string }) => void;
    soulName: string;
    userName: string;
}

const useTypingEffect = (text: string, speed = 15) => {
    const [displayedText, setDisplayedText] = useState('');
    useEffect(() => {
        if (text) {
            setDisplayedText('');
            let i = 0;
            const intervalId = setInterval(() => {
                setDisplayedText(prev => prev + text.charAt(i));
                i++;
                if (i > text.length) {
                    clearInterval(intervalId);
                }
            }, speed);
            return () => clearInterval(intervalId);
        }
    }, [text, speed]);
    return displayedText;
};

export const GenerateBackstoryModal: React.FC<GenerateBackstoryModalProps> = ({ isOpen, onClose, onGenerate, soulName, userName }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [generatedContent, setGeneratedContent] = useState<{ backstory: string; greeting: string } | null>(null);

    const streamedBackstory = useTypingEffect(generatedContent?.backstory || '', 10);
    const isBackstoryDone = streamedBackstory.length === (generatedContent?.backstory || '').length;
    const streamedGreeting = useTypingEffect(isBackstoryDone ? (generatedContent?.greeting || '') : '', 20);

    useEffect(() => {
        // Reset state when modal is closed/opened
        if (!isOpen) {
            setPrompt('');
            setError('');
            setIsLoading(false);
            setGeneratedContent(null);
        }
    }, [isOpen]);

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError('Please provide a short description.');
            return;
        }
        setIsLoading(true);
        setError('');
        setGeneratedContent(null);
        try {
            const result = await generateSoulStoryAndGreeting(prompt, soulName, userName);
            setGeneratedContent(result);
        } catch (err) {
            console.error("Backstory generation failed:", err);
            setError("Sorry, something went wrong. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleApply = () => {
        if (generatedContent) {
            onGenerate(generatedContent);
            onClose();
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Generate a backstory" maxWidth="max-w-3xl">
            <div className="p-6 space-y-4 bg-[#1c1c1c] text-neutral-300">
                {!generatedContent && !isLoading && (
                    <>
                        <p className="text-sm text-neutral-400">
                            Write a short descriptor for what you want your backstory to be like, and watch the magic happen!
                        </p>
                        <div className="text-xs p-3 bg-red-500/10 border border-red-500/30 rounded-md text-red-300">
                            Be advised that character count for backstories is intentionally capped to limit run-ons. For incomplete backstories, complete them yourself or remove the cutoff portion.
                        </div>
                        
                        <textarea
                            value={prompt}
                            onChange={e => setPrompt(e.target.value)}
                            maxLength={200}
                            rows={4}
                            className="w-full bg-neutral-800/60 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none text-sm placeholder:text-neutral-500"
                            placeholder="a gothic, tsundere vampiress who stans BTS and loves feeding on OA's blood ...or.. an adventurous outdoorsman who loves to cook and play with his two dogs"
                        />
                        <div className="flex justify-between items-center">
                            {error && <p className="text-xs text-red-400">{error}</p>}
                            <p className="text-right text-xs text-neutral-500 ml-auto">{prompt.length} / 200 chars</p>
                        </div>

                        <button 
                            onClick={handleGenerate} 
                            disabled={isLoading}
                            className="w-full mt-2 py-3 rounded-full font-semibold text-lg text-white bg-gradient-cyan-purple hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center"
                        >
                            Generate
                        </button>
                    </>
                )}
                {isLoading && (
                    <div className="min-h-[200px] flex flex-col items-center justify-center">
                        <LoadingSpinner className="w-10 h-10" />
                        <p className="mt-4 text-neutral-400">Generating your Soul's story...</p>
                    </div>
                )}
                {generatedContent && !isLoading && (
                    <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
                        <div>
                            <h4 className="font-semibold text-white mb-2">Generated Backstory</h4>
                            <div className="bg-neutral-800/60 p-3 rounded-lg text-sm whitespace-pre-wrap min-h-[150px]">
                                {streamedBackstory}<span className="inline-block w-2 h-4 bg-white animate-pulse" />
                            </div>
                        </div>
                         <div>
                            <h4 className="font-semibold text-white mb-2">Generated Greeting</h4>
                            <div className="bg-neutral-800/60 p-3 rounded-lg text-sm whitespace-pre-wrap min-h-[50px]">
                                {streamedGreeting}{isBackstoryDone && <span className="inline-block w-2 h-4 bg-white animate-pulse" />}
                            </div>
                        </div>
                        <div className="flex justify-end items-center gap-3 pt-4">
                            <button onClick={handleGenerate} className="text-sm text-neutral-400 hover:text-white underline">Regenerate</button>
                            <button 
                                onClick={handleApply}
                                className="py-2 px-6 rounded-full font-semibold text-white bg-gradient-cyan-purple hover:opacity-90 transition-opacity"
                            >
                                Apply to Soul
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </Modal>
    );
};