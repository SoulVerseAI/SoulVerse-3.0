import React from 'react';

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ currentStep, totalSteps }) => {
  const percentage = (currentStep / totalSteps) * 100;

  return (
    <div className="relative h-1.5 bg-neutral-700 rounded-full w-full max-w-sm mx-auto mb-10 overflow-hidden">
      <div
        className="absolute top-0 left-0 h-full bg-gradient-cyan-purple rounded-full transition-all duration-500"
        style={{ width: `${percentage}%` }}
      ></div>
    </div>
  );
};
