import React, { useState, useCallback } from 'react';
import { SoulTemplate } from '../../types';
import { UserCircleIcon, ClipboardIcon, XMarkIcon, CheckIcon } from '../icons/Icons';

interface SoulHelloProps {
  template: SoulTemplate;
  userName: string;
  onFinish: () => void;
  onBack: () => void;
  onClose: () => void;
}

export const SoulHello: React.FC<SoulHelloProps> = ({ template, userName, onFinish, onBack, onClose }) => {
  const [copied, setCopied] = useState(false);
  const greetingText = template.greeting.replace(/\{user\}/gi, userName);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(greetingText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [greetingText]);

  const getBackgroundImage = (template: SoulTemplate) => {
    if (template.bgImageUrls && template.bgImageUrls.length > 0) {
      const firstImage = template.bgImageUrls[0];
      if (typeof firstImage === 'string') {
        return firstImage;
      }
      if (firstImage && typeof firstImage === 'object' && 'url' in firstImage && typeof firstImage.url === 'string') {
        return firstImage.url;
      }
    }
    return template.smallAvatarUrl;
  };
  
  const backgroundImageUrl = getBackgroundImage(template);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen text-neutral-200 p-4 overflow-auto">
      <div className="absolute inset-0 z-0">
        {backgroundImageUrl && (
          <div 
            className="absolute top-0 left-0 w-full h-full bg-cover bg-center transition-opacity duration-500 ken-burns-image"
            style={{ backgroundImage: `url(${backgroundImageUrl})` }}
          ></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent"></div>
      </div>
      
      <button onClick={onClose} className="absolute top-6 right-6 p-2 rounded-full text-neutral-300 hover:bg-black/50 hover:text-white z-20" aria-label="Close">
        <XMarkIcon className="w-8 h-8" />
      </button>

      <div className="relative z-10 w-full max-w-2xl text-center flex flex-col items-center my-auto py-10">
        <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-white/20 shadow-2xl mb-6 flex-shrink-0">
          {template.smallAvatarUrl ? (
            <img src={template.smallAvatarUrl} alt={template.name} className="w-full h-full object-cover" />
          ) : (
            <UserCircleIcon className="w-full h-full text-neutral-600 bg-neutral-800" />
          )}
        </div>
        <h1 className="text-5xl font-bold text-white drop-shadow-lg">{template.name}</h1>
        <p className="mt-2 text-lg text-neutral-300 drop-shadow-md">{template.title.replace(/\{soul\}/gi, template.name).replace(/\{user\}/gi, userName)}</p>

        <div className="mt-8 p-6 bg-black/50 backdrop-blur-md rounded-xl border border-white/10 w-full relative">
          <p className="text-lg text-neutral-200 italic text-left">"{greetingText}"</p>
          <button onClick={handleCopy} className="absolute top-3 right-3 p-1.5 rounded-full text-neutral-400 hover:text-white bg-black/30" title="Copy greeting">
            {copied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <ClipboardIcon className="w-5 h-5" />}
          </button>
        </div>

        <div className="flex justify-between items-center mt-12 w-full max-w-md">
          <button onClick={onBack} className="py-3 px-10 rounded-full text-neutral-300 font-semibold transition-colors bg-black/30 backdrop-blur-sm hover:bg-black/50">
            Back
          </button>
          <button 
            onClick={onFinish}
            className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90"
          >
            Create Soul
          </button>
        </div>
      </div>
    </div>
  );
};
