
import React from 'react';
import { Soul, Gender } from '../../types';
import { ProgressBar } from './ProgressBar';
import { XMarkIcon } from '../icons/Icons';

interface NameYourSoulProps {
    data: Partial<Soul>;
    onUpdate: (updates: Partial<Soul>) => void;
    onNext: () => void;
    onBack: () => void;
    onClose: () => void;
}

export const NameYourSoul: React.FC<NameYourSoulProps> = ({ data, onUpdate, onNext, onBack, onClose }) => {

    const canProceed = data.name && data.name.trim() !== '' && data.gender;

    return (
        <div className="flex flex-col items-center justify-start text-neutral-200 p-4">
            <div className="w-full max-w-lg mx-auto">
                <ProgressBar currentStep={1} totalSteps={4} />

                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-white">Your Soul</h1>
                    <p className="mt-2 text-neutral-400">Some basic details about your Soul.</p>
                </div>
                
                <div className="space-y-6">
                    <div>
                        <label htmlFor="soul-name" className="text-sm font-medium text-neutral-300 mb-2 block">Soul Name</label>
                        <input 
                            id="soul-name" 
                            type="text" 
                            value={data.name || ''} 
                            onChange={e => onUpdate({ name: e.target.value })} 
                            className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                            placeholder="E.g., Cyra"
                        />
                    </div>
                     <div>
                         <label className="text-sm font-medium text-neutral-300 mb-2 block">Soul Gender</label>
                         <div className="grid grid-cols-2 gap-3">
                             <button 
                                onClick={() => onUpdate({ gender: 'Male' })} 
                                className={`py-3 rounded-lg font-semibold transition-colors ${data.gender === 'Male' ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-800 hover:bg-neutral-700'}`}
                             >
                                Male
                             </button>
                             <button 
                                onClick={() => onUpdate({ gender: 'Female' })} 
                                className={`py-3 rounded-lg font-semibold transition-colors ${data.gender === 'Female' ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-800 hover:bg-neutral-700'}`}
                             >
                                Female
                            </button>
                         </div>
                    </div>
                </div>

                <div className="flex justify-between items-center mt-12">
                     <button onClick={onBack} className="py-3 px-10 rounded-full text-neutral-400 font-semibold transition-colors hover:bg-neutral-800">
                        Back
                    </button>
                    <button 
                        onClick={onNext}
                        disabled={!canProceed}
                        className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                    >
                        Next
                    </button>
                </div>
            </div>
        </div>
    );
};
