
import React from 'react';
import { Soul } from '../../types';
import { ProgressBar } from './ProgressBar';
import { XMarkIcon } from '../icons/Icons';

interface HelloYourSoulProps {
    data: Partial<Soul>;
    onFinish: () => void;
    onBack: () => void;
    onClose: () => void;
}

export const HelloYourSoul: React.FC<HelloYourSoulProps> = ({ data, onFinish, onBack, onClose }) => {

    return (
        <div className="relative flex flex-col items-center justify-between min-h-full bg-transparent text-white p-4 overflow-hidden">
            {data.avatar && (
                <div 
                    className="absolute inset-0 bg-cover bg-center transition-opacity duration-500 rounded-b-xl"
                    style={{ backgroundImage: `url(${data.avatar})` }}
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/20"></div>
                </div>
            )}
            
            <div className="relative w-full max-w-lg mx-auto z-10 pt-6">
                 <ProgressBar currentStep={4} totalSteps={4} />
            </div>

            <div className="relative z-10 text-center">
                 <h1 className="text-4xl font-bold text-white drop-shadow-lg">Hello, {data.name || 'Soul'}!</h1>
                 <p className="mt-2 text-neutral-200 drop-shadow-md">You can customize your Soul in the settings menu at any time.</p>
            </div>
            
            <div className="relative w-full max-w-lg mx-auto z-10 pb-6">
                <div className="flex justify-between items-center mt-12">
                     <button onClick={onBack} className="py-3 px-10 rounded-full text-neutral-300 font-semibold transition-colors bg-black/30 backdrop-blur-sm hover:bg-black/50">
                        Back
                    </button>
                    <button 
                        onClick={onFinish}
                        className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90"
                    >
                        Finish
                    </button>
                </div>
            </div>
        </div>
    );
};
