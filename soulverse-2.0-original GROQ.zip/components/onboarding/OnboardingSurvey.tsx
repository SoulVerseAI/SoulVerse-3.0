import React, { useState } from 'react';

interface OnboardingSurveyProps {
  onComplete: (selection: string) => void;
}

const surveyOptions = [
  { left: 'Google/Youtube ad', right: 'X/Twitter' },
  { left: 'Friend', right: 'App Store ad' },
  { left: 'Instagram', right: 'Reddit' },
  { left: 'News', right: 'Pinterest' },
  { left: 'ChatGPT/other AI', right: 'TikTok' },
  { left: 'Facebook', right: 'Other' },
];

export const OnboardingSurvey: React.FC<OnboardingSurveyProps> = ({ onComplete }) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleSelect = (option: string) => {
    setSelectedOption(option);
  };
  
  const handleSubmit = () => {
    if (selectedOption) {
      onComplete(selectedOption);
    }
  };

  return (
    <div className="p-4 md:p-6 bg-gradient-to-b from-cyan-600/30 to-purple-800/30">
      <div className="w-full max-w-lg mx-auto text-center text-white font-sans">
        <h1 className="text-4xl font-bold mb-2">Welcome to Soulverse! 🎉</h1>
        <p className="text-lg text-neutral-400 mb-12">We're glad you're here – how did you find us?</p>
        
        <div className="grid grid-cols-2 gap-x-8 gap-y-6 text-lg mb-12">
          {surveyOptions.map((row, index) => (
            <React.Fragment key={index}>
              <button
                onClick={() => handleSelect(row.left)}
                className={`p-2 rounded-md transition-colors text-center ${selectedOption === row.left ? 'text-white font-semibold' : 'text-neutral-400 hover:text-white'}`}
              >
                {row.left}
              </button>
              <button
                onClick={() => handleSelect(row.right)}
                className={`p-2 rounded-md transition-colors text-center ${selectedOption === row.right ? 'text-white font-semibold' : 'text-neutral-400 hover:text-white'}`}
              >
                {row.right}
              </button>
            </React.Fragment>
          ))}
        </div>

        <button
            onClick={() => handleSelect('Prefer not to say')}
            className={`p-2 rounded-md transition-colors text-center text-lg ${selectedOption === 'Prefer not to say' ? 'text-white font-semibold' : 'text-neutral-400 hover:text-white'}`}
        >
            Prefer not to say
        </button>

        <button
          onClick={handleSubmit}
          disabled={!selectedOption}
          className="w-full mt-10 py-4 px-6 bg-gradient-cyan-purple text-white font-semibold text-xl rounded-2xl transition-colors hover:opacity-90 disabled:bg-neutral-800 disabled:text-neutral-500 disabled:cursor-not-allowed"
        >
          Continue to Soulverse
        </button>
      </div>
    </div>
  );
};