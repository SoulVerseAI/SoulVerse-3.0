
import React, { useState, useEffect, useRef } from 'react';
import { Soul, Selfie } from '../../types';
import { ProgressBar } from './ProgressBar';
import { ChevronLeftIcon, ChevronRightIcon, WandSparklesIcon, XMarkIcon } from '../icons/Icons';
import { GenerateAvatarModal } from '../ui/GenerateAvatarModal';
import { SelectGeneratedAvatarModal } from '../ui/SelectGeneratedAvatarModal';
import { generateAvatarImage, generateAvatarDescriptionFromImage } from '../../services/geminiService';
import { LoadingSpinner } from '../icons/Icons';
import { CollapsibleSection } from '../ui/CollapsibleSection';
import { Slider } from '../ui/Slider';

// Avatar URLs
const femaleAvatars = [ 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem1.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem2.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem3.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem4.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem5.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem1anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem2anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem3anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem4anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/fem5anime.png' ];
const maleAvatars = [ 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male1.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male2.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male3.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male4.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male5.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male1anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male2anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male3anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male4anime.png', 'https://gkryniecki.wordpress.com/wp-content/uploads/2025/07/male5anime.png' ];

interface LookYourSoulProps {
    data: Partial<Soul>;
    onUpdate: (updates: Partial<Soul>) => void;
    onNext: () => void;
    onBack: () => void;
    onClose: () => void;
    setToast: (toast: { title: string; message: React.ReactNode } | null) => void;
}

export const LookYourSoul: React.FC<LookYourSoulProps> = ({ data, onUpdate, onNext, onBack, onClose, setToast }) => {
    const [mode, setMode] = useState<'predefined' | 'custom'>('predefined');
    const [predefinedIndex, setPredefinedIndex] = useState(0);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [showGuidelines, setShowGuidelines] = useState(false);
    
    const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
    const [isSelectModalOpen, setIsSelectModalOpen] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedAvatars, setGeneratedAvatars] = useState<{url: string, prompt: string}[]>([]);
    const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
    const [validationError, setValidationError] = useState('');

    const avatarList = data.gender === 'Male' ? maleAvatars : femaleAvatars;

    useEffect(() => {
        if (mode === 'predefined' && (!data.avatar || !avatarList.includes(data.avatar))) {
             onUpdate({ avatar: avatarList[predefinedIndex] });
        }
    }, [mode, data.gender, predefinedIndex, avatarList, onUpdate, data.avatar]);

    const handleCycle = (direction: 'prev' | 'next') => {
        const newIndex = direction === 'next'
            ? (predefinedIndex + 1) % avatarList.length
            : (predefinedIndex - 1 + avatarList.length) % avatarList.length;
        setPredefinedIndex(newIndex);
        onUpdate({ avatar: avatarList[newIndex] });
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setMode('custom');
            const reader = new FileReader();
            reader.onload = (e) => onUpdate({ avatar: e.target?.result as string });
            reader.readAsDataURL(file);
        }
    };
    
    const handleGenerateAvatar = async (prompt: string, style: 'Photoreal' | 'Anime') => {
        setIsGenerateModalOpen(false);
        // setToast({ title: "Avatar Generation", message: "Avatar photo generation request sent. Please wait a moment for the result." });
        setIsSelectModalOpen(true);
        setIsGenerating(true);
    
        try {
            const genderPrefix = data.gender ? `${data.gender}, ` : '';
            const finalPrompt = genderPrefix + prompt;
            const result = await generateAvatarImage(finalPrompt, style);
            // Save every generated avatar to the soul's selfie list
            const newSelfie: Selfie = {
                id: `selfie-creation-${Date.now()}`,
                url: result.url,
                tags: [],
                timestamp: new Date().toISOString()
            };
            onUpdate({ selfies: [...(data.selfies || []), newSelfie] });
            setGeneratedAvatars(prev => [result, ...prev]);
        } catch (error) {
            console.error("Avatar generation failed:", error);
            setToast({ title: "Generation Failed", message: `Sorry, there was an error generating the avatar. Please try again.` });
            if (generatedAvatars.length === 0) {
              setIsSelectModalOpen(false);
            }
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSelectGeneratedAvatar = (avatarUrl: string) => {
        onUpdate({ avatar: avatarUrl, physicalAppearanceDescription: '' }); // Reset description for new avatar
        setMode('custom');
        setIsSelectModalOpen(false);
    };

    const handleGenerateDescription = async () => {
        if (!data.avatar || !data.avatar.startsWith('data:image')) return;
        setIsGeneratingDescription(true);
        try {
            const mimeType = data.avatar.substring(5, data.avatar.indexOf(';'));
            const base64Data = data.avatar.split(',')[1];
            const description = await generateAvatarDescriptionFromImage(base64Data, mimeType);
            onUpdate({ physicalAppearanceDescription: description });
        } catch (error) {
            console.error("Failed to generate description:", error);
            setToast({ title: "Error", message: "Failed to generate description from image." });
        } finally {
            setIsGeneratingDescription(false);
        }
    };
    
    const isCustomModeReady = mode === 'custom' && data.avatar && !avatarList.includes(data.avatar);
    
    const handleNextClick = () => {
        if (isCustomModeReady && (!data.physicalAppearanceDescription || data.physicalAppearanceDescription.trim() === '')) {
            setValidationError('A physical appearance description is required for custom avatars.');
            return;
        }
        setValidationError('');
        onNext();
    }
    
    const guidelinesText = `Your avatar should have their face clearly visible, ideally facing front, and not too close-up. The avatar & description will be used in the selfies, so your Kindroid knows what it looks like. Please note uploading images of real people whose appearances you don't own (e.g. anyone not you) is against our Terms.`;

    return (
        <>
            <GenerateAvatarModal 
                isOpen={isGenerateModalOpen}
                onClose={() => setIsGenerateModalOpen(false)}
                onConfirm={handleGenerateAvatar}
            />
            <SelectGeneratedAvatarModal
                isOpen={isSelectModalOpen}
                onClose={() => setIsSelectModalOpen(false)}
                isLoading={isGenerating}
                generatedAvatars={generatedAvatars}
                onSelect={handleSelectGeneratedAvatar}
                onRegenerate={() => {
                    setIsSelectModalOpen(false);
                    setIsGenerateModalOpen(true);
                }}
            />

            <div className="flex flex-col items-center justify-start text-neutral-200 p-4">
                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                <div className="w-full max-w-lg mx-auto">
                    <ProgressBar currentStep={2} totalSteps={4} />

                    <div className="text-center mb-8">
                        <h1 className="text-4xl font-bold text-white">Your Soul's Look</h1>
                        <p className="mt-2 text-neutral-400">What should your {data.name || 'Soul'} look like?</p>
                    </div>
                    
                    <div className="flex bg-neutral-800 rounded-full p-1.5 mb-6 max-w-sm mx-auto">
                        <button onClick={() => setMode('predefined')} className={`py-2 rounded-full text-sm font-semibold transition-colors flex-1 ${mode === 'predefined' ? 'bg-gradient-cyan-purple text-white' : 'text-neutral-400'}`}>Predefined</button>
                        <button onClick={() => setMode('custom')} className={`py-2 rounded-full text-sm font-semibold transition-colors flex-1 ${mode === 'custom' ? 'bg-gradient-cyan-purple text-white' : 'text-neutral-400'}`}>Custom</button>
                    </div>

                    <div className="p-px bg-gradient-cyan-purple rounded-lg mb-6">
                        <button
                            onClick={() => setIsGenerateModalOpen(true)}
                            className="w-full flex items-center justify-center gap-2 py-3 rounded-[7px] bg-[#1c1c1c] font-semibold text-white hover:bg-transparent transition-colors"
                        >
                            <WandSparklesIcon className="w-5 h-5" />
                            <span className="font-semibold">Generate an avatar</span>
                        </button>
                    </div>

                    {mode === 'predefined' ? (
                        <div className="flex items-center justify-center gap-2 mb-6 h-64">
                            <button onClick={() => handleCycle('prev')} className="p-2 rounded-full bg-neutral-700 hover:bg-neutral-600"><ChevronLeftIcon /></button>
                            <img src={avatarList[predefinedIndex]} alt="Predefined Avatar" className="w-64 h-64 rounded-lg object-cover border-2 border-neutral-700"/>
                            <button onClick={() => handleCycle('next')} className="p-2 rounded-full bg-neutral-700 hover:bg-neutral-600"><ChevronRightIcon /></button>
                        </div>
                    ) : (
                        isCustomModeReady ? (
                            <div className="space-y-6">
                                <div className="relative w-full aspect-square max-w-sm mx-auto bg-neutral-800 rounded-xl overflow-hidden">
                                    <img src={data.avatar!} alt="Avatar preview" className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                                        {Array(9).fill(0).map((_, i) => <div key={i} className="border border-white/10"></div>)}
                                    </div>
                                </div>
                                <div className="space-y-1 text-center">
                                    <button onClick={() => setShowGuidelines(p => !p)} className="text-sm text-neutral-400 hover:text-white underline">
                                        {showGuidelines ? 'Hide' : 'Show'} photo tips and guidelines
                                    </button>
                                    {showGuidelines && <p className="text-xs text-neutral-500">{guidelinesText}</p>}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-neutral-400 mb-2">What style is your avatar?</label>
                                    <div className="flex gap-2">
                                        <button onClick={() => onUpdate({ avatarStyle: 'Photoreal' })} className={`py-2 px-4 rounded-full text-sm font-medium transition-colors flex-1 ${data.avatarStyle === 'Photoreal' ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-700 hover:bg-neutral-600'}`}>Photoreal</button>
                                        <button onClick={() => onUpdate({ avatarStyle: 'Anime' })} className={`py-2 px-4 rounded-full text-sm font-medium transition-colors flex-1 ${data.avatarStyle === 'Anime' ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-700 hover:bg-neutral-600'}`}>Anime</button>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-neutral-400 mb-2">Describe the physical appearance (max 800 chars).</label>
                                    <div className="relative">
                                        <textarea
                                            value={data.physicalAppearanceDescription || ''}
                                            onChange={e => { onUpdate({ physicalAppearanceDescription: e.target.value }); if(validationError) setValidationError(''); }}
                                            maxLength={800}
                                            rows={4}
                                            placeholder="white hair, short, long hair, slight tan, ..."
                                            className={`w-full bg-neutral-700/60 border rounded-lg p-3 pr-10 focus:ring-2 focus:outline-none text-sm ${validationError ? 'border-red-500 ring-red-500/50' : 'border-neutral-600 focus:ring-purple-500'}`}
                                        />
                                        <button
                                            type="button"
                                            onClick={handleGenerateDescription}
                                            disabled={isGeneratingDescription}
                                            className="absolute top-2 right-2 p-1.5 rounded-full text-neutral-400 hover:text-white bg-neutral-700/80 hover:bg-neutral-600/80 disabled:opacity-50"
                                            aria-label="Generate description from image"
                                        >
                                            {isGeneratingDescription ? <LoadingSpinner className="w-5 h-5"/> : <WandSparklesIcon className="w-5 h-5"/>}
                                        </button>
                                    </div>
                                    <p className="text-right text-xs text-neutral-500 mt-1">{(data.physicalAppearanceDescription || '').length} / 800</p>
                                    {validationError && <p className="text-xs text-red-400 mt-1">{validationError}</p>}
                                </div>
                                <CollapsibleSection title="Face Detail" description="In photoreal will add more realistic detail to the face, at some expense of consistency of avatar image.">
                                    <div className="space-y-4 pt-4">
                                        <p className="text-xs text-neutral-400">Set this low for more face structure consistency, and high for more detailed freckles, eye colors, beauty marks, etc, but more varied facial structures.</p>
                                        <div>
                                            <label className="block text-sm font-medium text-neutral-300 mb-2">Face detail enhance: {Math.round((data.faceDetailEnhance || 0) * 100)}%</label>
                                            <Slider min={0} max={1} step={0.01} value={data.faceDetailEnhance || 0} onChange={(val) => onUpdate({ faceDetailEnhance: val })} />
                                        </div>
                                         <div>
                                            <textarea value={data.faceDetailPrompt || ''} onChange={e => onUpdate({ faceDetailPrompt: e.target.value })} maxLength={200} rows={2} placeholder="freckles, piercing green eyes, ..." className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none text-sm"/>
                                            <p className="text-right text-xs text-neutral-500 mt-1">{(data.faceDetailPrompt || '').length} / 200</p>
                                        </div>
                                    </div>
                                </CollapsibleSection>
                                <CollapsibleSection title="Avatar Boost" description="Avatar boost enhances the likeness of your images using your provided reference photos." note={<p className="text-yellow-300">Avatar boost is not available during creation flow and will be available in avatar settings once the AI is created.</p>}>
                                    <div />
                                </CollapsibleSection>
                            </div>
                        ) : (
                            <div className="w-full h-64 border-2 border-dashed border-neutral-600 rounded-2xl flex items-center justify-center p-4">
                                <button onClick={() => fileInputRef.current?.click()} className="bg-neutral-700 hover:bg-neutral-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
                                    Upload Photo
                                </button>
                            </div>
                        )
                    )}

                    <div className="flex justify-between items-center mt-12">
                        <button onClick={onBack} className="py-3 px-10 rounded-full text-neutral-400 font-semibold transition-colors bg-neutral-800/60 hover:bg-neutral-700">
                            Back
                        </button>
                        <button 
                            onClick={handleNextClick}
                            className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                        >
                            Next
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};
