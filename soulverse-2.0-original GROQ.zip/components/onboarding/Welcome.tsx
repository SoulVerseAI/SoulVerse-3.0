import React, { useState, useMemo, useEffect } from "react";
import Select from "react-select";
import { Gender } from "../../types";
import { FunctionWindow } from "../ui/FunctionWindow";

interface WelcomeProps {
  onNext: (data: {
    name: string;
    gender: Gender;
    avatar: string | null;
  }) => void;
  onExit: () => void;
  error: string;
  clearError: () => void;
}

const portraits = {
  female: [
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(1).png?alt=media&token=723e5b49-e42a-4cf9-a78e-b551ebcc5c01',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(2).png?alt=media&token=cdf5d35f-8c38-4e5e-9df4-8641ed16a1a5',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(3).png?alt=media&token=a18cb454-e9ea-43c0-81db-30aae6ae9ef3',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(4).png?alt=media&token=6d981e24-a5a8-4a1f-a56d-ca872af03dd5',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Ffemale%2Ffemale%20(5).png?alt=media&token=d8449b88-5c1a-47c8-ba32-e6e3b5b58138',
  ],
  male: [
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(1).png?alt=media&token=a7b9463b-6210-403d-af65-def39c67552d',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(2).png?alt=media&token=c382eba4-0dd9-4374-9a69-43e590cb10f7',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(4).png?alt=media&token=8bd934a0-948f-49ae-85ec-b202271ba2dc',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(5).png?alt=media&token=72b86d08-f108-4326-af28-a730bee9191b',
    'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FUser%20Portrait%2Fmale%2Fmale%20(6).png?alt=media&token=f139d255-2b8d-4509-9c5f-e52eaca6bf9a',
  ],
};

const PortraitButton: React.FC<{ src: string; isSelected: boolean; onClick: () => void; disabled?: boolean }> = ({ src, isSelected, onClick, disabled }) => (
    <button
        onClick={onClick}
        disabled={disabled}
        className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all duration-200
            ${isSelected ? 'border-purple-500 scale-105 ring-2 ring-purple-400/50' : 'border-neutral-700'}
            ${!disabled ? 'hover:border-neutral-500' : ''}
            ${disabled ? 'filter grayscale cursor-not-allowed opacity-50' : 'cursor-pointer'}
        `}
    >
        <img src={src} alt="Portrait option" className="w-full h-full object-cover" />
    </button>
);


export const Welcome: React.FC<WelcomeProps> = ({ onNext, onExit, error, clearError }) => {
  const [name, setName] = useState("");
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [gender, setGender] = useState<Gender>(null);
  const [ageWarning, setAgeWarning] = useState<string>("");
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
  const [prevGender, setPrevGender] = useState<Gender>(gender);

  if (gender !== prevGender) {
    setPrevGender(gender);
    if (gender === 'Male') {
      setSelectedAvatar(portraits.male[0]);
    } else if (gender === 'Female') {
      setSelectedAvatar(portraits.female[0]);
    } else if (gender === 'Nonbinary') {
      setSelectedAvatar(portraits.female[0]);
    } else {
      setSelectedAvatar(null);
    }
  }

  const handleSelectAvatar = (url: string) => {
    setSelectedAvatar(url);
  };

  const isMalePortraitActive = gender === 'Male' || gender === 'Nonbinary';
  const isFemalePortraitActive = gender === 'Female' || gender === 'Nonbinary';

  const isNameValid = name.trim() !== '';
  const canProceed = isNameValid && gender !== null && selectedAvatar !== null;

  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString());
  // FIX: Replaced undefined variable 'y' with 'i'
  const years = Array.from({ length: 76 }, (_, i) => (2025 - i).toString());

  const customSelectStyles = {
    control: (base: any) => ({ ...base, backgroundColor: "#262626", borderColor: "#404040", padding: "2px", borderRadius: "8px", minHeight: "48px", boxShadow: "none", ":hover": { borderColor: "#6b21a8" }, }),
    singleValue: (base: any) => ({ ...base, color: "#fff" }),
    menu: (base: any) => ({ ...base, backgroundColor: "#262626", color: "#fff", marginTop: 4, borderRadius: "8px", zIndex: 9999, }),
    option: (base: any, { isFocused, isSelected }: any) => ({ ...base, backgroundColor: isSelected ? "#9333ea" : isFocused ? "#404040" : "transparent", color: "#fff", cursor: "pointer", }),
    dropdownIndicator: (base: any) => ({ ...base, color: "#a3a3a3", ":hover": { color: "#fff" }, }),
    indicatorSeparator: () => ({ display: "none" }),
    input: (base: any) => ({ ...base, color: "#fff" }),
    placeholder: (base: any) => ({ ...base, color: "#9ca3af", }),
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value);
    if (error) {
        clearError();
    }
  }

  return (
    <div className="relative flex flex-col h-full w-full bg-[#0D0517] text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
            <div className="absolute top-0 left-0 w-full h-full bg-cover bg-center" style={{backgroundImage: "url('https://firebasestorage.googleapis.com/v0/b/gen-lang-client-0176412501.firebasestorage.app/o/bg.png?alt=media&token=c1112b32-3b2d-4561-9c16-b84295e86d06')"}}></div>
            <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-purple-500/30 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-cyan-500/30 rounded-full blur-3xl animate-pulse animation-delay-400"></div>
        </div>
        <FunctionWindow isOpen={true} onClose={onExit} title="Character Creation">
            <div className="w-full max-w-lg mx-auto p-4 md:p-6 text-neutral-200">
                <div className="text-center mb-8 pt-4 md:pt-0">
                    <h1 className="text-4xl md:text-3xl font-bold text-white">Welcome! 🥳</h1>
                    <p className="mt-2 text-neutral-400">What should your Soul call you?</p>
                </div>
              
              <div className="space-y-6">
                <div>
                  <label htmlFor="your-name" className="text-sm font-medium text-neutral-400 mb-2 block"> Your name </label>
                  <input id="your-name" type="text" value={name} onChange={handleNameChange} className={`w-full bg-neutral-800 border rounded-lg p-3 focus:ring-2 focus:outline-none ${ isNameValid || name === "" ? "border-neutral-700 focus:ring-purple-500" : "border-red-500 focus:ring-red-500" }`} />
                  {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
                </div>

                <div>
                  <label className="text-sm font-medium text-neutral-400 mb-2 block"> Your birthday </label>
                  <div className="grid grid-cols-3 gap-3">
                    <Select options={days.map((d) => ({ value: d, label: d }))} value={day ? { value: day, label: day } : null} onChange={(option) => setDay(option?.value || "")} placeholder="Day" menuPlacement="auto" styles={customSelectStyles} />
                    <Select options={months.map((m) => ({ value: m, label: m }))} value={month ? { value: month, label: month } : null} onChange={(option) => setMonth(option?.value || "")} placeholder="Month" menuPlacement="auto" styles={customSelectStyles} />
                    <Select options={years.map((y) => ({ value: y, label: y }))} value={year ? { value: year, label: year } : null} onChange={(option) => { const selectedYear = option?.value || ""; setYear(selectedYear); if (parseInt(selectedYear, 10) >= 2009) { setAgeWarning("This application may contain content unsuitable for minors. By proceeding, you confirm you are of legal age and enter at your own risk."); } else { setAgeWarning(""); } }} placeholder="Year" menuPlacement="auto" styles={customSelectStyles} />
                  </div>
                  {ageWarning && ( <div className="mt-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-300"> {ageWarning} </div> )}
                </div>

                <div>
                  <label className="text-sm font-medium text-neutral-400 mb-2 block"> Your gender </label>
                  <div className="grid grid-cols-3 gap-3">
                    <button onClick={() => setGender("Male")} className={`py-3 rounded-lg font-semibold transition-colors ${ gender === "Male" ? "bg-gradient-cyan-purple text-white" : "bg-neutral-800 hover:bg-neutral-700" }`}> Male </button>
                    <button onClick={() => setGender("Female")} className={`py-3 rounded-lg font-semibold transition-colors ${ gender === "Female" ? "bg-gradient-cyan-purple text-white" : "bg-neutral-800 hover:bg-neutral-700" }`}> Female </button>
                    <button onClick={() => setGender("Nonbinary")} className={`py-3 rounded-lg font-semibold transition-colors ${ gender === "Nonbinary" ? "bg-gradient-cyan-purple text-white" : "bg-neutral-800 hover:bg-neutral-700" }`}> Nonbinary </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <label className="text-sm font-medium text-neutral-400 mb-2 block"> Select Your Portrait </label>
                <div className="grid grid-cols-5 gap-4 justify-items-center">
                    {portraits.female.map(url => (
                        <PortraitButton 
                            key={url} 
                            src={url} 
                            isSelected={selectedAvatar === url} 
                            onClick={() => handleSelectAvatar(url)}
                            disabled={!isFemalePortraitActive} 
                        />
                    ))}
                    {portraits.male.map(url => (
                        <PortraitButton 
                            key={url} 
                            src={url} 
                            isSelected={selectedAvatar === url} 
                            onClick={() => handleSelectAvatar(url)}
                            disabled={!isMalePortraitActive} 
                        />
                    ))}
                </div>
              </div>
              
              <p className="text-center text-xs text-neutral-500 mt-8 max-w-sm mx-auto">
                We use your preferred name, birthday, and gender so your Soul can address you in conversation properly.
              </p>

              <div className="flex justify-between items-center mt-12">
                <button onClick={onExit} className="py-2 px-6 rounded-full text-sm font-medium transition-colors hover:bg-neutral-800 text-neutral-400"> Exit </button>
                <button onClick={() => onNext({ name, gender, avatar: selectedAvatar })} disabled={!canProceed} className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"> Next </button>
              </div>
            </div>
        </FunctionWindow>
    </div>
  );
};