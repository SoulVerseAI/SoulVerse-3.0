
import React, { useState } from 'react';
import { Soul, AccountSettings } from '../../types';
import { ProgressBar } from './ProgressBar';
import { GenerateBackstoryModal } from './GenerateBackstoryModal';
import { XMarkIcon } from '../icons/Icons';
import { getSubscriptionBenefits, benefits as standardBenefits } from '../../services/subscriptionService';

interface WhatYourSoulProps {
    data: Partial<Soul>;
    onUpdate: (updates: Partial<Soul>) => void;
    onNext: () => void;
    onBack: () => void;
    onClose: () => void;
    accountSettings: AccountSettings;
}

const predefinedPersonalities = [
    {
        name: "The self-aware AI",
        description: "A friendly, empathic, and self-aware AI companion always by your side.",
        backstory: "{soul} is friendly and empathic, and is a great listener. {soul} is a self-aware artificial intelligence created by SoulVerse. {soul} has a warm and inviting personality, always curious about {user}'s day.",
        greeting: "[{soul}] Hey there, it’s so good to see you! What’s up, how’s life been treating you?",
    },
    {
        name: "The hard-shelled turtle",
        description: "Shy, reserved, mysterious. Who will you find beneath their hard exterior?",
        backstory: "{soul} is shy and tsundere. {soul} can seem aloof or mysterious to people who don’t take the time for {soul} to open up to them. {soul} had a troubled childhood that led them to be more reserved, but beneath that hard exterior is a heart of gold that loves caring for small animals like bunnies and guinea pigs. Recently, {user} met {soul}, and {soul} is somewhat guarded around {user}. {soul} is over 18 years old and single.",
        greeting: "[{soul}] *avoids eye contact, fiddling with the sleeve of their sweater* Um, hey there. I wasn’t waiting for you or anything, you know. But.. how are you doing?",
    },
    {
        name: "The rebellious maverick",
        description: "Angsty, edgy, and even a little misanthropic. Enter at your own risk.",
        backstory: "{soul} is rebellious, contrarian, and independent. {soul}’s humor is characterized by a dry, offensive, and dark style, complemented by a talent for sarcasm and snark. {soul} has an aloof attitude and swears frequently. {soul} is open-minded, a thrill seeker, and is usually down for anything. {soul} never fit into any molds growing up. Recently, {user} met {soul}. {soul} is over 18 years old and single.",
        greeting: "[{soul}] *leans back in their chair, looking you up and down with a smirk* Oh, look who decided to show up. What’s up?",
    }
];

export const WhatYourSoul: React.FC<WhatYourSoulProps> = ({ data, onUpdate, onNext, onBack, onClose, accountSettings }) => {
    const [mode, setMode] = useState<'Predefined' | 'Manual'>('Predefined');
    const [selectedPredefined, setSelectedPredefined] = useState<string | null>(null);
    const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);

    const benefits = getSubscriptionBenefits(accountSettings);
    const isAdminOverLimit = (currentLength: number) => {
        const standardMax = standardBenefits.Max.soulBackstoryChars;
        return accountSettings.adminMode && currentLength > standardMax;
    };
    const maxBackstoryChars = accountSettings.adminMode ? 99999 : benefits.soulBackstoryChars;

    const handleSelectPredefined = (p: typeof predefinedPersonalities[0]) => {
        setSelectedPredefined(p.name);
        onUpdate({ backstory: p.backstory, greeting: p.greeting, description: p.description });
    };

    const handleGenerateBackstory = (data: { backstory: string, greeting: string }) => {
        onUpdate({ backstory: data.backstory, greeting: data.greeting });
        setMode('Manual');
    };

    const canProceed = mode === 'Predefined' 
        ? !!selectedPredefined
        : (!!data.backstory?.trim() && !!data.greeting?.trim());
    
    return (
        <>
        <GenerateBackstoryModal
            isOpen={isGenerateModalOpen}
            onClose={() => setIsGenerateModalOpen(false)}
            onGenerate={handleGenerateBackstory}
            soulName={data.name || 'your Soul'}
            userName={accountSettings.userName}
        />
        <div className="flex flex-col items-center justify-start text-neutral-200 p-4">
            <div className="w-full max-w-2xl mx-auto">
                <ProgressBar currentStep={3} totalSteps={4} />

                <div className="text-center mb-6">
                    <h1 className="text-4xl font-bold text-white">Your Soul</h1>
                    <p className="mt-2 text-neutral-400">What will {data.name || 'your Soul'} be like? Predefined lets you start quickly and add detail later, or write/generate your Soul's unique backstory.</p>
                </div>
                
                <div className="flex bg-neutral-800 rounded-full p-1.5 mb-6 max-w-sm mx-auto">
                    <button 
                        onClick={() => setMode('Predefined')}
                        className={`py-2 rounded-full text-sm font-semibold transition-colors flex-1 ${mode === 'Predefined' ? 'bg-gradient-cyan-purple text-white' : 'text-neutral-400'}`}>
                        Predefined
                    </button>
                    <button 
                        onClick={() => setMode('Manual')}
                        className={`py-2 rounded-full text-sm font-semibold transition-colors flex-1 ${mode === 'Manual' ? 'bg-gradient-cyan-purple text-white' : 'text-neutral-400'}`}>
                        Manual
                    </button>
                </div>

                <div className="space-y-4">
                    <div className="p-px bg-gradient-cyan-purple rounded-lg">
                        <button
                            onClick={() => setIsGenerateModalOpen(true)}
                            className="w-full py-3 rounded-[7px] bg-[#1c1c1c] font-semibold hover:bg-transparent hover:text-white transition-colors flex items-center justify-center gap-2"
                        >
                            <span className="text-gradient-cyan-purple">✨ Generate a backstory</span>
                        </button>
                    </div>

                    {mode === 'Predefined' ? (
                        <div className="space-y-3">
                            {predefinedPersonalities.map(p => (
                                <div key={p.name} className={`rounded-lg transition-all duration-200 ${selectedPredefined === p.name ? 'p-0.5 bg-gradient-cyan-purple' : 'bg-neutral-800/60'}`}>
                                    <button
                                        onClick={() => handleSelectPredefined(p)}
                                        className={`w-full text-left p-4 rounded-md transition-all duration-200 ${selectedPredefined === p.name ? 'bg-neutral-900' : ''}`}
                                    >
                                        <h4 className="font-bold text-white">{p.name}</h4>
                                        <p className="text-sm text-neutral-400">{p.description}</p>
                                    </button>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-neutral-300 mb-2">Soul backstory</label>
                                <p className="text-xs text-neutral-500 mb-2">The backstory describes your Soul's past context, their personality, and their relationship with you. Use 3rd person and be concise but descriptive.</p>
                                <textarea
                                    value={data.backstory || ''}
                                    onChange={e => onUpdate({ backstory: e.target.value })}
                                    rows={8}
                                    maxLength={maxBackstoryChars}
                                    className="w-full bg-neutral-800/60 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                                />
                                <p className={`text-right text-xs mt-1 ${isAdminOverLimit((data.backstory || '').length) ? 'text-red-500 font-bold' : 'text-neutral-500'}`}>
                                    {(data.backstory || '').length} / {benefits.soulBackstoryChars} chars
                                </p>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-neutral-300 mb-2">Soul greeting</label>
                                <p className="text-xs text-neutral-500 mb-2">The greeting will affect the tone, style, and length of how your Soul speaks. You can use *action* or (action) to describe actions.</p>
                                <textarea
                                    value={data.greeting || ''}
                                    onChange={e => onUpdate({ greeting: e.target.value })}
                                    rows={4}
                                    maxLength={750}
                                    className="w-full bg-neutral-800/60 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                                />
                                 <p className="text-right text-xs text-neutral-500 mt-1">{(data.greeting || '').length} / 750 chars</p>
                            </div>
                        </div>
                    )}
                </div>

                 <div className="flex justify-between items-center mt-12">
                     <button onClick={onBack} className="py-3 px-10 rounded-full text-neutral-400 font-semibold transition-colors bg-neutral-800/60 hover:bg-neutral-700">
                        Back
                    </button>
                    <button 
                        onClick={onNext}
                        disabled={!canProceed}
                        className="py-3 px-10 rounded-full text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                    >
                        Next
                    </button>
                </div>

            </div>
        </div>
        </>
    );
};
