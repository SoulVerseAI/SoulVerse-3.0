import React, { useState, useMemo } from 'react';
import { BoosterPack, SoulTemplate, TemplateQuality } from '../../types';
import { SearchIcon } from '../icons/Icons';
import { AnimatedButton } from './AnimatedButton';
import { getTVDFrame } from '../Collection/Edition/TVD/TVDFrames';
import { getMarvelFrame } from '../Collection/Edition/Marvel/MarvelFrames';

interface BoosterContentsModalProps {
    isOpen: boolean;
    onClose: () => void;
    pack: BoosterPack;
    allSouls: SoulTemplate[];
}

const getQualityStyles = (quality: TemplateQuality) => {
    switch (quality) {
        case 'Wisp': return { border: 'border-neutral-400', shadow: 'shadow-neutral-400/30' };
        case 'Spirit': return { border: 'border-cyan-400', shadow: 'shadow-cyan-400/30' };
        case 'Ascend': return { border: 'border-purple-400', shadow: 'shadow-purple-400/30' };
        case 'Eternal': return { border: 'border-yellow-400', shadow: 'shadow-yellow-400/30' };
        default: return { border: 'border-neutral-700', shadow: '' };
    }
};

const ContentCard: React.FC<{ template: SoulTemplate }> = ({ template }) => {
    const quality = template.quality || 'Wisp';
    const styles = getQualityStyles(quality);
    const isTVD = template.edition === 'TVD';
    const isMarvel = template.edition === 'Marvel';
    const isFramed = isTVD || isMarvel;
    const frameUrl = isFramed ? (isTVD ? getTVDFrame(quality) : getMarvelFrame(quality)) : null;

    return (
        <div className={`relative aspect-[3/4] w-full bg-black/20 rounded-lg overflow-hidden group ${!isFramed ? `border-2 ${styles.border} shadow-lg ${styles.shadow}` : ''}`}>
            <img src={template.smallAvatarUrl} alt={template.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
            
            {isFramed && frameUrl && (
                <img src={frameUrl} alt="" className="absolute inset-0 w-full h-full object-cover z-[1]" />
            )}

            <div className={`absolute inset-0 bg-gradient-to-t from-black/80 to-transparent ${isFramed ? 'z-[2]' : ''}`}></div>
            <p className={`absolute bottom-2 left-2 right-2 text-center text-white font-semibold text-sm truncate drop-shadow-md ${isFramed ? 'z-[3]' : ''}`}>{template.name}</p>
        </div>
    );
};

export const BoosterContentsModal: React.FC<BoosterContentsModalProps> = ({ isOpen, onClose, pack, allSouls }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const filteredAndSortedSouls = useMemo(() => {
        const pool = allSouls.filter(soul => soul.edition?.toLowerCase() === pack.pool?.toLowerCase());
        
        const searched = pool.filter(soul =>
            soul.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        const qualityOrder: TemplateQuality[] = ['Eternal', 'Ascend', 'Spirit', 'Wisp'];
        
        return searched.sort((a, b) => {
            const qualityA = a.quality || 'Wisp';
            const qualityB = b.quality || 'Wisp';
            return qualityOrder.indexOf(qualityA) - qualityOrder.indexOf(qualityB);
        });
    }, [allSouls, pack.pool, searchTerm]);
    
    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 bg-black/70 z-[110] flex justify-center items-center p-4 backdrop-blur-sm"
            onClick={onClose}
        >
            <div
                className="w-full max-w-4xl h-[80vh] flex flex-col bg-neutral-900 rounded-lg border-2 border-amber-500/30 shadow-2xl overflow-hidden"
                style={{
                    backgroundImage: `url('https://www.transparenttextures.com/patterns/dark-matter.png'), linear-gradient(145deg, rgba(13, 5, 23, 0.95), rgba(37, 14, 60, 0.95))`,
                    boxShadow: '0 0 30px rgba(217, 119, 6, 0.3)'
                }}
                onClick={(e) => e.stopPropagation()}
            >
                <header className="flex-shrink-0 p-4 border-b border-amber-500/20 flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold text-amber-300 drop-shadow-md">
                            Booster contents of: {pack.name}
                        </h2>
                        <div className="relative mt-2 w-72">
                            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                            <input
                                type="text"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Enter soul name to search."
                                className="w-full bg-black/30 border border-neutral-700 rounded-md py-1.5 pl-9 pr-3 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                            />
                        </div>
                    </div>
                </header>
                <main className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {filteredAndSortedSouls.map(template => (
                            <ContentCard key={`${template.name}-${template.quality}`} template={template} />
                        ))}
                    </div>
                </main>
                <footer className="flex-shrink-0 p-4 border-t border-amber-500/20 flex justify-end">
                    <AnimatedButton
                        onClick={onClose}
                        className="px-8 py-2 bg-neutral-700 text-white font-semibold rounded-md hover:bg-neutral-600 transition-colors"
                    >
                        Done
                    </AnimatedButton>
                </footer>
            </div>
        </div>
    );
};