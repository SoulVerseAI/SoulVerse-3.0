
import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';

interface MenuItem {
  label: string;
  action: () => void;
}

interface LoaderContextMenuProps {
  isOpen: boolean;
  items: MenuItem[];
  onClose: () => void;
  triggerRef: React.RefObject<HTMLElement>;
}

export const LoaderContextMenu: React.FC<LoaderContextMenuProps> = ({ isOpen, items, onClose, triggerRef }) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ top: 0, left: 0, opacity: 0 });

  useEffect(() => {
    if (isOpen && triggerRef.current && menuRef.current) {
      const triggerRect = triggerRef.current.getBoundingClientRect();
      const menuRect = menuRef.current.getBoundingClientRect();

      let top = triggerRect.bottom + 8; // A little space below
      let left = triggerRect.left;

      if (top + menuRect.height > window.innerHeight) {
        top = triggerRect.top - menuRect.height - 8;
      }

      if (left + menuRect.width > window.innerWidth) {
        left = triggerRect.right - menuRect.width;
      }
      
      if (left < 0) left = 0;

      requestAnimationFrame(() => {
        setPosition({ top: top + window.scrollY, left: left + window.scrollX, opacity: 1 });
      });
    }
  }, [isOpen, triggerRef]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isOpen &&
        menuRef.current && !menuRef.current.contains(event.target as Node) &&
        triggerRef.current && !triggerRef.current.contains(event.target as Node)
      ) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose, triggerRef]);

  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <div
      ref={menuRef}
      className="fixed bg-white rounded-lg shadow-lg z-[200] py-2 transition-opacity duration-150 w-48"
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
        opacity: position.opacity
      }}
    >
      {items.map((item, index) => (
        <button
          key={index}
          onClick={() => {
            item.action();
            onClose();
          }}
          className="w-full px-4 py-2 text-sm text-black text-left hover:bg-neutral-100"
        >
          {item.label}
        </button>
      ))}
    </div>,
    document.body
  );
};
