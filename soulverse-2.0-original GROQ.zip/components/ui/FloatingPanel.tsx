
import React, { useRef, useEffect } from 'react';
import { XMarkIcon } from '../icons/Icons';

interface FloatingPanelProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
}

export const FloatingPanel: React.FC<FloatingPanelProps> = ({ isOpen, onClose, title, children, maxWidth = 'max-w-md' }) => {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/60 z-50 flex justify-center items-center p-4 backdrop-blur-sm"
      aria-labelledby="floating-panel-title"
      role="dialog"
      aria-modal="true"
    >
      <div
        ref={panelRef}
        className={`w-full ${maxWidth} rounded-xl shadow-2xl flex flex-col max-h-[80vh] overflow-hidden border border-white/10 bg-gradient-to-b from-cyan-800/60 to-purple-900/60 backdrop-blur-xl`}
      >
        <header className="flex justify-between items-center p-4 border-b border-cyan-500/20 flex-shrink-0 bg-black/20">
          <h3 id="floating-panel-title" className="font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="p-1 rounded-full text-neutral-400 hover:bg-neutral-700">
            <XMarkIcon className="w-5 h-5" />
          </button>
        </header>
        <div className="overflow-y-auto custom-scrollbar">
          {children}
        </div>
      </div>
    </div>
  );
};
