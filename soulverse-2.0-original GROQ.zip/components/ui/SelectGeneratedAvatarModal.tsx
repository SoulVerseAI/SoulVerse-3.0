
import React from 'react';
import { Modal } from './Modal';
import { LoadingSpinner, TrashIcon, XMarkIcon } from '../icons/Icons';

interface SelectGeneratedAvatarModalProps {
    isOpen: boolean;
    onClose: () => void;
    isLoading: boolean;
    generatedAvatars: { url: string; prompt: string }[];
    onSelect: (avatarUrl: string) => void;
    onRegenerate: () => void;
}

export const SelectGeneratedAvatarModal: React.FC<SelectGeneratedAvatarModalProps> = ({ 
    isOpen, 
    onClose, 
    isLoading, 
    generatedAvatars, 
    onSelect,
    onRegenerate
}) => {
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Select Generated Avatar">
            <div className="p-4 md:p-6 text-neutral-300 space-y-4">
                <p className="text-sm">
                    Select an existing avatar, or <button onClick={onRegenerate} className="text-blue-400 underline hover:text-blue-300">generate a new one</button>.
                </p>
                <div className="grid grid-cols-2 gap-4 min-h-[200px]">
                    {isLoading && (
                        <div className="col-span-2 flex flex-col items-center justify-center text-center p-8">
                            <LoadingSpinner className="w-12 h-12 text-purple-400"/>
                            <p className="mt-4 text-neutral-400">Generating...</p>
                        </div>
                    )}
                    {generatedAvatars.map((avatar, index) => (
                        <div key={index} className="relative group">
                            <button 
                                onClick={() => onSelect(avatar.url)}
                                className="aspect-square w-full rounded-lg overflow-hidden border-2 border-transparent group-hover:border-purple-500 transition-all"
                            >
                                <img src={avatar.url} alt={`Generated Avatar ${index + 1}`} className="w-full h-full object-cover" />
                            </button>
                            <p className="mt-1 text-xs text-neutral-400 truncate">{avatar.prompt}</p>
                            <button className="absolute top-2 right-2 p-1.5 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                                <TrashIcon className="w-4 h-4" />
                            </button>
                        </div>
                    ))}
                </div>
                <div className="text-center text-sm text-neutral-500 pt-4 border-t border-neutral-700">
                    Load More
                </div>
            </div>
        </Modal>
    );
};
