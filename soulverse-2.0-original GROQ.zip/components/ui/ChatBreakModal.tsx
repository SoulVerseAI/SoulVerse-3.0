
import React, { useState, useEffect } from 'react';
import { Modal } from './Modal';
import { Toggle } from './Toggle';
import { XMarkIcon } from '../icons/Icons';

interface ChatBreakModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (newGreeting: string, resetMemory: boolean) => void;
  soulName: string;
}

const Explanation: React.FC<{ title: string, children: React.ReactNode, note: string }> = ({ title, children, note }) => (
    <div className="bg-neutral-800/50 p-4 rounded-lg border border-neutral-700 h-full flex flex-col">
        <h4 className="font-semibold text-white">{title}</h4>
        <div className="text-sm text-neutral-400 mt-2 space-y-2 flex-grow">{children}</div>
        <p className="text-xs text-cyan-400 mt-3">{note}</p>
    </div>
);


export const ChatBreakModal: React.FC<ChatBreakModalProps> = ({ isOpen, onClose, onConfirm, soulName }) => {
  const [newGreeting, setNewGreeting] = useState('');
  const [resetMemory, setResetMemory] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [prevIsOpen, setPrevIsOpen] = useState(isOpen);

  if (isOpen !== prevIsOpen) {
    setPrevIsOpen(isOpen);
    if (!isOpen) {
      setNewGreeting('');
      setResetMemory(false);
      setError(null);
    }
  }

  const handleConfirm = () => {
    // A greeting is no longer mandatory for a chat break.
    // If empty, the soul's default greeting will be used.
    // We keep the length check to prevent overly long greetings.
    if (newGreeting.length > 2000) {
      setError('Greeting message cannot exceed 2000 characters.');
      return;
    }
    setError(null);
    onConfirm(newGreeting, resetMemory);
  };
  
  const handleGreetingChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewGreeting(e.target.value);
    if (error) {
      setError(null);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Chat break" maxWidth="max-w-5xl" closeOnBackdropClick={false}>
      <div className="p-6 space-y-6 bg-[#1c1c1c] text-neutral-300">
        {error && (
          <div className="bg-red-500/20 text-red-300 p-3 rounded-lg flex items-center justify-between text-sm">
            <span>⚠️ {error}</span>
            <button onClick={() => setError(null)} className="p-1 -m-1 rounded-full hover:bg-red-500/30">
              <XMarkIcon className="w-4 h-4" />
            </button>
          </div>
        )}
        <div className="space-y-2 text-sm text-neutral-400">
          <p>
            Chat break lets you reset the conversation's memory. This is useful when your Soul gets off track or when you want to start a new scene.
          </p>
          <p>
            Below, enter the greeting message you want <span className="font-semibold text-neutral-200">{soulName} to say to you</span> to start the new conversation; this message will set the tone for the new scene. If left blank, the Soul's default greeting will be used.
          </p>
        </div>
        
        <textarea
          value={newGreeting}
          onChange={handleGreetingChange}
          rows={5}
          maxLength={2000}
          className="w-full bg-neutral-800 border border-neutral-700 rounded-xl p-4 focus:ring-2 focus:ring-purple-500 focus:outline-none placeholder:text-neutral-500"
          placeholder={`Your ${soulName}'s new greeting message (optional)`}
        />

        <div className="grid md:grid-cols-2 gap-4">
            <Explanation title="1. Chat Break (Soft Reset)" note="👉 Use this for a soft reset to refresh the current scene.">
                <ul className="list-disc list-inside space-y-1">
                    <li>Deletes the last 30 messages from the visible chat history.</li>
                    <li>The AI's long-term memory (Recall Memories) remains intact.</li>
                    <li>Backstory and key memories are unaffected.</li>
                </ul>
            </Explanation>
            <Explanation title="2. Chat Break + MEMORY WIPE (Hard Reset)" note="👉 Use this for a hard reset to start a completely new topic.">
                <ul className="list-disc list-inside space-y-1">
                    <li>Deletes ALL chat history from the interface and the AI's memory.</li>
                    <li>Deletes ALL Recall Memories, giving the AI a "clean slate".</li>
                    <li>The Soul will rely only on its core identity (Backstory, Key Memories).</li>
                </ul>
            </Explanation>
        </div>

        <div className="flex items-center justify-center pt-2">
             <Toggle checked={resetMemory} onChange={setResetMemory} />
             <span className={`ml-3 font-semibold ${resetMemory ? 'text-red-400' : 'text-neutral-400'}`}>
                MEMORY WIPE
             </span>
        </div>

        <div className="text-xs p-3 bg-neutral-900/50 border border-neutral-700/60 rounded-md text-neutral-500 text-center">
            <strong>Important:</strong> A soft reset modifies your recent visible chat history. A hard reset (MEMORY WIPE) will delete your entire visible chat history and all of your Soul's recallable memories.
        </div>
        
        <div className="pt-2">
            <button 
                onClick={handleConfirm} 
                className="w-full py-3 rounded-full font-semibold text-lg text-white bg-gradient-cyan-purple hover:opacity-90 transition-opacity"
            >
                Confirm
            </button>
        </div>
      </div>
    </Modal>
  );
};
