import React, { useState } from 'react';
import { ChevronDownIcon } from '../icons/Icons';

interface CollapsibleSectionProps {
  title: React.ReactNode;
  children: React.ReactNode;
  description?: React.ReactNode;
  note?: React.ReactNode;
  isOpen?: boolean;
  onToggle?: () => void;
}

export const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({ title, children, description, note, isOpen: externalIsOpen, onToggle: externalOnToggle }) => {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;
  const onToggle = externalOnToggle || (() => setInternalIsOpen(prev => !prev));

  return (
    <div className="py-1">
      <button
        onClick={onToggle}
        className="w-full flex justify-between items-center p-2 text-left hover:bg-transparent focus:outline-none"
        aria-expanded={isOpen}
      >
        {title}
      </button>
      {description && (
        <div className="px-2 pb-1 text-sm text-neutral-500 -mt-1">
            {description}
        </div>
      )}
      <div className={`grid transition-all duration-300 ease-in-out ${isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}>
          <div className="overflow-hidden">
              <div className="pt-2 pl-4 pr-2 pb-2">
                {note && (
                    <div className="mb-4 text-sm text-red-400">
                        {note}
                    </div>
                )}
                {children}
              </div>
          </div>
      </div>
    </div>
  );
};
