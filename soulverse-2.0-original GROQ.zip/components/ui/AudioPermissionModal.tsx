import React from 'react';
import { Modal } from './Modal';
import { SpeakerWaveIcon } from '../icons/Icons';

export const AudioPermissionModal: React.FC<{
  isOpen: boolean;
  onAllow: () => void;
  onDeny: () => void;
}> = ({ isOpen, onAllow, onDeny }) => {
  return (
    <Modal isOpen={isOpen} onClose={onDeny} title="Audio Playback" maxWidth="max-w-lg">
      <div className="p-6 text-neutral-300 space-y-4 text-center">
        <SpeakerWaveIcon className="w-12 h-12 mx-auto text-purple-400" />
        <p className="text-lg font-semibold text-white">Allow SoulVerse to play audio?</p>
        <p className="text-sm text-neutral-400">
          This enables features like Text-to-Speech for messages and background music. You can change this setting later.
        </p>
        <div className="flex justify-center gap-4 pt-4">
          <button onClick={onDeny} className="py-2 px-8 rounded-md text-sm font-medium transition-colors bg-neutral-700 hover:bg-neutral-600">
            Deny
          </button>
          <button onClick={onAllow} className="py-2 px-8 rounded-md text-sm font-medium transition-colors bg-blue-600 text-white hover:bg-blue-700">
            Allow
          </button>
        </div>
      </div>
    </Modal>
  );
};
