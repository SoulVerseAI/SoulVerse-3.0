
import React from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: React.ReactNode;
  children: React.ReactNode;
  maxWidth?: string;
  position?: 'center' | 'top';
  topDecoration?: React.ReactNode;
  headerClassName?: string;
  closeOnBackdropClick?: boolean;
}

export const Modal: React.FC<ModalProps> = ({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  maxWidth = 'max-w-2xl', 
  position = 'center', 
  topDecoration, 
  headerClassName,
  closeOnBackdropClick = true 
}) => {
  if (!isOpen) return null;

  const handleBackdropClick = () => {
    if (closeOnBackdropClick) {
      onClose();
    }
  };

  const backdropClasses = position === 'top' 
      ? 'items-start pt-20 pb-8 px-4' 
      : 'items-center p-4';

  const modalMaxHeight = position === 'top' ? 'max-h-[calc(100vh-7rem)]' : 'max-h-[calc(100vh-4rem)]';

  // Apply responsive max-width
  const responsiveMaxWidth = maxWidth.startsWith('max-w-') ? `md:${maxWidth}` : maxWidth;

  return (
    <div
      className={`fixed inset-0 bg-black/60 z-[100] flex justify-center ${backdropClasses}`}
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
      onClick={handleBackdropClick}
    >
      <div
        className={`relative bg-[#1c1c1c] rounded-xl shadow-2xl w-full max-w-sm ${responsiveMaxWidth} ${modalMaxHeight} flex flex-col overflow-hidden`}
        onClick={(e) => e.stopPropagation()} // Prevent click inside modal from closing it
      >
        {topDecoration}
        <header className={`relative flex items-center justify-center p-4 border-b border-neutral-700/60 flex-shrink-0 ${headerClassName || ''}`}>
          <h2 id="modal-title" className="text-xl font-semibold text-white text-center">{title}</h2>
          <button onClick={onClose} className="absolute top-1/2 -translate-y-1/2 right-4 p-1 rounded-full text-neutral-400 hover:bg-neutral-700/80 hover:text-white transition-transform duration-75 ease-out active:scale-[0.97]">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </header>
        <div className="overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
};
