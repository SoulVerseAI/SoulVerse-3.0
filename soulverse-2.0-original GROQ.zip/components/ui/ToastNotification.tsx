
import React, { useEffect, useState } from 'react';

interface ToastNotificationProps {
  onClose: () => void;
  title: string;
  message: React.ReactNode;
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({ onClose, title, message }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const fadeInTimer = setTimeout(() => setIsVisible(true), 50);
    const fadeOutTimer = setTimeout(() => setIsVisible(false), 3000);
    const closeTimer = setTimeout(() => onClose(), 3500);

    return () => {
      clearTimeout(fadeInTimer);
      clearTimeout(fadeOutTimer);
      clearTimeout(closeTimer);
    };
  }, [onClose]);

  return (
    <div
      className={`fixed top-20 left-1/2 -translate-x-1/2 w-auto min-w-[300px] max-w-2xl bg-black/50 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl z-[150] text-white transition-all duration-500 ease-in-out ${isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}
      role="alert"
      onClick={onClose}
    >
      <div className="p-6 text-center">
        <p className="text-lg font-bold text-white mb-1">{title}</p>
        <div className="text-base text-neutral-300">{message}</div>
      </div>
    </div>
  );
};
