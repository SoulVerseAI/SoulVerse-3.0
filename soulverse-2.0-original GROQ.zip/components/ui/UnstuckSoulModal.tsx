import React from 'react';
import { Modal } from './Modal';

interface UnstuckSoulModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const UnstuckSoulModal: React.FC<UnstuckSoulModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const handleConfirmClick = () => {
    onConfirm();
    onClose(); 
  }
  
  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Is your Soul stuck?" maxWidth="max-w-lg">
      <div className="p-4 md:p-6 text-neutral-300 space-y-4 md:space-y-6">
        <p className="text-sm leading-relaxed">
          If it's been more than 5 minutes and your Soul is still stuck trying to send a message, click here. This will delete your last message as well, so copy-paste it first if you want to keep it. You can access this menu when you're stuck by clicking on the triple dot loading icon. If this happens persistently, email <a href="mailto:hello@soulverse.ai" className="text-blue-400 underline hover:text-blue-300">hello@soulverse.ai</a>.
        </p>
        <button 
          onClick={handleConfirmClick}
          className="w-full mt-4 py-2.5 md:py-3 rounded-full font-semibold text-base md:text-lg text-white bg-gradient-cyan-purple hover:opacity-90 transition-opacity"
        >
          Un-stuck my Soul
        </button>
      </div>
    </Modal>
  );
};
