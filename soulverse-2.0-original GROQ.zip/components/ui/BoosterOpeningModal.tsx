import React, { useState, useEffect, useMemo, useRef } from 'react';
import { BoosterPack, SoulTemplate, TemplateQuality } from '../../types';
import { StarIcon } from '../icons/Icons';
import { getTVDFrame } from '../Collection/Edition/TVD/TVDFrames';
import { getMarvelFrame } from '../Collection/Edition/Marvel/MarvelFrames';

interface BoosterOpeningModalProps {
    isOpen: boolean;
    onClose: () => void;
    contents: SoulTemplate[];
    onClaim: (contents: SoulTemplate[]) => void;
    pack: BoosterPack | null;
}

const getQuality = (template: SoulTemplate): TemplateQuality => {
    if (template.quality === 'Eternal') return 'Eternal';
    if (template.quality === 'Ascend') return 'Ascend';
    if (template.quality === 'Spirit') return 'Spirit';
    return 'Wisp';
};

const getQualityStyles = (quality: TemplateQuality) => {
    switch (quality) {
        case 'Wisp': return { border: 'border-neutral-400', glow: 'shadow-[0_0_15px_2px_rgba(163,163,163,0.5)]', glowHover: 'hover:shadow-[0_0_25px_8px_rgba(163,163,163,0.7)]' };
        case 'Spirit': return { border: 'border-cyan-400', glow: 'shadow-[0_0_15px_2px_rgba(34,211,238,0.5)]', glowHover: 'hover:shadow-[0_0_25px_8px_rgba(34,211,238,0.7)]' };
        case 'Ascend': return { border: 'border-purple-400', glow: 'shadow-[0_0_15px_2px_rgba(192,132,252,0.5)]', glowHover: 'hover:shadow-[0_0_25px_8px_rgba(192,132,252,0.7)]' };
        case 'Eternal': return { border: 'border-yellow-400', glow: 'shadow-[0_0_15px_2px_rgba(251,191,36,0.5)]', glowHover: 'hover:shadow-[0_0_25px_8px_rgba(251,191,36,0.7)]' };
        default: return { border: 'border-neutral-700', glow: '', glowHover: '' };
    }
};

interface CardProps {
    template: SoulTemplate;
    isFlipped: boolean;
    onFlip: () => void;
    cardBackUrl?: string;
    style?: React.CSSProperties;
    className?: string;
}

const Card: React.FC<CardProps> = ({ template, isFlipped, onFlip, cardBackUrl, style, className }) => {
    const quality = getQuality(template);
    const styles = getQualityStyles(quality);
    const CARD_BACK_URL_DEFAULT = 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fcardback.png?alt=media&token=4ddb9e9c-7f2c-4349-aed5-92634a520163';
    const finalCardBackUrl = (template as any).cardBackUrl || cardBackUrl || CARD_BACK_URL_DEFAULT;

    const isTVD = template.edition === 'TVD';
    const isMarvel = template.edition === 'Marvel';
    const isFramed = isTVD || isMarvel;
    const frameUrl = isFramed ? (isTVD ? getTVDFrame(quality) : getMarvelFrame(quality)) : null;

    return (
        <div className={`w-36 md:w-48 aspect-[3/4] perspective-1000 ${className}`} onClick={onFlip} style={style}>
            <div className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
                {/* Back of the card */}
                <div className={`absolute w-full h-full backface-hidden z-10 cursor-pointer transition-transform hover:scale-105`}>
                    <img src={finalCardBackUrl} alt="Card back" className="w-full h-full object-contain drop-shadow-lg" />
                </div>
                {/* Front of the card */}
                <div className={`absolute w-full h-full backface-hidden rotate-y-180 bg-neutral-900 rounded-lg overflow-hidden ${!isFramed ? `border-2 ${styles.border} shadow-2xl ${styles.glow} ${styles.glowHover} transition-shadow` : ''}`}>
                    {isFramed && frameUrl ? (
                        <>
                            <img src={template.smallAvatarUrl} alt={template.name} className="absolute inset-0 w-full h-full object-cover" />
                            <img src={frameUrl} alt="" className="absolute inset-0 w-full h-full z-[1]" />
                        </>
                    ) : (
                        <img src={template.smallAvatarUrl} alt={template.name} className="w-full h-full object-cover" />
                    )}
                    <div className={`absolute inset-0 bg-gradient-to-t from-black/80 to-transparent ${isFramed ? 'z-[2]' : ''}`}></div>
                    <div className={`absolute bottom-0 left-0 right-0 p-2 text-left ${isFramed ? 'z-[3]' : ''}`}>
                        {template.label && !isFramed && (
                            <p className={`text-xs font-semibold uppercase tracking-wider -mb-1 ${template.label === 'Villain' ? 'text-red-400' : 'text-cyan-400'}`} style={{ textShadow: '0 1px 2px rgba(0,0,0,0.8)' }}>
                                {template.label}
                            </p>
                        )}
                        <p className="font-bold text-white text-sm truncate drop-shadow-md">{template.name}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const BoosterOpeningModal: React.FC<BoosterOpeningModalProps> = ({ isOpen, onClose, contents, onClaim, pack }) => {
    const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
    const [prevIsOpen, setPrevIsOpen] = useState(isOpen);

    if (isOpen !== prevIsOpen) {
        setPrevIsOpen(isOpen);
        if (isOpen) {
            setFlippedIndices([]);
        }
    }

    const handleFlip = (index: number) => {
        if (flippedIndices.includes(index)) return;
        setFlippedIndices(prev => [...prev, index]);
    };

    const allFlipped = useMemo(() => 
        contents.length > 0 && flippedIndices.length === contents.length
    , [contents.length, flippedIndices.length]);
    
    if (!isOpen) return null;

    const cardPositions = [
        { top: '15%', left: '25%', transform: 'translate(-50%, 0)' },
        { top: '15%', left: '50%', transform: 'translate(-50%, 0)' },
        { top: '15%', left: '75%', transform: 'translate(-50%, 0)' },
        { top: '60%', left: '35%', transform: 'translate(-50%, 0)' },
        { top: '60%', left: '65%', transform: 'translate(-50%, 0)' },
    ];


    return (
        <div className="w-full h-full flex flex-col overflow-hidden bg-cover bg-center" style={{backgroundImage: "url('https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/freepik__a-futuristic-topdown-view-digital-square-platform-__51677.png?alt=media&token=7a816e42-2a6d-4730-b4fa-efc3f8434498')"}}>
            <style>{`
                .perspective-1000 { perspective: 1000px; }
                .transform-style-3d { transform-style: preserve-3d; }
                .backface-hidden { backface-visibility: hidden; -webkit-backface-visibility: hidden; }
                .rotate-y-180 { transform: rotateY(180deg); }
                .card-fly-in {
                    opacity: 0;
                    animation: fly-in 0.6s forwards ease-out;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                }
                @keyframes fly-in {
                    0% { 
                        opacity: 0; 
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%) scale(0.2); 
                    }
                    100% { 
                        opacity: 1; 
                        top: var(--card-final-top);
                        left: var(--card-final-left);
                        transform: var(--card-final-transform);
                        scale: 1; 
                    }
                }
            `}</style>
            
            <div className="flex-1 relative">
                <div className="w-full h-full relative">
                    {contents.map((template, index) => (
                         <Card
                            key={index}
                            template={template}
                            isFlipped={flippedIndices.includes(index)}
                            onFlip={() => handleFlip(index)}
                            cardBackUrl={pack?.cardBackUrl}
                            className="absolute card-fly-in"
                            style={{
                                animationDelay: `${0.3 + index * 0.15}s`,
                                '--card-final-top': cardPositions[index].top,
                                '--card-final-left': cardPositions[index].left,
                                '--card-final-transform': cardPositions[index].transform,
                            } as React.CSSProperties
                            }
                        />
                    ))}
                </div>
            </div>

            <footer className="flex-shrink-0 h-24 px-6 flex items-center justify-center z-20">
                 {allFlipped && (
                    <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
                         <button
                            onClick={() => onClaim(contents)}
                            className="py-3 px-12 rounded-full font-bold text-white text-lg transition-all duration-300 bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                        >
                           CLAIM
                        </button>
                    </div>
                )}
            </footer>
        </div>
    );
};