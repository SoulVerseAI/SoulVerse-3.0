import React from 'react';
import { AccountSettings } from '../../types';
import { Toggle } from './Toggle';
import { GoogleIcon } from '../icons/Icons';

export interface GoogleAuthState {
    isSignedIn: boolean;
    userEmail: string | null;
    error: string | null;
}

export interface GoogleSheetsAuthProps {
    googleAuth: GoogleAuthState;
    onAuthorize: () => void;
    onSignOut: () => void;
}

interface GoogleSheetsSettingsProps extends GoogleSheetsAuthProps {
    accountSettings: AccountSettings;
    onSettingsChange: <K extends keyof AccountSettings>(key: K, value: AccountSettings[K]) => void;
}

export const GoogleSheetsSettings: React.FC<GoogleSheetsSettingsProps> = ({
    accountSettings,
    onSettingsChange,
    googleAuth,
    onAuthorize,
    onSignOut,
}) => {
    return (
        <div className="space-y-6 pt-4">
            <div>
                {googleAuth.isSignedIn ? (
                    <div className="flex items-center justify-between p-3 bg-green-900/30 border border-green-700/50 rounded-lg">
                        <p className="text-sm text-green-300">
                            Connected as: <span className="font-semibold">{googleAuth.userEmail}</span>
                        </p>
                        <button onClick={onSignOut} className="text-xs text-neutral-400 hover:text-white underline">
                            Sign Out
                        </button>
                    </div>
                ) : (
                    <button
                        onClick={onAuthorize}
                        className="w-full flex items-center justify-center gap-3 py-2.5 rounded-lg font-semibold bg-neutral-700/60 hover:bg-neutral-600 text-white transition-colors"
                    >
                        <GoogleIcon className="w-5 h-5" />
                        Authorize with Google
                    </button>
                )}
                {googleAuth.error && <p className="text-xs text-red-400 mt-2">Authorization failed: {googleAuth.error}</p>}
            </div>

            <div className={`space-y-4 ${!googleAuth.isSignedIn ? 'opacity-50 pointer-events-none' : ''}`}>
                <div>
                    <label htmlFor="spreadsheet-id" className="block text-sm font-medium text-neutral-300 mb-2">
                        Google Spreadsheet ID
                    </label>
                    <input
                        id="spreadsheet-id"
                        type="text"
                        value={accountSettings.googleSheetsId || ''}
                        onChange={(e) => onSettingsChange('googleSheetsId', e.target.value)}
                        placeholder="Enter your Spreadsheet ID"
                        className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                    <p className="text-xs text-neutral-500 mt-1">
                        Find this in your sheet's URL: docs.google.com/spreadsheets/d/`SPREADSHEET_ID`/edit
                    </p>
                </div>
                <div>
                    <label className="flex items-center justify-between text-sm font-medium text-neutral-300">
                        <span>Enable Chat Logging</span>
                        <Toggle
                            checked={accountSettings.isGoogleSheetsLoggingEnabled || false}
                            onChange={(checked) => onSettingsChange('isGoogleSheetsLoggingEnabled', checked)}
                        />
                    </label>
                    <p className="text-xs text-neutral-500 mt-1">
                        Automatically logs user and AI messages to the specified sheet.
                    </p>
                </div>
            </div>
        </div>
    );
};