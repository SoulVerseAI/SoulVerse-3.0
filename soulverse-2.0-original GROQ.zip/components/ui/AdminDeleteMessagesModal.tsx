import React, { useState } from 'react';
import { Modal } from './Modal';
import { ChatMessage } from '../../types';
import { ChevronDownIcon, TrashIcon } from '../icons/Icons';

interface CollapsibleMessageItemProps {
    message: ChatMessage;
    onDelete: (id: string) => void;
    soulName: string;
    userName: string;
}

const CollapsibleMessageItem: React.FC<CollapsibleMessageItemProps> = ({ message, onDelete, soulName, userName }) => {
    const [isOpen, setIsOpen] = useState(false);
    const sender = message.sender === 'user' ? userName : soulName;

    return (
        <div className="border border-neutral-700/60 rounded-lg overflow-hidden">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center p-3 text-left bg-neutral-800/50 hover:bg-neutral-800/80 transition-colors"
            >
                <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-white truncate">
                        {sender}: {message.text}
                    </p>
                    <p className="text-xs text-neutral-500">{new Date(message.timestamp).toLocaleString()}</p>
                </div>
                <ChevronDownIcon
                    className={`w-5 h-5 text-neutral-400 transition-transform duration-200 ml-2 ${isOpen ? 'rotate-180' : ''}`}
                />
            </button>
            {isOpen && (
                <div className="p-3 bg-neutral-800/30 border-t border-neutral-700/60">
                    <p className="text-sm whitespace-pre-wrap mb-3">{message.text}</p>
                    <button 
                        onClick={() => onDelete(message.id)}
                        className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 px-3 py-1 rounded-md"
                    >
                        <TrashIcon className="w-4 h-4" />
                        Delete Message
                    </button>
                </div>
            )}
        </div>
    );
};

interface AdminDeleteMessagesModalProps {
    isOpen: boolean;
    onClose: () => void;
    messages: ChatMessage[];
    onDeleteMessage: (messageId: string) => void;
    soulName: string;
    userName: string;
}

export const AdminDeleteMessagesModal: React.FC<AdminDeleteMessagesModalProps> = ({ isOpen, onClose, messages, onDeleteMessage, soulName, userName }) => {
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Manage Chat History" maxWidth="max-w-3xl">
            <div className="p-4 md:p-6 bg-[#1c1c1c] text-neutral-300">
                <p className="text-sm text-neutral-400 mb-4">
                    Here you can view and delete individual messages from the current chat history. This action is permanent.
                </p>
                <div className="max-h-[60vh] overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                    {messages.length > 0 ? (
                        [...messages].reverse().map(msg => (
                           (msg.text !== '--- Chat Break ---' && msg.timestamp !== '0') &&
                            <CollapsibleMessageItem 
                                key={msg.id} 
                                message={msg} 
                                onDelete={onDeleteMessage}
                                soulName={soulName}
                                userName={userName}
                            />
                        ))
                    ) : (
                        <p className="text-center text-neutral-500 py-8">No messages in this chat yet.</p>
                    )}
                </div>
            </div>
        </Modal>
    );
};
