import React from 'react';
import { XMarkIcon } from '../icons/Icons';

interface FunctionWindowProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  children: React.ReactNode;
  headerClassName?: string;
  transparentBg?: boolean;
  maxWidth?: string;
}

export const FunctionWindow: React.FC<FunctionWindowProps> = ({ isOpen, onClose, title, children, headerClassName, transparentBg = false, maxWidth = 'max-w-[958px] h-full rounded-xl' }) => {
  if (!isOpen) return null;

  const containerClasses = transparentBg
    ? "bg-transparent backdrop-filter-none border-none shadow-none"
    : "border border-white/10 bg-gradient-to-b from-cyan-800/50 to-purple-900/50 backdrop-blur-xl";

  return (
    <div
      className="fixed inset-0 z-50 flex justify-center items-center md:items-start md:pt-20 md:pb-8 p-4 pointer-events-none"
      role="dialog"
      aria-modal="false"
    >
      <div
        className={`w-full ${maxWidth} max-h-[90vh] md:max-h-[821px] shadow-2xl flex flex-col overflow-hidden pointer-events-auto ${containerClasses}`}
        onClick={(e) => e.stopPropagation()}
      >
        {!transparentBg && title && (
            <header className={`relative flex items-center justify-center p-4 bg-black/30 backdrop-blur-sm border-b border-blue-500/50 flex-shrink-0 ${headerClassName || ''}`}>
            <h2 id="function-window-title" className="text-xl font-semibold text-white text-center">{title}</h2>
            <button onClick={onClose} className="absolute top-1/2 -translate-y-1/2 right-4 p-1 rounded-full text-neutral-400 hover:bg-neutral-700/80 hover:text-white">
                <XMarkIcon className="w-6 h-6" />
            </button>
            </header>
        )}
        <div className="flex-1 overflow-y-auto min-h-0">
          {children}
        </div>
      </div>
    </div>
  );
};
