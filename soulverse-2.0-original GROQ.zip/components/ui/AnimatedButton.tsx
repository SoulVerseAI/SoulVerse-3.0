import React from 'react';

interface AnimatedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    children: React.ReactNode;
}

export const AnimatedButton: React.FC<AnimatedButtonProps> = ({ children, className, ...props }) => {
    const animationClasses = "transition-transform duration-75 ease-out active:scale-[0.97]";

    return (
        <button
            className={`${animationClasses} ${className || ''}`}
            {...props}
        >
            {children}
        </button>
    );
};