import React, { useState, useEffect, useRef } from 'react';
import { Modal } from './Modal';
import { Soul, ChatMessage, AccountSettings } from '../../types';
import { generateSelfiePrompt, generateSimpleScenePrompt, generateNsfwSelfiePrompt, getConversationContext } from '../../services/geminiService';
import { Toggle } from './Toggle';
import { CollapsibleSection } from './CollapsibleSection';
import { LoadingSpinner } from '../icons/Icons';

export interface GenerateImageOptions {
    customPrompt: string;
    pose: string;
    useNSFW: boolean;
    style: 'Photoreal' | 'Anime';
    positiveBasePrompt: string;
    negativeBasePrompt: string;
}

interface GenerateImageModalProps {
    isOpen: boolean;
    onClose: () => void;
    onGenerate: (options: GenerateImageOptions) => void;
    type: 'selfie' | 'scene';
    soul: Soul;
    initialUseNSFW?: boolean;
    messages: ChatMessage[];
    accountSettings: AccountSettings;
}

const selfiePoses = ["Standing", "Sitting", "Lying down", "Walking", "Action pose", "Close-up portrait", "Dynamic angle", "Looking over shoulder"];

export const GenerateImageModal: React.FC<GenerateImageModalProps> = ({ isOpen, onClose, onGenerate, type, soul, initialUseNSFW = false, messages, accountSettings }) => {
    const [customPrompt, setCustomPrompt] = useState('');
    const [selectedPose, setSelectedPose] = useState('');
    const [useNSFW, setUseNSFW] = useState(initialUseNSFW);
    const [style, setStyle] = useState<'Photoreal' | 'Anime'>(soul.avatarStyle || 'Photoreal');
    const [positiveBasePrompt, setPositiveBasePrompt] = useState('');
    const [negativeBasePrompt, setNegativeBasePrompt] = useState('');
    const [isLoadingPrompts, setIsLoadingPrompts] = useState(true);

    const defaultPrompts = useRef({ positive: '', negative: '' });

    useEffect(() => {
        if (isOpen) {
            setUseNSFW(initialUseNSFW);
            setCustomPrompt('');
            setSelectedPose('');
            setStyle(soul.avatarStyle || 'Photoreal');
        }
    }, [isOpen, initialUseNSFW, soul.avatarStyle]);

    useEffect(() => {
        const fetchBasePrompts = async () => {
            if (!isOpen) return;
            setIsLoadingPrompts(true);
            try {
                let prompts;
                if (type === 'selfie') {
                    const lastMessagesContext = getConversationContext(messages, 1000, soul.name, accountSettings.userName);
                    prompts = useNSFW
                        ? await generateNsfwSelfiePrompt(lastMessagesContext, soul.physicalAppearanceDescription, soul.name, soul.gender)
                        : await generateSelfiePrompt(lastMessagesContext, soul.physicalAppearanceDescription, style, soul.name, soul.gender);
                } else {
                    prompts = await generateSimpleScenePrompt(messages, soul, accountSettings, useNSFW);
                }
                setPositiveBasePrompt(prompts.positive);
                setNegativeBasePrompt(prompts.negative);
                defaultPrompts.current = { positive: prompts.positive, negative: prompts.negative };
            } catch (error) {
                console.error("Failed to fetch base prompts", error);
                setPositiveBasePrompt("Error loading prompt.");
                setNegativeBasePrompt("Error loading prompt.");
            } finally {
                setIsLoadingPrompts(false);
            }
        };
        fetchBasePrompts();
    }, [isOpen, type, soul, useNSFW, style, messages, accountSettings]);

    const handleGenerateClick = () => {
        onGenerate({
            customPrompt,
            pose: selectedPose,
            useNSFW,
            style,
            positiveBasePrompt,
            negativeBasePrompt
        });
    };

    const handleRestoreDefaults = () => {
        setPositiveBasePrompt(defaultPrompts.current.positive);
        setNegativeBasePrompt(defaultPrompts.current.negative);
    };

    const title = type === 'selfie' ? 'Request Selfie' : 'Generate Scene';

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={title} maxWidth="max-w-2xl">
            <div className="p-6 space-y-6 bg-[#1c1c1c] text-neutral-300">
                
                {type === 'selfie' && (
                    <div>
                        <label className="block text-sm font-medium text-neutral-300 mb-2">Pose (Optional)</label>
                        <div className="flex flex-wrap gap-2">
                            {selfiePoses.map(pose => (
                                <button 
                                    key={pose}
                                    onClick={() => setSelectedPose(p => p === pose ? '' : pose)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${selectedPose === pose ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-700/60 hover:bg-neutral-600'}`}
                                >
                                    {pose}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                <div>
                    <label htmlFor="custom-prompt" className="block text-sm font-medium text-neutral-300 mb-2">
                        {type === 'selfie' ? 'Selfie Prompt' : 'Scene Prompt'} (Optional)
                    </label>
                    <textarea 
                        id="custom-prompt"
                        value={customPrompt}
                        onChange={e => setCustomPrompt(e.target.value)}
                        rows={3}
                        className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        placeholder={type === 'selfie' ? 'e.g., smiling softly, in a sunlit cafe...' : 'e.g., walking through a neon-lit city street at night...'}
                    />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-700/60">
                     <div>
                        <label className="block text-sm font-medium text-neutral-300 mb-2">Style</label>
                        <div className="flex gap-2">
                            <button onClick={() => setStyle('Photoreal')} className={`py-2 px-4 rounded-md text-sm font-medium transition-colors flex-1 ${style === 'Photoreal' ? 'bg-neutral-600 text-white' : 'bg-neutral-700/60 hover:bg-neutral-600'}`}>Photoreal</button>
                            <button onClick={() => setStyle('Anime')} className={`py-2 px-4 rounded-md text-sm font-medium transition-colors flex-1 ${style === 'Anime' ? 'bg-neutral-600 text-white' : 'bg-neutral-700/60 hover:bg-neutral-600'}`}>Anime</button>
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-neutral-300 mb-2">Content</label>
                         <div className="flex items-center justify-center gap-2 p-2 bg-neutral-700/60 rounded-md">
                            <span className="text-sm font-medium">SFW</span>
                            <Toggle checked={useNSFW} onChange={setUseNSFW} />
                            <span className="text-sm font-medium text-red-400">NSFW</span>
                        </div>
                    </div>
                </div>

                <CollapsibleSection title="Advanced Prompt Settings" description="Edit the base prompts for this generation.">
                    {isLoadingPrompts ? (
                         <div className="flex items-center justify-center p-8">
                            <LoadingSpinner className="w-8 h-8" />
                        </div>
                    ) : (
                        <div className="space-y-4 pt-4">
                            <div>
                                <label className="block text-sm font-medium text-neutral-300 mb-2">Positive Base Prompt</label>
                                <textarea value={positiveBasePrompt} onChange={e => setPositiveBasePrompt(e.target.value)} rows={4} className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs"/>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-neutral-300 mb-2">Negative Base Prompt</label>
                                <textarea value={negativeBasePrompt} onChange={e => setNegativeBasePrompt(e.target.value)} rows={2} className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs"/>
                            </div>
                            <button onClick={handleRestoreDefaults} className="text-xs text-blue-400 underline hover:text-blue-300">
                                Restore Defaults
                            </button>
                        </div>
                    )}
                </CollapsibleSection>

                <div className="flex justify-end pt-4">
                    <button 
                        onClick={handleGenerateClick}
                        className="py-2 px-8 rounded-full font-semibold text-white bg-gradient-cyan-purple hover:opacity-90 transition-opacity"
                    >
                        Generate
                    </button>
                </div>
            </div>
        </Modal>
    );
};
