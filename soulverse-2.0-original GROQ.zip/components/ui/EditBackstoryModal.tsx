import React, { useState } from 'react';
import { AccountSettings } from '../../types';
import { getSubscriptionBenefits, benefits as standardBenefits } from '../../services/subscriptionService';

export const EditBackstoryModal: React.FC<{initialBackstory: string, onSave: (b: string) => void, maxLength: number, accountSettings: AccountSettings}> = 
({ initialBackstory, onSave, maxLength, accountSettings }) => {
    const [backstory, setBackstory] = useState(initialBackstory);
    // FIX: Changed 'Eternal' to 'Max' to match SubscriptionTier type.
    const standardMax = standardBenefits.Max.userBackstoryChars;
    const isAdminOverLimit = accountSettings.adminMode && backstory.length > standardMax;
    const displayMaxLength = getSubscriptionBenefits(accountSettings).userBackstoryChars;

    return (
        <div className="p-4">
             <p className="text-sm text-neutral-400 mb-4">This information will be accessible to all your Souls in conversations, including group chats and voice calls.</p>
            <textarea
              value={backstory}
              onChange={(e) => setBackstory(e.target.value)}
              maxLength={maxLength}
              rows={6}
              className="w-full bg-neutral-700/60 border-neutral-600 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm"
            />
            <div className="flex justify-between items-center mt-1">
                <button onClick={() => setBackstory('')} className="text-xs text-neutral-400 hover:text-white underline">
                    Clear Backstory
                </button>
                <p className={`text-right text-xs ${isAdminOverLimit ? 'text-red-500 font-bold' : 'text-neutral-500'}`}>{backstory.length} / {displayMaxLength}</p>
            </div>
            <button onClick={() => onSave(backstory)} className="mt-4 w-full py-2 px-6 rounded-md text-sm font-medium transition-opacity bg-gradient-cyan-purple text-white hover:opacity-90">
                Save
            </button>
        </div>
    )
};