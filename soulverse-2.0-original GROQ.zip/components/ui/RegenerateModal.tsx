import React, { useState } from 'react';
import { Modal } from './Modal';
import { ChevronDownIcon } from '../icons/Icons';

interface RegenerateModalProps {
    isOpen: boolean;
    onClose: () => void;
    onRegenerate: (suggestion: string) => void;
    originalMessageText: string;
}

export const RegenerateModal: React.FC<RegenerateModalProps> = ({ isOpen, onClose, onRegenerate, originalMessageText }) => {
    const [suggestion, setSuggestion] = useState('');
    const [showOriginal, setShowOriginal] = useState(false);
    const suggestionPresets = ["Take it in another direction", "Make it longer", "Narrate thoughts more", "Avoid metaphors"];

    const handleSuggestionClick = (preset: string) => {
        setSuggestion(prev => prev ? `${prev}, ${preset.toLowerCase()}` : preset);
    };
    
    const handleSubmit = () => {
        onRegenerate(suggestion);
        setSuggestion(''); // Clear after submitting
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Regenerate/Suggest Change" maxWidth="max-w-5xl" closeOnBackdropClick={false}>
            <div className="p-6 space-y-4 bg-[#1c1c1c] text-neutral-300">
                <p className="text-sm text-neutral-400">
                    Write a suggestion for your Soul to revise their message, or leave blank to regenerate the response (which may be similar to previous response). To get a different response altogether, suggest "take it in a different direction".
                </p>
                <button onClick={() => setShowOriginal(p => !p)} className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white">
                    Show original message
                    <ChevronDownIcon className={`w-4 h-4 transition-transform ${showOriginal ? 'rotate-180' : ''}`} />
                </button>
                {showOriginal && (
                    <div className="text-sm p-3 bg-neutral-800 rounded-lg border border-neutral-700 max-h-24 overflow-y-auto">
                        {originalMessageText}
                    </div>
                )}
                <div className="bg-neutral-700/60 rounded-xl p-4">
                    <textarea
                        value={suggestion}
                        onChange={e => setSuggestion(e.target.value)}
                        maxLength={300}
                        rows={3}
                        className="w-full bg-transparent focus:outline-none text-sm resize-none placeholder-neutral-500"
                        placeholder={'(Optional suggestion) "take it in a different direction", or "be more descriptive"\n\nLeave blank to regenerate from scratch (may be similar to previous response).'}
                    />
                </div>
                <div className="text-right text-xs text-neutral-500">{suggestion.length} / 300 chars</div>
                <div className="flex flex-wrap gap-2">
                    {suggestionPresets.map(preset => (
                        <button key={preset} onClick={() => handleSuggestionClick(preset)} className="px-3 py-1.5 text-xs font-medium text-white bg-gradient-cyan-purple hover:opacity-90 rounded-full transition-opacity">
                            {preset}
                        </button>
                    ))}
                </div>
                <button onClick={handleSubmit} className="w-full mt-4 py-3 rounded-full font-semibold text-lg text-white bg-gradient-cyan-purple hover:opacity-90 transition-opacity">
                   Regenerate
                </button>
            </div>
        </Modal>
    );
};