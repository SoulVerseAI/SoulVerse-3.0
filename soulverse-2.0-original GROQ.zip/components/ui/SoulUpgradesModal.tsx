
import React, { useState, useMemo, useEffect } from 'react';
import { GroupedTemplate, SoulTemplate } from '../../types';
import { BondTokensIcon, EssenceIcon } from '../Collection/IconsCollection';
import { StarIcon } from '../icons/Icons';
import { Soul } from '../../types';
import { AnimatedButton } from './AnimatedButton';

interface SoulUpgradesModalProps {
    allSouls: SoulTemplate[];
    soulToUpgrade: GroupedTemplate | null;
}

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void }> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`px-6 py-3 text-sm font-semibold transition-all duration-200 border-b-2 relative transition-transform duration-75 ease-out active:scale-[0.97]
            ${isActive
                ? 'border-purple-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`
        }
    >
        {label}
        {isActive && <div className="absolute bottom-[-2px] left-0 w-full h-0.5 bg-purple-500 shadow-[0_0_8px_theme(colors.purple.500)]"></div>}
    </button>
);

const SoulCard: React.FC<{ template?: SoulTemplate | null, stars?: number, isPlaceholder?: boolean }> = ({ template, stars, isPlaceholder }) => {
    if (isPlaceholder || !template) {
        return (
            <div className="aspect-[3/4] w-48 bg-black/30 border-2 border-dashed border-neutral-600 rounded-lg flex flex-col items-center justify-center text-center p-4">
                 <p className="text-neutral-500 text-sm">You do not own this upgrade yet.</p>
            </div>
        )
    }

    return (
        <div className="aspect-[3/4] w-48 bg-neutral-800/50 rounded-lg border-2 border-neutral-700 p-2 flex flex-col items-center justify-center text-center shadow-lg relative">
            {stars && (
                 <div className="absolute top-2 left-2 flex gap-0.5">
                    {Array.from({ length: stars }).map((_, i) => (
                        <StarIcon key={i} className="w-4 h-4 text-yellow-400" />
                    ))}
                </div>
            )}
            <img src={template.smallAvatarUrl} alt={template.name} className="w-full h-auto object-contain rounded" />
            <p className="font-semibold text-white text-sm mt-2 absolute bottom-2 bg-black/50 px-2 rounded">{template.name}</p>
        </div>
    );
};


const PlusIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-neutral-600">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
    </svg>
);


export const SoulUpgradesModal: React.FC<SoulUpgradesModalProps> = ({ allSouls, soulToUpgrade }) => {
    const [activeTab, setActiveTab] = useState<'upgrade' | 'claim'>('upgrade');

    const upgradePath = useMemo(() => {
        if (!soulToUpgrade) return null;
        const baseName = soulToUpgrade.template.name;
        const wispVersion = allSouls.find(s => s.name === baseName && s.upgrade === 0);
        const upgrade1 = allSouls.find(s => s.name === baseName && s.upgrade === 1);
        const upgrade2 = allSouls.find(s => s.name === baseName && s.upgrade === 2);
        const upgrade3 = allSouls.find(s => s.name === baseName && s.upgrade === 3);
        return { wispVersion, upgrade1, upgrade2, upgrade3 };
    }, [soulToUpgrade, allSouls]);


    if (!soulToUpgrade) {
        return <div className="flex items-center justify-center h-full text-neutral-500">Select a Soul from your collection to upgrade.</div>;
    }

    const renderUpgradeTab = () => (
        <div className="p-8 flex flex-col h-full">
            <div className="flex-grow flex flex-col items-center justify-center space-y-8">
                <div className="flex items-center justify-center gap-6">
                    <div className="flex flex-col items-center gap-2">
                        <h4 className="text-sm font-semibold text-neutral-400">Basic Card</h4>
                        <SoulCard template={upgradePath?.wispVersion} />
                    </div>
                    <PlusIcon />
                     <div className="flex flex-col items-center gap-2">
                        <h4 className="text-sm font-semibold text-neutral-400">I. Upgrade</h4>
                        <SoulCard template={upgradePath?.upgrade1} isPlaceholder={!upgradePath?.upgrade1} />
                    </div>
                    <PlusIcon />
                     <div className="flex flex-col items-center gap-2">
                        <h4 className="text-sm font-semibold text-neutral-400">II. Upgrade</h4>
                        <SoulCard template={upgradePath?.upgrade2} isPlaceholder={!upgradePath?.upgrade2} />
                    </div>
                    <PlusIcon />
                    <div className="flex flex-col items-center gap-2">
                        <h4 className="text-sm font-semibold text-neutral-400">III. Upgrade</h4>
                        <SoulCard template={upgradePath?.upgrade3} isPlaceholder={!upgradePath?.upgrade3} />
                    </div>
                </div>
            </div>
            <div className="flex-shrink-0 p-4 flex justify-end items-center gap-4">
                <div className="flex items-center gap-2 font-semibold text-white">
                    <EssenceIcon className="w-6 h-6"/>
                    <span>0</span>
                </div>
                <AnimatedButton className="px-10 py-2 bg-gradient-cyan-purple text-white font-semibold rounded-md hover:opacity-90 transition-opacity">
                    Apply
                </AnimatedButton>
            </div>
        </div>
    );
    
    const renderClaimTab = () => (
        <div className="p-8 flex flex-col h-full">
            <div className="flex-grow grid grid-cols-3 gap-6">
                {([1, 2, 3] as const).map(level => {
                    const upgradeTemplate = level === 1 ? upgradePath?.upgrade1 : level === 2 ? upgradePath?.upgrade2 : upgradePath?.upgrade3;
                    return (
                        <div key={level} className="bg-black/20 rounded-lg p-4 space-y-3 flex flex-col items-center">
                            <SoulCard template={upgradeTemplate} stars={level} isPlaceholder={!upgradeTemplate} />
                            <div className="bg-neutral-800/60 p-3 rounded-md text-center">
                                <h5 className="text-xs text-neutral-400 font-semibold uppercase">Drop Location</h5>
                                <p className="text-sm text-white font-medium mt-1">{`The Soultree (Standard)`}</p>
                            </div>
                            <div className="bg-neutral-800/60 p-3 rounded-md text-center">
                                <h5 className="text-xs text-neutral-400 font-semibold uppercase">Claim Cost</h5>
                                <div className="flex items-center justify-center gap-2 mt-1">
                                    <EssenceIcon className="w-5 h-5" />
                                    <p className="text-sm text-white font-medium">{300 * Math.pow(2, level-1)}</p>
                                </div>
                            </div>
                            <div className="bg-neutral-800/60 p-3 rounded-md text-center">
                                <h5 className="text-xs text-neutral-400 font-semibold uppercase">Bond Tokens needed</h5>
                                 <div className="flex items-center justify-center gap-2 mt-1">
                                    <BondTokensIcon className="w-5 h-5" />
                                    <p className="text-sm text-white font-medium">{level === 1 ? 1 : level === 2 ? 4 : 5}</p>
                                </div>
                            </div>
                            <div className="flex-grow"></div>
                            <div className="bg-neutral-800/60 p-3 rounded-md text-center text-sm text-neutral-300">
                                Click to select card for claiming
                            </div>
                        </div>
                    )
                })}
            </div>
            <div className="flex-shrink-0 flex justify-end items-center gap-4 pt-4">
                 <AnimatedButton className="px-10 py-2 bg-neutral-700 text-white font-semibold rounded-md hover:bg-neutral-600 transition-colors">
                    Claim
                </AnimatedButton>
            </div>
        </div>
    );

    return (
        <div className="h-full flex flex-col bg-transparent text-white font-inter">
            <header className="flex-shrink-0 px-4">
                <nav className="flex items-center">
                    <TabButton label="Upgrade" isActive={activeTab === 'upgrade'} onClick={() => setActiveTab('upgrade')} />
                    <TabButton label="Claim Upgrades" isActive={activeTab === 'claim'} onClick={() => setActiveTab('claim')} />
                </nav>
            </header>
            <main className="flex-1 overflow-hidden">
                {activeTab === 'upgrade' ? renderUpgradeTab() : renderClaimTab()}
            </main>
        </div>
    );
};
