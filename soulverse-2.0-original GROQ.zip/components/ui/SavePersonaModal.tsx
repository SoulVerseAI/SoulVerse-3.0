import React from 'react';
import { Modal } from './Modal';
import { Persona, Gender } from '../../types';

export const SavePersonaModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  onOverwrite: (persona: Persona) => void;
  currentSettings: { userName: string; userGender: Gender };
  existingPersonas: Persona[];
}> = ({ isOpen, onClose, onSave, onOverwrite, currentSettings, existingPersonas }) => {

  const personaExists = existingPersonas.some(p => p.name === currentSettings.userName);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Save current as persona">
      <div className="p-6 space-y-4">
        <p className="text-sm text-neutral-400">
          This will put your current user settings into a persona. Make sure you've clicked "save" on any changes you made on user profile before saving as a persona.
        </p>
        <p className="text-sm">
          Current settings to save: <span className="font-semibold text-white">{currentSettings.userName} ({currentSettings.userGender})</span>
        </p>

        <button
          onClick={onSave}
          className="text-blue-400 hover:text-blue-300 disabled:text-neutral-500 disabled:cursor-not-allowed transition-colors text-sm font-semibold"
        >
          + Save as New Persona
        </button>
        {personaExists && <p className="text-xs text-neutral-500 -mt-2 pl-1">A persona named '{currentSettings.userName}' already exists. Overwrite it below.</p>}

        <div className="pt-4 border-t border-neutral-700">
          <h4 className="font-semibold text-white mb-2 text-sm">Or save and overwrite/update an existing persona:</h4>
          <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-2">
            {existingPersonas.length > 0 ? (
              existingPersonas.map(p => (
                <button
                  key={p.id}
                  onClick={() => onOverwrite(p)}
                  className="w-full text-left p-3 rounded-lg bg-neutral-800 hover:bg-neutral-700/60 flex justify-between items-center"
                >
                  <span className="font-medium text-white">{p.name}</span>
                  <span className="text-xs text-neutral-400">{p.userName} ({p.userGender})</span>
                </button>
              ))
            ) : (
              <p className="text-sm text-neutral-500">No existing personas to overwrite.</p>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};
