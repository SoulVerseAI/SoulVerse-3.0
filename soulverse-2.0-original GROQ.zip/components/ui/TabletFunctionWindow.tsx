import React from 'react';
import { FunctionWindow } from './FunctionWindow';

type FunctionName = 
  | 'seasonPass' 
  | 'soulNotes' 
  | 'vault' 
  | 'soulBoard' 
  | 'homeMenu' 
  | 'selfie' 
  | 'voiceCall' 
  | 'inbox'
  | 'createSoul';

interface TabletFunctionWindowProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  children: React.ReactNode;
  headerClassName?: string;
  transparentBg?: boolean;
  functionName: string;
}

const TABLET_FUNCTION_SIZES: Record<string, string> = {
  seasonPass: 'max-w-2xl h-full rounded-xl',
  soulNotes: 'max-w-4xl h-full rounded-xl',
  vault: 'max-w-4xl h-full rounded-xl',
  soulBoard: 'max-w-4xl h-full rounded-xl',
  homeMenu: 'max-w-4xl h-full rounded-xl',
  selfie: 'max-w-2xl h-auto rounded-xl',
  voiceCall: 'max-w-lg h-auto rounded-xl',
  inbox: 'max-w-3xl h-full rounded-xl',
  createSoul: 'max-w-2xl h-auto rounded-xl',
  // Default fallback
  default: 'max-w-2xl h-auto rounded-xl',
};

export const TabletFunctionWindow: React.FC<TabletFunctionWindowProps> = (props) => {
  const { functionName, ...rest } = props;
  const sizeClass = TABLET_FUNCTION_SIZES[functionName] || TABLET_FUNCTION_SIZES.default;

  return <FunctionWindow {...rest} maxWidth={sizeClass} />;
};
