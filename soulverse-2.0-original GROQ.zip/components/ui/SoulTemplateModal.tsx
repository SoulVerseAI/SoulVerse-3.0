

import React, { useState } from 'react';
import { Modal } from './Modal';
import { Soul } from '../../types';
import { UserCircleIcon, ChevronDownIcon, PlayCircleIcon, XMarkIcon } from '../icons/Icons';

const DetailTextarea: React.FC<{ label: string; value: string; rows?: number }> = ({ label, value, rows = 5 }) => (
    <div>
        <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">{label}</label>
        <div style={{minHeight: `${rows * 1.5}rem`}} className="bg-neutral-800 p-3 rounded-lg text-sm text-neutral-300 border border-neutral-700/60 overflow-y-auto whitespace-pre-wrap">
            {value || "Not set."}
        </div>
    </div>
);

const DetailField: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
    <div>
        <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">{label}</label>
        <div className="bg-neutral-800 p-3 rounded-lg text-sm text-neutral-300 border border-neutral-700/60">
            {children}
        </div>
    </div>
);

const GenderButton: React.FC<{ label: string, isSelected: boolean }> = ({ label, isSelected }) => (
    <button
        disabled
        className={`w-full py-2 rounded-md text-sm font-medium transition-colors ${
            isSelected ? 'text-white bg-gradient-cyan-purple' : 'bg-neutral-700/60 text-neutral-400'
        }`}
    >
        {label}
    </button>
);

const VoiceOption: React.FC<{ name: string, isSelected: boolean }> = ({ name, isSelected }) => (
    <div className="flex items-center justify-between p-2">
        <div className="flex items-center gap-3">
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isSelected ? 'border-purple-400' : 'border-neutral-500'}`}>
                {isSelected && <div className="w-2.5 h-2.5 bg-purple-400 rounded-full" />}
            </div>
            <span className="text-base text-neutral-200">{name}</span>
        </div>
        <button className="text-neutral-400 hover:text-white transition-colors">
            <PlayCircleIcon className="w-7 h-7" />
        </button>
    </div>
);


interface SoulTemplateModalProps {
    isOpen: boolean;
    onClose: () => void;
    soul: Soul | null;
    maxWidth?: string;
    position?: 'center' | 'top';
}

export const SoulTemplateModal: React.FC<SoulTemplateModalProps> = ({ isOpen, onClose, soul, maxWidth = 'max-w-2xl', position = 'center' }) => {
    const [advancedSettingsOpen, setAdvancedSettingsOpen] = useState(false);

    if (!soul) return null;
    
    const voices = [
        { id: 'voice-1', name: 'Voice 1' },
        { id: 'voice-2', name: 'Voice 2' },
        { id: 'voice-3', name: 'Voice 3' },
        { id: 'voice-4', name: 'Voice 4' },
        { id: 'voice-5', name: 'Voice 5' },
    ];
    const voiceOptions = voices.map(v => v.name);

    // Default to voice 2 as per image, if no voice is set.
    const selectedVoiceName = soul.voiceURI ? (voices.find(v => v.id === soul.voiceURI)?.name || 'Voice 2') : 'Voice 2';
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Details" maxWidth={maxWidth} position={position}>
            <div className="overflow-y-auto p-6 space-y-6 bg-[#1c1c1c]">
                <DetailTextarea label="Tagline" value={soul.description} rows={2} />
                <DetailField label="Name"><p>{soul.name}</p></DetailField>
                <DetailField label="Gender">
                    <div className="flex gap-2">
                        <GenderButton label="Male" isSelected={soul.gender === 'Male'} />
                        <GenderButton label="Female" isSelected={soul.gender === 'Female'} />
                    </div>
                </DetailField>
                <DetailTextarea label="Backstory" value={soul.backstory} />
                <DetailField label="Role"><p>{soul.role || "Character"}</p></DetailField>
                <DetailField label="Personality">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <p className="text-xs text-neutral-400 mb-1">Four Letter</p>
                            <p className="font-medium">{soul.mbti || "Not set"}</p>
                        </div>
                        <div>
                            <p className="text-xs text-neutral-400 mb-1">Enneagram</p>
                            <p className="font-medium">{soul.enneagram || "Not set"}</p>
                        </div>
                    </div>
                </DetailField>
                <DetailTextarea label="Response Directive" value={soul.responseDirective} />
                <DetailTextarea label="Key Memories" value={soul.keyMemories} />
                <DetailTextarea label="Greeting Message" value={soul.greeting} />
                <DetailTextarea label="Example Message" value={soul.exampleMessage} />
                <DetailField label="Voice">
                    <div className="space-y-1">
                        {voiceOptions.map(voiceName => (
                            <VoiceOption key={voiceName} name={voiceName} isSelected={voiceName === selectedVoiceName} />
                        ))}
                    </div>
                </DetailField>
                <DetailField label="Chat Dynamism">
                    <div className="flex justify-between items-center">
                        <span>{soul.dynamism.toFixed(2)}</span>
                        <ChevronDownIcon className="w-5 h-5 text-neutral-500" />
                    </div>
                </DetailField>
                
                <div className="space-y-4 pt-4 border-t border-neutral-700/60">
                    <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider">Avatar</h3>
                    <div className="flex justify-center">
                        {soul.avatar ? (
                            <img src={soul.avatar} alt={soul.name} className="w-full aspect-square rounded-lg object-cover" />
                        ) : (
                            <div className="w-full aspect-square bg-neutral-800 rounded-lg flex items-center justify-center">
                                <UserCircleIcon className="w-1/2 h-1/2 text-neutral-600" />
                            </div>
                        )}
                    </div>
                    <DetailTextarea label="Avatar Description" value={soul.physicalAppearanceDescription || "No description provided."} />
                    <p className="text-xs text-neutral-500 -mt-5 px-1">This describes the visual appearance of the character for AI image generation (selfies).</p>
                    <DetailField label="Avatar Style">
                        <div className="flex gap-2">
                            <GenderButton label="Photoreal" isSelected={soul.avatarStyle === 'Photoreal'} />
                            <GenderButton label="Anime" isSelected={soul.avatarStyle === 'Anime'} />
                        </div>
                    </DetailField>
                </div>

                <div className="border-t border-neutral-700/60 pt-4">
                    <button onClick={() => setAdvancedSettingsOpen(p => !p)} className="flex justify-between items-center w-full text-left">
                        <span className="text-sm font-semibold text-neutral-400 uppercase tracking-wider">Advanced Avatar Settings</span>
                        <ChevronDownIcon className={`w-5 h-5 text-neutral-400 transition-transform ${advancedSettingsOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {advancedSettingsOpen && (
                        <div className="mt-4 space-y-4">
                            <p className="text-xs text-neutral-500">These settings are read-only for templates.</p>
                            <DetailField label="Face Detail Enhance"><p>{Math.round(soul.faceDetailEnhance * 100)}%</p></DetailField>
                            <DetailTextarea label="Face Detail Prompt" value={soul.faceDetailPrompt} rows={2} />
                        </div>
                    )}
                </div>

                <div className="text-center pt-4">
                    <button onClick={() => alert("Report functionality not implemented.")} className="text-red-500 text-sm font-medium hover:text-red-400">
                        Report
                    </button>
                </div>
            </div>
        </Modal>
    );
}