
import React from 'react';
import { Modal } from './Modal';
import { Soul } from '../../types';

interface ReturnToCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  soul: Soul | null;
}

export const ReturnToCollectionModal: React.FC<ReturnToCollectionModalProps> = ({ isOpen, onClose, onConfirm, soul }) => {
  if (!soul) return null;

  const handleConfirmClick = () => {
    onConfirm();
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Return ${soul.name} to Collection?`} maxWidth="max-w-lg">
      <div className="p-6 text-neutral-300 space-y-4">
        <p className="text-sm text-yellow-300 bg-yellow-900/30 border border-yellow-700/50 rounded-lg p-3">
          <strong>Warning:</strong> This action is permanent and cannot be undone.
        </p>
        <p className="text-sm">
          Returning <strong className="text-white">{soul.name}</strong> to your collection will permanently delete all of its associated chat history and long-term memories from your browser's local storage.
        </p>
        <p className="text-sm">
          A new, non-editable template card for <strong className="text-white">{soul.name}</strong> will be added back to your Collection tab.
        </p>
        <p className="text-sm">Are you sure you want to proceed?</p>
        <div className="flex justify-end space-x-3 pt-4">
          <button onClick={onClose} className="py-2 px-6 rounded-md text-sm font-medium transition-colors bg-neutral-700 hover:bg-neutral-600">
            Cancel
          </button>
          <button onClick={handleConfirmClick} className="py-2 px-6 rounded-md text-sm font-medium transition-colors bg-red-600 text-white hover:bg-red-700">
            Delete & Return
          </button>
        </div>
      </div>
    </Modal>
  );
};
