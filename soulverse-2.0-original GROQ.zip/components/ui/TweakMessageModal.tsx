
import React, { useState, useEffect } from 'react';
import { AccountSettings, ChatMessage } from '../../types';

interface TweakMessageModalProps {
    message: ChatMessage;
    onSave: (messageId: string, newText: string) => void;
    onClose: () => void;
    accountSettings: AccountSettings; // Needed for subscription check, though we use a hard limit for now
}

export const TweakMessageModal: React.FC<TweakMessageModalProps> = ({ message, onSave, onClose, accountSettings }) => {
    const [editedText, setEditedText] = useState(message.text);
    const [prevMessage, setPrevMessage] = useState(message);

    if (message !== prevMessage) {
        setPrevMessage(message);
        try {
            // Attempt to parse the message text as JSON
            const parsedData = JSON.parse(message.text);
            // Check if it's a valid scenario object with narrative and options
            if (parsedData && typeof parsedData === 'object' && 'narrative' in parsedData && Array.isArray(parsedData.options)) {
                // Pretty-print the JSON object for easier editing
                setEditedText(JSON.stringify(parsedData, null, 2));
            } else {
                // It's some other valid JSON, but not what we expect for a scenario. Treat as plain text.
                setEditedText(message.text);
            }
        } catch (error) {
            // It's not a JSON string, so it's a regular text message.
            setEditedText(message.text);
        }
    }

    // While subscriptions define context length, a single message edit has a practical limit.
    // 4000 is a generous limit used elsewhere in the app (e.g., chat break).
    const maxLength = 4000;

    const handleSaveClick = () => {
        onSave(message.id, editedText);
    };

    return (
        <div className="p-2 md:p-4 bg-gradient-to-b from-cyan-800/60 to-purple-900/60 text-neutral-300">
            <textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                rows={10}
                maxLength={maxLength}
                className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm"
                aria-label="Edit AI Message"
            />
            <div className="flex justify-between items-center mt-2">
                <span className="text-xs text-neutral-500">{editedText.length} / {maxLength}</span>
                <div className="flex space-x-3">
                <button
                    onClick={onClose}
                    className="py-2 px-4 rounded-md text-sm font-medium transition-colors hover:bg-neutral-700"
                >
                    Cancel
                </button>
                <button
                    onClick={handleSaveClick}
                    className="py-2 px-4 rounded-md text-sm font-medium transition-opacity bg-gradient-cyan-purple text-white hover:opacity-90"
                >
                    Save
                </button>
                </div>
            </div>
        </div>
    );
};
