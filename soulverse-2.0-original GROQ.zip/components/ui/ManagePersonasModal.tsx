import React, { useState } from 'react';
import { Modal } from './Modal';
import { Persona } from '../../types';
import { TrashIcon } from '../icons/Icons';

export const ManagePersonasModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  personas: Persona[];
  onUse: (persona: Persona) => void;
  onDelete: (personaId: string) => void;
}> = ({ isOpen, onClose, personas, onUse, onDelete }) => {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleConfirmDelete = () => {
    if (deletingId) {
      onDelete(deletingId);
      setDeletingId(null);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Manage personas">
      <div className="p-4 space-y-2">
        {personas.length > 0 ? (
          personas.map(p => (
            <div key={p.id} className="bg-neutral-800 p-3 rounded-lg flex items-center justify-between">
              {deletingId === p.id ? (
                <div className="w-full flex justify-between items-center">
                  <span className="text-sm text-red-400">Delete {p.name}?</span>
                  <div>
                    <button onClick={handleConfirmDelete} className="text-sm font-semibold px-3 py-1 text-white bg-red-600 rounded-md mr-2">Confirm</button>
                    <button onClick={() => setDeletingId(null)} className="text-sm px-3 py-1">Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <span className="font-semibold text-white">{p.name} ({p.userGender})</span>
                  <div className="flex items-center gap-2">
                    <button onClick={() => onUse(p)} className="text-sm font-semibold px-3 py-1 text-white bg-blue-600 rounded-md hover:bg-blue-700">Use Persona</button>
                    <button onClick={() => setDeletingId(p.id)} className="p-2 text-neutral-400 hover:text-red-400"><TrashIcon className="w-5 h-5"/></button>
                  </div>
                </>
              )}
            </div>
          ))
        ) : (
          <p className="text-center text-neutral-500 py-8">No personas saved.</p>
        )}
      </div>
    </Modal>
  );
};
