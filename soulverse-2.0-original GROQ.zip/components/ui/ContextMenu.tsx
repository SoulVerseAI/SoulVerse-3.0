

import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';

interface MenuItem {
  label: string;
  icon: React.ReactNode;
  action: () => void;
}

interface ContextMenuProps {
  isOpen: boolean;
  items: MenuItem[];
  onClose: () => void;
  triggerRef: React.RefObject<HTMLElement>;
  direction?: 'up' | 'down';
}

export const ContextMenu: React.FC<ContextMenuProps> = ({ isOpen, items, onClose, triggerRef, direction = 'down' }) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ top: 0, left: 0, opacity: 0 });

  useEffect(() => {
    if (isOpen && triggerRef.current && menuRef.current) {
      const triggerRect = triggerRef.current.getBoundingClientRect();
      const menuRect = menuRef.current.getBoundingClientRect();

      let top;
      if (direction === 'up') {
        top = triggerRect.top - menuRect.height;
        // Flip to down if it goes off the top of the screen
        if (top < 0) {
          top = triggerRect.bottom;
        }
      } else { // 'down'
        top = triggerRect.bottom;
        // Flip to up if it goes off the bottom of the screen
        if (top + menuRect.height > window.innerHeight) {
          top = triggerRect.top - menuRect.height;
        }
      }

      let left = triggerRect.left;

      // Adjust if menu goes off the right edge of the screen
      if (left + menuRect.width > window.innerWidth) {
        left = triggerRect.right - menuRect.width;
      }
      
      // Ensure it doesn't go off the left edge
      if (left < 0) {
        left = 0;
      }

      requestAnimationFrame(() => {
        setPosition({ top: top + window.scrollY, left: left + window.scrollX, opacity: 1 });
      });
    }
  }, [isOpen, triggerRef, direction]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isOpen &&
        menuRef.current && !menuRef.current.contains(event.target as Node) &&
        triggerRef.current && !triggerRef.current.contains(event.target as Node)
      ) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose, triggerRef]);

  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <div
      ref={menuRef}
      className="fixed w-64 bg-gradient-cyan-purple border border-white/10 rounded-xl shadow-2xl z-[200] p-2 transition-opacity duration-150"
      role="menu"
      aria-orientation="vertical"
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
        opacity: position.opacity
      }}
    >
      {items.map((item, index) => (
        <button
          key={index}
          onClick={() => {
            item.action();
            onClose();
          }}
          className="w-full flex items-center px-4 py-3 text-base font-medium text-white hover:bg-white/10 text-left rounded-md"
          role="menuitem"
        >
          <span className="mr-4 text-neutral-200">{item.icon}</span>
          {item.label}
        </button>
      ))}
    </div>,
    document.body
  );
};