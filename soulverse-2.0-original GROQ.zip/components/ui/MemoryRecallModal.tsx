
import React, { useState } from 'react';
import { Soul, LongTermMemory } from '../../types';
import { PencilIcon, XMarkIcon, PlusIcon } from '../icons/Icons';
import { Modal } from './Modal';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MemoryItemProps {
    memory: LongTermMemory;
    onDelete: (id: string) => void;
    onUpdate: (id: string, summary: string) => void;
    onDeprioritize: (memory: LongTermMemory) => void;
}

const MemoryItem: React.FC<MemoryItemProps> = ({ memory, onDelete, onUpdate, onDeprioritize }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState(memory.summary);

    const handleSave = () => {
        onUpdate(memory.id, editText);
        setIsEditing(false);
    };

    const handleCancel = () => {
        setEditText(memory.summary);
        setIsEditing(false);
    };

    return (
        <div className="p-4 bg-neutral-800/50 rounded-lg text-neutral-300 text-sm border border-neutral-700">
            {isEditing ? (
                <div className="space-y-2">
                    <textarea 
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        rows={4}
                        className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                    <div className="flex justify-end gap-2">
                        <button onClick={handleCancel} className="text-xs px-2 py-1 rounded hover:bg-neutral-700">Cancel</button>
                        <button onClick={handleSave} className="text-xs px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white">Save</button>
                    </div>
                </div>
            ) : (
                <div className="flex items-start justify-between gap-2">
                    <div className="prose prose-sm prose-invert max-w-none prose-p:my-0 flex-1 whitespace-pre-wrap break-words">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>{memory.summary}</ReactMarkdown>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                        <button onClick={() => onDeprioritize(memory)} className="text-xs text-neutral-400 hover:text-red-400 underline">Deprioritize</button>
                        <button onClick={() => setIsEditing(true)} className="p-1 rounded-full text-neutral-400 hover:text-white" title="Edit"><PencilIcon className="w-4 h-4" /></button>
                        <button onClick={() => onDelete(memory.id)} className="p-1 rounded-full text-neutral-400 hover:text-red-400" title="Delete"><XMarkIcon className="w-4 h-4" /></button>
                    </div>
                </div>
            )}
        </div>
    );
};

const AddMemoryForm: React.FC<{ onSave: (text: string) => void, onCancel: () => void }> = ({ onSave, onCancel }) => {
    const [text, setText] = useState('');
    
    const handleSave = () => {
        if (text.trim()) {
            onSave(text.trim());
        }
    };

    return (
        <div className="p-4 bg-neutral-800 rounded-lg border border-blue-500/50 space-y-2">
            <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={4}
                className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                placeholder="Enter new memory summary..."
            />
            <div className="flex justify-end gap-2">
                <button onClick={onCancel} className="text-xs px-2 py-1 rounded hover:bg-neutral-700">Cancel</button>
                <button onClick={handleSave} className="text-xs px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white">Save Memory</button>
            </div>
        </div>
    );
};


interface MemoryRecallModalProps {
    isOpen: boolean;
    onClose: () => void;
    soul: Soul | null;
    memories: LongTermMemory[];
    onDeleteMemory: (memoryId: string) => void;
    onUpdateMemory: (memoryId: string, newSummary: string) => void;
    onAddMemory: (summary: string) => Promise<void>;
}

export const MemoryRecallModal: React.FC<MemoryRecallModalProps> = ({ isOpen, onClose, soul, memories, onDeleteMemory, onUpdateMemory, onAddMemory }) => {
    const [isAdding, setIsAdding] = useState(false);
    const [memoryToDeprioritize, setMemoryToDeprioritize] = useState<LongTermMemory | null>(null);

    const handleSaveNewMemory = async (summary: string) => {
        await onAddMemory(summary);
        setIsAdding(false);
    };

    const handleDeprioritizeConfirm = () => {
        if (memoryToDeprioritize) {
            onDeleteMemory(memoryToDeprioritize.id);
            setMemoryToDeprioritize(null);
        }
    };

    const title = (
        <div className="flex items-center gap-4">
            <span>{soul?.name || 'Soul'}'s Recalled Memories</span>
            <button
                onClick={() => setIsAdding(prev => !prev)}
                className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-700/60 transition-colors"
                title="Add new memory"
            >
                <PlusIcon className="w-5 h-5" />
            </button>
        </div>
    );
    
    return (
        <>
            <Modal isOpen={isOpen} onClose={onClose} title={title} maxWidth="max-w-4xl">
                <div className="p-6 text-neutral-300 space-y-6 min-w-[300px]">
                    <div>
                        <p className="text-sm text-neutral-400 mb-4">
                            Long term memories are consolidated over time, and journal entries may be edited in Backstory menu. For more, see the user guide.
                        </p>
                    </div>

                    <div className="space-y-2">
                        <h3 className="text-lg font-semibold text-white">Journal entries</h3>
                        <div className="p-4 bg-neutral-800/50 rounded-lg text-neutral-400 text-sm">
                            No recalled journal entries.
                        </div>
                    </div>

                    <div className="space-y-2">
                        <h3 className="text-lg font-semibold text-white">Long term memories</h3>
                        <p className="text-sm text-neutral-400">
                        The following memories were recalled by your Soul to generate this response.
                        </p>
                        <div className="max-h-96 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                            {isAdding && <AddMemoryForm onSave={handleSaveNewMemory} onCancel={() => setIsAdding(false)} />}
                            {memories.length > 0 ? (
                                [...memories].sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()).map(ltm => (
                                    <MemoryItem 
                                        key={ltm.id}
                                        memory={ltm}
                                        onDelete={onDeleteMemory}
                                        onUpdate={onUpdateMemory}
                                        onDeprioritize={setMemoryToDeprioritize}
                                    />
                                ))
                            ) : (
                                !isAdding && (
                                    <div className="p-4 bg-neutral-800/50 rounded-lg text-neutral-400 text-sm mt-2">
                                        No long term memories were recalled for this message.
                                    </div>
                                )
                            )}
                        </div>
                    </div>
                </div>
            </Modal>

            {memoryToDeprioritize && (
                <Modal 
                    isOpen={!!memoryToDeprioritize} 
                    onClose={() => setMemoryToDeprioritize(null)} 
                    title="Deprioritize this long term memory?"
                    maxWidth="max-w-md"
                >
                    <div className="p-6 space-y-4">
                        <p className="text-sm text-neutral-300">This makes the memory much less likely to surface given similar context.</p>
                        <div className="flex justify-end gap-4 pt-2">
                            <button onClick={() => setMemoryToDeprioritize(null)} className="py-2 px-6 rounded-md text-sm font-medium bg-neutral-700 hover:bg-neutral-600">
                                Cancel
                            </button>
                            <button onClick={handleDeprioritizeConfirm} className="py-2 px-6 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700">
                                Confirm deprioritize
                            </button>
                        </div>
                    </div>
                </Modal>
            )}
        </>
    );
};
