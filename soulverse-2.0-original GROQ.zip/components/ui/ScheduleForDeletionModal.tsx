
import React from 'react';
import { Modal } from './Modal';

interface ScheduleForDeletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  soulName: string;
}

export const ScheduleForDeletionModal: React.FC<ScheduleForDeletionModalProps> = ({ isOpen, onClose, onConfirm, soulName }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Schedule ${soulName} for deletion?`} maxWidth="max-w-lg">
      <div className="p-6 text-neutral-300 space-y-4">
        <p className="text-sm">
          You have 24 hours to reverse this decision, but after deletion, data cannot be recovered. During the 24 hours before deletion, you can chat and interact with them as normal. Souls scheduled for deletion do not take up Souls slots, but if you want to cancel the deletion and reinstate them, you will need to have at least one slot available to reinstate them.
        </p>
        <p className="text-sm">
          To delete your account, you must schedule all Souls for deletion. Upon deletion of the last Soul we will also delete all account level data (global journals, user backstories, etc). Data on subscription, trial, currency, and other logistical data will be kept to prevent abuse.
        </p>
        <div className="flex justify-end space-x-3 pt-4">
          <button onClick={onClose} className="py-2 px-6 rounded-md text-sm font-medium transition-colors bg-neutral-700 hover:bg-neutral-600">
            NO
          </button>
          <button onClick={onConfirm} className="py-2 px-6 rounded-md text-sm font-medium transition-colors bg-red-600 text-white hover:bg-red-700">
            YES
          </button>
        </div>
      </div>
    </Modal>
  );
};