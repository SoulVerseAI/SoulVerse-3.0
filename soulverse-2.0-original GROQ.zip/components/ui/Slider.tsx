
import React from 'react';

interface SliderProps {
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (value: number) => void;
}

export const Slider: React.FC<SliderProps> = ({ min, max, step, value, onChange }) => {
  const percentage = ((value - min) / (max - min)) * 100;

  const backgroundStyle = {
    background: `linear-gradient(to right, #2563eb ${percentage}%, #404040 ${percentage}%)`
  };

  return (
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="w-full h-2 rounded-lg appearance-none cursor-pointer"
      style={backgroundStyle}
    />
  );
};