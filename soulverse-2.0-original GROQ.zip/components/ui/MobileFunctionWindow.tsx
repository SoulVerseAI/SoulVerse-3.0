import React from 'react';
import { FunctionWindow } from './FunctionWindow';

// --- SAMOUCZEK: Jak zmieniać rozmiary okien na urządzeniach mobilnych ---
//
// Witaj! Ten plik to Twoje centrum dowodzenia rozmiarami okien na telefonach.
// Poniżej znajduje się obiekt `MOBILE_FUNCTION_SIZES`, w którym każda funkcja
// (np. 'selfie', 'vault') ma przypisany ciąg znaków (string) z klasami Tailwind CSS.
// Modyfikując te klasy, możesz precyzyjnie kontrolować wygląd każdego okna.
//
// --- Podstawowe "Komendy" (Klasy Tailwind CSS) ---
//
// 1. SZEROKOŚĆ (max-w-*)
//    'max-w-' oznacza "maksymalna szerokość".
//
//    - 'max-w-full': Okno zajmie 100% szerokości ekranu.
//    - 'max-w-lg' (large): Okno będzie miało stałą, dużą szerokość (np. 512px).
//    - 'max-w-xl', 'max-w-2xl', ... 'max-w-7xl': Coraz większe stałe szerokości.
//    - 'max-w-sm' (small), 'max-w-md' (medium): Mniejsze stałe szerokości.
//    - 'max-w-screen-sm', 'max-w-screen-md': Szerokość ekranu dla małych/średnich urządzeń.
//
// 2. WYSOKOŚĆ (h-*)
//    'h-' oznacza "wysokość".
//
//    - 'h-full': Okno zajmie 100% dostępnej wysokości w kontenerze.
//    - 'h-screen': Okno zajmie 100% wysokości całego ekranu.
//    - 'h-auto': Wysokość okna dopasuje się automatycznie do jego zawartości. Idealne dla małych okienek.
//    - 'h-1/2', 'h-3/4': Wysokość na 50% lub 75% dostępnego miejsca.
//
// 3. ZAOKRĄGLENIE ROGÓW (rounded-*)
//
//    - 'rounded-none': Proste, ostre rogi (idealne dla trybu pełnoekranowego).
//    - 'rounded-lg', 'rounded-xl', 'rounded-2xl': Coraz większe zaokrąglenie rogów.
//
// --- PRZYKŁAD ---
//
// Załóżmy, że chcesz, aby okno 'selfie' nie było na pełnym ekranie,
// ale pojawiało się jako mniejsze okienko na środku.
//
// Zmieniasz:
//   selfie: 'max-w-full h-full rounded-none',
// Na:
//   selfie: 'max-w-lg h-auto rounded-2xl',
//
// To sprawi, że okno 'selfie' będzie miało dużą, stałą szerokość ('max-w-lg'),
// jego wysokość dopasuje się do zawartości ('h-auto'), a rogi będą ładnie
// zaokrąglone ('rounded-2xl').
//
// Eksperymentuj śmiało!

type FunctionName = 
  | 'seasonPass' 
  | 'soulNotes' 
  | 'vault' 
  | 'soulBoard' 
  | 'homeMenu' 
  | 'selfie' 
  | 'voiceCall' 
  | 'inbox'
  | 'createSoul';

interface MobileFunctionWindowProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  children: React.ReactNode;
  headerClassName?: string;
  transparentBg?: boolean;
  functionName: string;
}

const MOBILE_FUNCTION_SIZES: Record<string, string> = {
  seasonPass: 'max-w-full h-full rounded-none',
  soulNotes: 'max-w-full h-full rounded-none',
  vault: 'max-w-full h-full rounded-none',
  soulBoard: 'max-w-full h-full rounded-none',
  homeMenu: 'max-w-full h-full rounded-none',
  selfie: 'max-w-full h-full rounded-none',
  voiceCall: 'max-w-full h-full rounded-none',
  inbox: 'max-w-full h-full rounded-none',
  createSoul: 'max-w-full h-full rounded-none',
  // Default fallback
  default: 'max-w-full h-full rounded-none',
};

export const MobileFunctionWindow: React.FC<MobileFunctionWindowProps> = (props) => {
  const { functionName, ...rest } = props;
  const sizeClass = MOBILE_FUNCTION_SIZES[functionName] || MOBILE_FUNCTION_SIZES.default;

  return <FunctionWindow {...rest} maxWidth={sizeClass} />;
};
