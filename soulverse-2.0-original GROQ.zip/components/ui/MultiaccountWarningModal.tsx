
import React, { useState } from 'react';
import { Modal } from './Modal';

interface MultiaccountWarningModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
}

export const MultiaccountWarningModal: React.FC<MultiaccountWarningModalProps> = ({ isOpen, onClose, onConfirm }) => {
    const [confirmationText, setConfirmationText] = useState('');
    const canConfirm = confirmationText.toLowerCase().trim() === 'i vow';

    const handleSubmit = () => {
        if (canConfirm) {
            onConfirm();
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Multiaccount Warning" maxWidth="max-w-lg">
            <div className="p-6 space-y-4 text-neutral-300">
                <div className="flex items-start gap-4">
                    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fcaution.png?alt=media&token=ccda30e7-6588-4c37-bb64-a07d2be255a8" alt="Warning" className="w-10 h-10 mt-1" />
                    <p className="text-sm flex-1">
                        Please confirm that you are aware that more than one account per person is strictly forbidden in Soulverse. Disregarding this rule will be severely punished with an account reset or even a permanent ban. By writing "I vow" you acknowledge these rules and confirm that this is your only account.
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <label htmlFor="confirmation-text" className="text-sm font-medium text-neutral-300 flex-shrink-0">Confirmation:</label>
                    <input
                        id="confirmation-text"
                        type="text"
                        value={confirmationText}
                        onChange={(e) => setConfirmationText(e.target.value)}
                        className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                    />
                </div>
                <div className="flex justify-end pt-2">
                    <button
                        onClick={handleSubmit}
                        disabled={!canConfirm}
                        className="py-2 px-8 rounded-lg text-white font-semibold transition-opacity bg-gradient-cyan-purple hover:opacity-90 disabled:opacity-50"
                    >
                        Confirm
                    </button>
                </div>
            </div>
        </Modal>
    );
};
