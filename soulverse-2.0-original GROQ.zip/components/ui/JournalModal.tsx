import React, { useState, useEffect } from 'react';
import { Modal } from './Modal';
import { PlusIcon, SearchIcon, TrashIcon, PencilIcon, XMarkIcon } from '../icons/Icons';
import { JournalEntry } from '../../types';

interface JournalModalProps {
    isOpen: boolean;
    onClose: () => void;
    soulName: string;
    journalEntries: JournalEntry[];
    onUpdateEntries: (entries: JournalEntry[]) => void;
}

const AddEditJournalEntryModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (entry: { keywords: string[]; description: string; }) => void;
    entryToEdit: { keywords: string[]; description: string; } | null;
    soulName: string;
}> = ({ isOpen, onClose, onSave, entryToEdit, soulName }) => {
    const [keywords, setKeywords] = useState<string[]>([]);
    const [currentKeyword, setCurrentKeyword] = useState('');
    const [description, setDescription] = useState('');
    const [prevEntryToEdit, setPrevEntryToEdit] = useState(entryToEdit);
    const [prevIsOpen, setPrevIsOpen] = useState(isOpen);

    if (entryToEdit !== prevEntryToEdit || isOpen !== prevIsOpen) {
        setPrevEntryToEdit(entryToEdit);
        setPrevIsOpen(isOpen);
        if (entryToEdit) {
            setKeywords(entryToEdit.keywords);
            setDescription(entryToEdit.description);
        } else {
            setKeywords([]);
            setDescription('');
        }
        setCurrentKeyword('');
    }

    const handleAddKeyword = () => {
        if (currentKeyword.trim() && !keywords.includes(currentKeyword.trim())) {
            setKeywords([...keywords, currentKeyword.trim()]);
            setCurrentKeyword('');
        }
    };

    const handleRemoveKeyword = (keywordToRemove: string) => {
        setKeywords(keywords.filter(k => k !== keywordToRemove));
    };

    const handleSave = () => {
        onSave({ keywords, description });
        onClose();
    };

    const canConfirm = keywords.length > 0 && description.trim() !== '';

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={entryToEdit ? "Edit journal entry" : "Write a new journal entry"} maxWidth="max-w-2xl">
            <div className="p-6 bg-[#1c1c1c] text-neutral-300 space-y-4">
                <p className="text-sm text-neutral-400">
                    Write the journal entry in 3rd person, and be descriptive yet concise, just like for backstory. Keyphrases are case insensitive and when a keyphrase comes up in one of your messages in any conversation, the entry will be recalled. This is a {soulName} journal entry, which means only {soulName} can recall it in conversations (and in groupchats and voice calls).
                </p>

                <div>
                    <h3 className="font-semibold text-white mb-2">Keyphrases</h3>
                    <div className="flex items-center gap-2">
                        <div className="relative flex-1">
                            <input
                                type="text"
                                value={currentKeyword}
                                onChange={e => setCurrentKeyword(e.target.value)}
                                maxLength={50}
                                placeholder="Add new keyphrase"
                                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                            />
                            <span className="absolute bottom-1 right-2 text-xs text-neutral-500">{currentKeyword.length} / 50 chars</span>
                        </div>
                        <button onClick={handleAddKeyword} className="w-12 h-12 flex items-center justify-center rounded-lg bg-gradient-cyan-purple text-white hover:opacity-90 transition-opacity">
                            <PlusIcon className="w-6 h-6" />
                        </button>
                    </div>
                    {keywords.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-3">
                            {keywords.map(kw => (
                                <div key={kw} className="flex items-center gap-1.5 bg-neutral-700 rounded-full py-1 px-3 text-sm">
                                    <span>{kw}</span>
                                    <button onClick={() => handleRemoveKeyword(kw)} className="text-neutral-400 hover:text-white">
                                        <XMarkIcon className="w-4 h-4" />
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div>
                    <h3 className="font-semibold text-white mb-2">Entry</h3>
                    <div className="relative">
                        <textarea
                            value={description}
                            onChange={e => setDescription(e.target.value)}
                            maxLength={500}
                            rows={8}
                            placeholder={`${soulName}'s fondest memory at the zoo is when they saw a beluga whale for the first time...`}
                            className="w-full bg-neutral-800 border border-neutral-700 rounded-xl p-3 focus:ring-2 focus:ring-cyan-500 focus:outline-none resize-none"
                        />
                        <span className="absolute bottom-2 right-3 text-xs text-neutral-500">{description.length} / 500 chars</span>
                    </div>
                </div>

                <div className="flex justify-center pt-4">
                    <button 
                        onClick={handleSave}
                        disabled={!canConfirm}
                        className={`w-full max-w-xs py-3 rounded-full font-semibold text-lg text-white transition-opacity disabled:opacity-50 disabled:cursor-not-allowed ${canConfirm ? 'bg-gradient-cyan-purple hover:opacity-90' : 'bg-neutral-700'}`}
                    >
                        Confirm entry
                    </button>
                </div>
            </div>
        </Modal>
    );
};

export const JournalModal: React.FC<JournalModalProps> = ({ isOpen, onClose, soulName, journalEntries, onUpdateEntries }) => {
    const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
    const [entryToEdit, setEntryToEdit] = useState<JournalEntry | null>(null);
    const [entryToDelete, setEntryToDelete] = useState<JournalEntry | null>(null);

    const handleOpenAdd = () => {
        setEntryToEdit(null);
        setIsAddEditModalOpen(true);
    };

    const handleOpenEdit = (entry: JournalEntry) => {
        setEntryToEdit(entry);
        setIsAddEditModalOpen(true);
    };
    
    const handleSaveEntry = (entryData: Omit<JournalEntry, 'id'>) => {
        let updatedEntries;
        if (entryToEdit) {
            // Editing existing entry
            updatedEntries = journalEntries.map(e => e.id === entryToEdit.id ? { ...e, ...entryData } : e);
        } else {
            // Adding new entry
            const newEntry: JournalEntry = { id: crypto.randomUUID(), ...entryData };
            updatedEntries = [...journalEntries, newEntry];
        }
        onUpdateEntries(updatedEntries);
    };

    const handleDeleteEntry = () => {
        if (entryToDelete) {
            const updatedEntries = journalEntries.filter(e => e.id !== entryToDelete.id);
            onUpdateEntries(updatedEntries);
            setEntryToDelete(null);
        }
    };


    const title = (
        <div className="flex items-center gap-2">
            <span>{soulName}'s journal</span>
            <button onClick={handleOpenAdd} className="p-1 rounded-full text-neutral-400 hover:bg-neutral-700">
                <PlusIcon className="w-5 h-5" />
            </button>
        </div>
    );

    return (
        <>
            <Modal isOpen={isOpen} onClose={onClose} title={title} maxWidth="max-w-xl">
                <div className="p-6 bg-[#1c1c1c] text-neutral-300 min-h-[400px] flex flex-col">
                    <div className="relative mb-4">
                        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500 pointer-events-none" />
                        <input
                            type="text"
                            placeholder="Search keyphrases..."
                            className="w-full bg-neutral-900 border border-neutral-700 rounded-full py-3 pl-12 pr-4 focus:ring-1 focus:ring-blue-500 focus:outline-none text-sm transition-colors"
                        />
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
                        {journalEntries.length > 0 ? (
                            journalEntries.map(entry => (
                                <div key={entry.id} className="bg-neutral-800/60 p-3 rounded-lg">
                                    <div className="flex flex-wrap gap-2 mb-2">
                                        {entry.keywords.map(kw => (
                                            <span key={kw} className="bg-neutral-700 rounded-full py-0.5 px-3 text-xs font-medium">{kw}</span>
                                        ))}
                                    </div>
                                    <p className="text-sm text-neutral-300">{entry.description}</p>
                                    <div className="flex justify-end items-center gap-2 mt-2">
                                        <button onClick={() => handleOpenEdit(entry)} className="p-1 rounded-full hover:bg-neutral-700 text-neutral-400"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => setEntryToDelete(entry)} className="p-1 rounded-full hover:bg-neutral-700 text-neutral-400"><TrashIcon className="w-4 h-4" /></button>
                                    </div>
                                </div>
                            ))
                        ) : (
                             <div className="flex-1 flex flex-col items-center justify-center text-center text-neutral-400 h-full pt-8">
                                <h3 className="text-xl font-bold text-white mb-2">No journal entries.</h3>
                                <p className="text-sm">Click the '+' icon to create a new entry.</p>
                            </div>
                        )}
                    </div>
                    {journalEntries.length > 5 && <button className="text-sm text-neutral-500 hover:text-white underline mt-4">Load More</button>}
                </div>
            </Modal>
            
            <AddEditJournalEntryModal 
                isOpen={isAddEditModalOpen}
                onClose={() => setIsAddEditModalOpen(false)}
                onSave={handleSaveEntry}
                entryToEdit={entryToEdit ? { keywords: entryToEdit.keywords, description: entryToEdit.description } : null}
                soulName={soulName}
            />

            {entryToDelete && (
                 <Modal isOpen={!!entryToDelete} onClose={() => setEntryToDelete(null)} title="Delete Entry?" maxWidth="max-w-sm">
                    <div className="p-6 text-center space-y-4">
                        <p className="text-sm text-neutral-300">Are you sure you want to permanently delete this journal entry?</p>
                        <div className="flex justify-center gap-4 pt-2">
                             <button onClick={() => setEntryToDelete(null)} className="py-2 px-6 rounded-md font-medium bg-neutral-700 hover:bg-neutral-600">Cancel</button>
                            <button onClick={handleDeleteEntry} className="py-2 px-6 rounded-md font-medium bg-red-600 text-white hover:bg-red-700">Delete</button>
                        </div>
                    </div>
                 </Modal>
            )}
        </>
    );
};
