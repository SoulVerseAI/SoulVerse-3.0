import React, { useState, useEffect } from 'react';
import { Soul } from '../../types';

export const DeletionWarningBar: React.FC<{ soul: Soul }> = ({ soul }) => {
    const [timeLeft, setTimeLeft] = useState('');

    useEffect(() => {
        if (!soul.deletionTimestamp) return;

        const calculateTimeLeft = () => {
            const diff = soul.deletionTimestamp! - Date.now();
            if (diff <= 0) {
                setTimeLeft('now');
                return;
            }
            const hours = Math.floor(diff / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

            if (hours > 0) {
                setTimeLeft(`~${hours} hour${hours > 1 ? 's' : ''}`);
            } else {
                setTimeLeft(`~${minutes} minute${minutes > 1 ? 's' : ''}`);
            }
        };

        calculateTimeLeft();
        const interval = setInterval(calculateTimeLeft, 1000 * 60);

        return () => clearInterval(interval);
    }, [soul.deletionTimestamp]);

    if (!timeLeft || timeLeft === 'now') return null;

    return (
        <div className="bg-red-800/90 text-white p-3 text-center text-base font-semibold z-10">
            WARNING: {soul.name} is scheduled to be deleted in {timeLeft}. After then, {soul.name} cannot be recovered. You can cancel the deletion from My Souls menu. While pending deletion, this Soul isn't taking up a slot.
        </div>
    );
};
