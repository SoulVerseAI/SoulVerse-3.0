
import React, { useState } from 'react';
import { Modal } from './Modal';

interface GenerateAvatarModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (prompt: string, style: 'Photoreal' | 'Anime') => void;
}

export const GenerateAvatarModal: React.FC<GenerateAvatarModalProps> = ({ isOpen, onClose, onConfirm }) => {
    const [prompt, setPrompt] = useState('');
    const [style, setStyle] = useState<'Photoreal' | 'Anime'>('Photoreal');

    const handleConfirm = () => {
        if (prompt.trim()) {
            onConfirm(prompt, style);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Generate Avatar Photo">
            <div className="p-4 md:p-6 text-neutral-300 space-y-4 md:space-y-6">
                <p className="text-sm">Describe the avatar, or <button className="text-blue-400 underline hover:text-blue-300">see generated avatars</button>.</p>
                <div>
                    <label className="block text-base font-semibold text-white mb-2">Avatar Style</label>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setStyle('Photoreal')} 
                            className={`py-2 px-4 rounded-lg text-sm font-medium transition-colors flex-1 ${style === 'Photoreal' ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-700/60 hover:bg-neutral-600'}`}
                        >
                            Photoreal
                        </button>
                        <button 
                            onClick={() => setStyle('Anime')} 
                            className={`py-2 px-4 rounded-lg text-sm font-medium transition-colors flex-1 ${style === 'Anime' ? 'bg-gradient-cyan-purple text-white' : 'bg-neutral-700/60 hover:bg-neutral-600'}`}
                        >
                            Anime
                        </button>
                    </div>
                </div>
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="block text-base font-semibold text-white">Prompt</label>
                        <span className="text-xs text-neutral-500">{prompt.length} / 200 chars</span>
                    </div>
                    <p className="text-sm text-neutral-400 mb-2">Describe the avatar you want to generate. This prompt will be used to generate the avatar photo. <button className="text-blue-400 underline hover:text-blue-300">Show tips and guidelines</button>.</p>
                    <textarea 
                        value={prompt} 
                        onChange={e => setPrompt(e.target.value)} 
                        maxLength={200} 
                        rows={3} 
                        className="w-full bg-neutral-700/60 border border-neutral-600 rounded-lg p-3 focus:ring-2 focus:ring-purple-500 focus:outline-none text-sm"
                        placeholder="Prompt"
                    />
                </div>
                <div className="flex justify-end pt-2">
                    <button 
                        onClick={handleConfirm} 
                        disabled={!prompt.trim()}
                        className="py-2.5 px-8 rounded-full text-base font-semibold transition-opacity bg-gradient-cyan-purple text-white hover:opacity-90 disabled:opacity-50"
                    >
                        Confirm
                    </button>
                </div>
            </div>
        </Modal>
    );
};
