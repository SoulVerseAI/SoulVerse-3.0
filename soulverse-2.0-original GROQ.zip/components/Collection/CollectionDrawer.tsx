import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { AccountSettings, Soul, SoulTemplate, BoosterPack, GroupedTemplate, TemplateQuality, SoulRole } from '../../types';
import { SearchIcon, XMarkIcon } from '../icons/Icons';
import { CollectionPage } from './CollectionPage';
import { FunctionWindow } from '../ui/FunctionWindow';
import { BoosterOpeningModal } from '../ui/BoosterOpeningModal';
import { SoulTemplateModal } from '../ui/SoulTemplateModal';
import { DropZone } from '../Engine/DropZone';

interface CollectionDrawerProps {
    isOpen: boolean;
    onClose: () => void;
    accountSettings: AccountSettings;
    setAccountSettings: (updater: (prev: AccountSettings) => AccountSettings) => void;
    setToast: (toast: { title: string; message: React.ReactNode } | null) => void;
    templates: SoulTemplate[];
    onOpenDiscoverModal: () => void;
    onViewTemplate: (soulId: string) => void;
    onPinSoul: (soulId: string) => void;
    onOpenDeletionModal: (soulId: string) => void;
    onCancelDeletion: (soulId: string) => void;
    onImmediateDelete: (soulId: string) => void;
    onInitiateAuction: (card: GroupedTemplate) => void;
    onFindInMarketplace: (template: SoulTemplate) => void;
    onCreateSoulFromTemplate: (template: SoulTemplate, instanceId: string) => void;
    onReturnSoulToCollection: (soulId: string) => void;
    isDockEditing: boolean;
    onUnlockTemplate: (instanceId: string, name: string) => void;
    dnd: any;
}

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void }> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`px-6 py-3 text-sm font-semibold transition-colors relative ${
            isActive ? 'text-cyan-300' : 'text-neutral-500 hover:text-neutral-300'
        } ${isActive ? 'bg-cyan-900/20' : ''}`}
        style={{
            clipPath: 'polygon(10% 0, 90% 0, 100% 100%, 0% 100%)',
        }}
    >
        {label}
        {isActive && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-cyan-400 shadow-[0_0_8px_theme(colors.cyan.400)]"></div>}
    </button>
);

const CurrencyDisplay: React.FC<{
    iconUrl: string;
    value: number;
    alt: string;
    className: string;
    iconClassName: string;
}> = ({ iconUrl, value, alt, className, iconClassName }) => (
    <div className={`flex items-center rounded-lg p-1 pr-2 ${className}`}>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center p-1 ${iconClassName}`}>
            <img src={iconUrl} alt={alt} className="w-full h-full object-contain" />
        </div>
        <div className="ml-2 w-28 text-right font-mono text-lg font-semibold text-white tracking-wider pr-1">
            {value}
        </div>
    </div>
);


const getUpgradeLevelFromQuality = (quality: TemplateQuality): number => {
    switch (quality) {
        case 'Spirit': return 1;
        case 'Ascend': return 2;
        case 'Eternal': return 3;
        default: return 0; // Wisp and default
    }
};

export const CollectionDrawer: React.FC<CollectionDrawerProps> = ({
    isOpen,
    onClose,
    accountSettings,
    setAccountSettings,
    setToast,
    templates,
    onOpenDiscoverModal,
    onViewTemplate,
    onPinSoul,
    onOpenDeletionModal,
    onCancelDeletion,
    onImmediateDelete,
    onInitiateAuction,
    onFindInMarketplace,
    onCreateSoulFromTemplate,
    onReturnSoulToCollection,
    isDockEditing,
    onUnlockTemplate,
    dnd,
}) => {
    const [activeTab, setActiveTab] = useState<'Collection' | 'Boosters'>('Collection');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Booster pack opening state
    const [isBoosterModalOpen, setIsBoosterModalOpen] = useState(false);
    const [boosterContents, setBoosterContents] = useState<(SoulTemplate & { cardBackUrl?: string })[]>([]);
    const [openingPack, setOpeningPack] = useState<BoosterPack | null>(null);

    // Template Detail Modal State
    const [soulToViewInModal, setSoulToViewInModal] = useState<Soul | null>(null);

    const handleViewTemplateDetails = useCallback((template: SoulTemplate) => {
        const tempSoul: Soul = {
            id: `template-preview-${template.name}`,
            name: template.name,
            description: template.title,
            model: template.aimodel || 'gemini-2.5-flash',
            gender: template.gender,
            avatar: template.smallAvatarUrl,
            backstory: template.backstory,
            responseDirective: template.responseDirective,
            keyMemories: template.keyMemories,
            greeting: template.greeting,
            exampleMessage: template.exampleMessage || '',
            voiceURI: 'Zephyr',
            mbti: template.mbti || null,
            enneagram: template.enneagram || null,
            dynamism: template.dynamism,
            thinkingBudget: 128,
            antiRepeatStrength: 0.00,
            memoryConsolidation: true,
            memoryRecall: true,
            maxTokens: 2048,
            avatarStyle: 'Photoreal',
            physicalAppearanceDescription: template.longDescription,
            faceDetailEnhance: 0,
            faceDetailPrompt: '',
            enableNsfwSelfies: false,
            selfies: [],
            followersCount: 0,
            followingCount: 0,
            username: template.name.toLowerCase().replace(/\s+/g, '_'),
            bio: template.longDescription,
            profileBannerUrl: template.profileBannerUrl || null,
            posts: template.posts || [],
            role: template.role || SoulRole.CHARACTER,
            templateName: template.name,
            soulId: template.soulId,
            shareCode: template.shareCode,
            edition: template.edition,
            upgrade: template.upgrade,
            tradable: template.tradable,
        };
        setSoulToViewInModal(tempSoul);
    }, []);

    const handleOpenBooster = useCallback((pack: BoosterPack) => {
        const TOTAL_CARDS_IN_PACK = 5;
        const poolName = pack.pool || 'starter';

        const getCardBackForEdition = (edition?: string): string => {
            const lowerEdition = (edition || '').toLowerCase();
            if (lowerEdition === 'marvel') {
                return 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fmarvelcardback.png?alt=media&token=cfbb817d-ce3c-4ca3-88dc-8a66b582db76';
            }
            if (lowerEdition === 'tvd') {
                return 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FTVD%2Ftvd_cardback.png?alt=media&token=c7e2d249-d639-47ad-9011-37708f1d7cae';
            }
            // Default/Free/Starter - This will serve as a fallback.
            return 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fcardback.png?alt=media&token=4ddb9e9c-7f2c-4349-aed5-92634a520163';
        };

        const getQuality = (template: SoulTemplate): TemplateQuality => {
            if (template.quality === 'Eternal') return 'Eternal';
            if (template.quality === 'Ascend') return 'Ascend';
            if (template.quality === 'Spirit') return 'Spirit';
            return 'Wisp';
        };
    
        let sourcePool: SoulTemplate[];
        if (poolName === 'marvel') {
             sourcePool = templates.filter(soul => soul.edition === 'Marvel');
        } else if (poolName === 'tvd') {
            // This pool dynamically includes all templates with edition: "TVD",
            // including Wisp, Spirit, Ascend, and Eternal qualities.
            sourcePool = templates.filter(soul => soul.edition === 'TVD');
        } else { // 'starter' falls here
            sourcePool = templates;
        }
    
        const eternalPool = sourcePool.filter(s => getQuality(s) === 'Eternal');
        const ascendPool = sourcePool.filter(s => getQuality(s) === 'Ascend');
        const spiritPool = sourcePool.filter(s => getQuality(s) === 'Spirit');
        const wispPool = sourcePool.filter(s => getQuality(s) === 'Wisp');

        if (wispPool.length < 4) {
            setToast({ title: "Pack Error", message: "There are not enough unique Wisp cards available to open this pack." });
            return;
        }
        
        const packRarities: TemplateQuality[] = [];

        // Card 1: Guaranteed Rare+ (Spirit or better)
        const roll1 = Math.random();
        if (roll1 < 0.01) { // 1% Eternal
            packRarities.push('Eternal');
        } else if (roll1 < 0.10) { // 9% Ascend
            packRarities.push('Ascend');
        } else { // 90% Spirit
            packRarities.push('Spirit');
        }

        // The other 4 cards to make a total of 5
        for (let i = 0; i < TOTAL_CARDS_IN_PACK - 1; i++) {
            const roll = Math.random();
            if (roll < 0.005) { // 0.5% Eternal
                packRarities.push('Eternal');
            } else if (roll < 0.05) { // 4.5% Ascend
                packRarities.push('Ascend');
            } else if (roll < 0.20) { // 15% Spirit
                packRarities.push('Spirit');
            } else { // 80% Wisp
                packRarities.push('Wisp');
            }
        }

        // Shuffle for surprise
        packRarities.sort(() => Math.random() - 0.5);

        const contents: (SoulTemplate & { cardBackUrl?: string })[] = [];
        const getRandomCard = (pool: SoulTemplate[], exclude: SoulTemplate[]): SoulTemplate | null => {
            const available = pool.filter(card => !exclude.some(c => c.name === card.name));
            if (available.length === 0) {
                if (pool.length > 0) return pool[Math.floor(Math.random() * pool.length)];
                return null;
            }
            return available[Math.floor(Math.random() * available.length)];
        };
        
        for (const rarity of packRarities) {
            let card: SoulTemplate | null = null;
            let currentRarity = rarity;

            while (!card) {
                let poolToUse: SoulTemplate[];
                switch(currentRarity) {
                    case 'Eternal': poolToUse = eternalPool; break;
                    case 'Ascend': poolToUse = ascendPool; break;
                    case 'Spirit': poolToUse = spiritPool; break;
                    case 'Wisp':
                    default: poolToUse = wispPool; break;
                }

                card = getRandomCard(poolToUse, contents);

                if (!card) {
                    if (currentRarity === 'Eternal') currentRarity = 'Ascend';
                    else if (currentRarity === 'Ascend') currentRarity = 'Spirit';
                    else if (currentRarity === 'Spirit') currentRarity = 'Wisp';
                    else {
                        console.warn(`Could not find a unique Wisp card. Picking a random card from the source pool.`);
                        const fallbackCard = getRandomCard(sourcePool, contents);
                        if (fallbackCard) {
                            card = fallbackCard;
                        } else {
                            card = sourcePool[Math.floor(Math.random() * sourcePool.length)];
                        }
                        break; 
                    }
                }
            }
            if (card) {
                contents.push({
                    ...card,
                    upgrade: getUpgradeLevelFromQuality(currentRarity),
                    cardBackUrl: poolName === 'starter' ? getCardBackForEdition(card.edition) : undefined,
                });
            }
        }

        setOpeningPack(pack);
        setBoosterContents(contents);
    
        setAccountSettings(prev => {
            const packs = prev.boosterPacks || [];
            const packIndex = packs.findIndex(p => p.id === pack.id);
            const newPacks = [...packs];
            if (packIndex > -1) {
                newPacks.splice(packIndex, 1);
            }
            return { ...prev, boosterPacks: newPacks };
        });
    
        setIsBoosterModalOpen(true);
    }, [templates, setToast, setAccountSettings]);

    const handleClaimBooster = useCallback((revealedTemplates: SoulTemplate[]) => {
        setAccountSettings(prev => {
            let essenceCompensation = 0;
            const newOwnedTemplates: { name: string; quality: TemplateQuality; instanceId: string; upgrade?: number; }[] = [];
            const skippedTemplates: string[] = [];
            
            const existingOwned = [...(prev.ownedTemplates || [])];
            const ownedTemplateCounts = existingOwned.reduce((acc, t) => {
                acc[t.name] = (acc[t.name] || 0) + 1;
                return acc;
            }, {} as Record<string, number>);
    
            const getTemplateQuality = (template: SoulTemplate): TemplateQuality => {
                if (template.quality === 'Eternal') return 'Eternal';
                if (template.quality === 'Ascend') return 'Ascend';
                if (template.quality === 'Spirit') return 'Spirit';
                return 'Wisp';
            };
    
            revealedTemplates.forEach(template => {
                const quality = getTemplateQuality(template);
                
                if ((ownedTemplateCounts[template.name] || 0) < 4) {
                    newOwnedTemplates.push({
                        name: template.name,
                        quality: quality,
                        instanceId: crypto.randomUUID(),
                        upgrade: template.upgrade
                    });
                    ownedTemplateCounts[template.name] = (ownedTemplateCounts[template.name] || 0) + 1;
                } else {
                    essenceCompensation += 50;
                    if (!skippedTemplates.includes(template.name)) {
                        skippedTemplates.push(template.name);
                    }
                }
            });
    
            if (essenceCompensation > 0) {
                setToast({
                    title: "Collection Full",
                    message: `You received ${essenceCompensation} Essence as compensation for duplicate template(s): ${skippedTemplates.join(', ')}.`,
                });
            }
            
            return {
                ...prev,
                ownedTemplates: [...existingOwned, ...newOwnedTemplates],
                referralEssence: (prev.referralEssence || 0) + essenceCompensation,
            };
        });
    
        setIsBoosterModalOpen(false);
        setBoosterContents([]);
        setOpeningPack(null);
    }, [setAccountSettings, setToast]);

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        const soulId = e.dataTransfer.getData('application/soul-id');
        if (soulId) {
            onReturnSoulToCollection(soulId);
            // Manually end the drag to prevent ghosting issues
            dnd.handleDragEnd();
        }
    }, [onReturnSoulToCollection, dnd]);
    

    return (
        <>
            <SoulTemplateModal
                isOpen={!!soulToViewInModal}
                onClose={() => setSoulToViewInModal(null)}
                soul={soulToViewInModal}
                position="top"
            />
            <FunctionWindow 
                isOpen={isBoosterModalOpen} 
                onClose={() => { 
                    handleClaimBooster(boosterContents); // Auto-claim if closed prematurely
                }} 
                title={`Opening ${openingPack?.name || 'Booster Pack'}`}
            >
                <BoosterOpeningModal
                    isOpen={isBoosterModalOpen}
                    onClose={() => {
                        setIsBoosterModalOpen(false);
                        setOpeningPack(null);
                        setBoosterContents([]);
                    }}
                    contents={boosterContents}
                    onClaim={handleClaimBooster}
                    pack={openingPack}
                />
            </FunctionWindow>
            <div className={`fixed top-0 left-0 h-full transition-transform duration-300 ease-in-out z-30 w-full max-w-sm md:w-[390px] md:max-w-none ${isOpen ? 'translate-x-0' : '-translate-x-full'} pointer-events-none`}>
                
                 {/* Currency Display - positioned absolutely, outside the main nav */}
                 <div className="absolute top-4 left-4 right-4 z-10 pointer-events-auto">
                    <div className="grid grid-cols-3 gap-2">
                         <CurrencyDisplay 
                            iconUrl="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/essence_currency.png?alt=media&token=8c6bbab2-8f02-4565-bb25-b60e8bd11c71"
                            value={accountSettings.referralEssence || 0}
                            alt="Essence"
                            className="bg-neutral-900/60 backdrop-blur-md"
                            iconClassName="bg-transparent"
                        />
                        <CurrencyDisplay 
                            iconUrl="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2FGenerated%20Image%20September%2006%2C%202025%20-%202_52AM.png?alt=media&token=48212470-1e98-4656-b9e9-00217601b54a"
                            value={accountSettings.soulShards || 0}
                            alt="Soul Shards"
                            className="bg-neutral-900/60 backdrop-blur-md"
                            iconClassName="bg-transparent"
                        />
                        <CurrencyDisplay 
                            iconUrl="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/ticket.png?alt=media&token=0905d04c-7cfc-4830-b91a-47a092ac45c6"
                            value={accountSettings.dailyRewardState?.seasonPoints || 0}
                            alt="Season Tickets"
                            className="bg-neutral-900/60 backdrop-blur-md"
                            iconClassName="bg-transparent"
                        />
                    </div>
                </div>

                 <DropZone onDrop={handleDrop} className="absolute top-20 max-h-[calc(100vh-6rem)] w-full h-[60vh] pointer-events-auto">
                    <nav 
                        className="w-full h-full backdrop-blur-xl border-r border-t border-b border-white/10 shadow-2xl flex flex-col rounded-r-2xl" 
                        style={{ backgroundImage: 'var(--bg-menu-gradient)' }}
                    >
                        <header className="relative p-4 bg-black/20 backdrop-blur-sm flex-shrink-0 space-y-4">
                            <button 
                                onClick={onClose} 
                                className="absolute top-2 right-2 p-2 rounded-full text-neutral-400 hover:bg-white/10 md:hidden z-10"
                                aria-label="Close Collection"
                            >
                                <XMarkIcon className="w-6 h-6" />
                            </button>
                            {/* Tabs */}
                            <div className="flex-shrink-0 -mx-4 px-4 border-b-2 border-cyan-500/30">
                                <nav className="flex items-center">
                                    {(['Collection', 'Boosters'] as const).map(tab => (
                                        <TabButton
                                            key={tab}
                                            label={tab}
                                            isActive={activeTab === tab}
                                            onClick={() => setActiveTab(tab)}
                                        />
                                    ))}
                                </nav>
                            </div>
                            {/* Search (conditional) */}
                            {(activeTab === 'Collection') && (
                            <div className="relative">
                                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500" />
                                <input
                                    type="text"
                                    value={searchTerm}
                                    onChange={e => setSearchTerm(e.target.value)}
                                    placeholder="Search templates..."
                                    className="w-full bg-neutral-800/60 border border-neutral-700 rounded-md py-2 pl-10 pr-4 focus:outline-none focus:ring-1 focus:ring-purple-500"
                                />
                            </div>
                            )}
                        </header>
                        <CollectionPage 
                            accountSettings={accountSettings} 
                            setAccountSettings={setAccountSettings} 
                            onCloseDrawer={onClose} 
                            setToast={setToast} 
                            templates={templates} 
                            onOpenBooster={handleOpenBooster}
                            onOpenDiscoverModal={onOpenDiscoverModal}
                            onViewTemplate={handleViewTemplateDetails}
                            onPinSoul={onPinSoul}
                            onOpenDeletionModal={onOpenDeletionModal}
                            onCancelDeletion={onCancelDeletion}
                            onImmediateDelete={onImmediateDelete}
                            activeTab={activeTab}
                            searchTerm={searchTerm}
                            onInitiateAuction={onInitiateAuction}
                            onFindInMarketplace={onFindInMarketplace}
                            onCreateSoulFromTemplate={onCreateSoulFromTemplate}
                            onUnlockTemplate={onUnlockTemplate}
                            dnd={dnd}
                        />
                    </nav>
                </DropZone>
            </div>
        </>
    );
}