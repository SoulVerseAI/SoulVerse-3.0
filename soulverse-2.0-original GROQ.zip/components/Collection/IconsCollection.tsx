import React from 'react';

// Quality Orbs
export const QualityWispIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2FWisp.png?alt=media&token=6055831e-1beb-4268-8f25-54abe04eb005" alt="Wisp Quality" {...props} />
);

export const QualitySpiritIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2FSpirit.png?alt=media&token=a85242a9-b9fa-42ce-9432-8bb44342cf20" alt="Spirit Quality" {...props} />
);

export const QualityAscendIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2FAscend.png?alt=media&token=863168ee-2ef2-4711-923c-44b4516fa822" alt="Ascend Quality" {...props} />
);

export const QualityEternalIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Feternal.png?alt=media&token=d7b2157c-5a17-4128-b787-132b30a7fd50" alt="Eternal Quality" {...props} />
);


// Role Icons
export const RoleCharacterIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fconversation.png?alt=media&token=2cd83aeb-bd25-4a56-a799-3454880905ce" alt="Character Role" {...props} />
);

export const RoleAssistantIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fonline-learning.png?alt=media&token=df5768d5-1c62-4203-8ba2-5dfa1f1ec412" alt="Assistant Role" {...props} />
);

export const RoleNarratorIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fbook.png?alt=media&token=7ab56ffa-dab7-4d61-99a2-08a5708d6396" alt="Narrator Role" {...props} />
);

export const RoleScenarioIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2Fdices.png?alt=media&token=722103c5-bc2d-4093-8ad9-e8f97f4cbdea" alt="Scenario Role" {...props} />
);

// Currency Icons
export const EssenceIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/essence_currency.png?alt=media&token=8c6bbab2-8f02-4565-bb25-b60e8bd11c71" alt="Essence" {...props} />
);

export const SoulShardsIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2FGenerated%20Image%20September%2006%2C%202025%20-%202_52AM.png?alt=media&token=48212470-1e98-4656-b9e9-00217601b54a" alt="Soul Shards" {...props} />
);

export const BondTokensIcon = (props: React.HTMLProps<HTMLImageElement>) => (
    <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/homemenu%2Fcollection%2FBondToken.png?alt=media&token=4be92209-f37f-47c1-ad5f-3a91599aea6d" alt="Bond Tokens" {...props} />
);