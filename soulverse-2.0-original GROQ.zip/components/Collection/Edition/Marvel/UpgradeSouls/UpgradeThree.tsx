import { SoulTemplate, Gender, SoulRole } from '../../../../../types';
import { wispSRCharacterMarvel } from '../Wisp/WispSRCharacter';
import { wispSRAssistantMarvel } from '../Wisp/WispSRAssistant';
import { wispSRNarratorMarvel } from '../Wisp/WispSRNarrator';

const baseMarvelTemplates = [
  ...wispSRCharacterMarvel,
  ...wispSRAssistantMarvel,
  ...wispSRNarratorMarvel,
];

export const upgradeThreeSRCharacterMarvel: SoulTemplate[] = baseMarvelTemplates.map(template => {
  const newTemplate: SoulTemplate = {
    ...template,
    name: template.name,
    title: `(Eternal) ${template.title}`,
    quality: 'Eternal',
    upgrade: 3,
    soulId: 300000 + (template.soulId || 0),
    shareCode: `U3-${template.shareCode}`,
    edition: 'Marvel',
  };
  return newTemplate;
});
