import { SoulTemplate, Gender, SoulRole } from '../../../../../types';
import { wispSRCharacterMarvel } from '../Wisp/WispSRCharacter';
import { wispSRAssistantMarvel } from '../Wisp/WispSRAssistant';
import { wispSRNarratorMarvel } from '../Wisp/WispSRNarrator';

const baseMarvelTemplates = [
  ...wispSRCharacterMarvel,
  ...wispSRAssistantMarvel,
  ...wispSRNarratorMarvel,
];

export const upgradeOneSRCharacterMarvel: SoulTemplate[] = baseMarvelTemplates.map(template => {
  const newTemplate: SoulTemplate = {
    ...template,
    name: template.name,
    title: `(Spirit) ${template.title}`,
    quality: 'Spirit',
    upgrade: 1,
    soulId: 100000 + (template.soulId || 0),
    shareCode: `U1-${template.shareCode}`,
    edition: 'Marvel',
  };
  return newTemplate;
});
