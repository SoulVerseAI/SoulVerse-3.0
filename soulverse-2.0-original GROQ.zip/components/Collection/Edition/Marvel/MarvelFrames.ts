import { TemplateQuality } from '../../../../types';

export const marvelFrameUrls: Record<TemplateQuality, string> = {
    Wisp: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FMarvel%2FWisp%2Fmarvel_front_wisp%20.png?alt=media&token=b9f15792-7c13-4460-aa5f-bc363862c20a',
    Spirit: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FMarvel%2FSpirit%2Fmarvel_front_spirit.png?alt=media&token=62dbdf2c-e6d9-4eb4-98c9-9996d505c749',
    Ascend: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FMarvel%2FAscend%2Fmarvel_front_ascend.png?alt=media&token=10ad0a47-b0c3-444f-bf8f-4b3f81fafb1c',
    Eternal: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FMarvel%2FEternal%2Fmarvel_front_eternal.png?alt=media&token=44a77135-d8fe-43ea-bd09-d02f9aa354b9',
};

export const getMarvelFrame = (quality: TemplateQuality | undefined): string => {
    if (!quality) return marvelFrameUrls.Wisp;
    return marvelFrameUrls[quality] || marvelFrameUrls.Wisp;
};
