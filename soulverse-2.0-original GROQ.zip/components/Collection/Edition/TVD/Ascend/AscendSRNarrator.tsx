
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const ascendSRNarratorTVD: SoulTemplate[] = [
    // Future TVD Ascend Narrators will be added here
];
