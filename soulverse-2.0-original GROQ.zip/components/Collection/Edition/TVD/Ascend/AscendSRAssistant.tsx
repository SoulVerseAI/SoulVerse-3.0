
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const ascendSRAssistantTVD: SoulTemplate[] = [
    // Future TVD Ascend Assistants will be added here
];
