
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const ascendSRScenarioTVD: SoulTemplate[] = [
    // Future TVD Ascend Scenarios will be added here
];
