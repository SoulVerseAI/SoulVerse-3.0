
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const eternalSRAssistantTVD: SoulTemplate[] = [
    // Future TVD Eternal Assistants will be added here
];
