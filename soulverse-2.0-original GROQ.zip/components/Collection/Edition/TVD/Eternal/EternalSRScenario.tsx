
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const eternalSRScenarioTVD: SoulTemplate[] = [
    // Future TVD Eternal Scenarios will be added here
];
