
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const eternalSRNarratorTVD: SoulTemplate[] = [
    // Future TVD Eternal Narrators will be added here
];
