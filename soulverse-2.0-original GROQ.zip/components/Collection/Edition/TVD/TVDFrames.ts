import { TemplateQuality } from '../../../../types';

export const tvdFrameUrls: Record<TemplateQuality, string> = {
    Wisp: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FTVD%2FWisp%2FWisp_TVD_front%20.png?alt=media&token=b2ebf6dd-6b45-4368-9cfc-610b18429bf8',
    Spirit: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FTVD%2FSpirit%2FSpirit_TVD_front%20.png?alt=media&token=83d93fb7-1fb7-42fc-ad0f-52d7b65295db',
    Ascend: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FTVD%2FAscend%2FAscend_TVD_front%20.png?alt=media&token=450f9351-13f2-4515-8b9d-5ffb42eb9f3b',
    Eternal: 'https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Components%2FCollection%2FEdition%2FTVD%2FEternal%2FEternal_TVD_front%20.png?alt=media&token=b3ae962c-adaf-4304-998c-3597c161b57f',
};

export const getTVDFrame = (quality: TemplateQuality | undefined): string => {
    if (!quality) return tvdFrameUrls.Wisp;
    return tvdFrameUrls[quality] || tvdFrameUrls.Wisp;
};
