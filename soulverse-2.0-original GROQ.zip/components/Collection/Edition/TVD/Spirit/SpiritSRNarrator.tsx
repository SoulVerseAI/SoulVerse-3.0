
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const spiritSRNarratorTVD: SoulTemplate[] = [
    // Future TVD Spirit Narrators will be added here
];
