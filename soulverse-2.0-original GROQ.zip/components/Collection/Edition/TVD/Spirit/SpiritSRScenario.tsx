
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const spiritSRScenarioTVD: SoulTemplate[] = [
    // Future TVD Spirit Scenarios will be added here
];
