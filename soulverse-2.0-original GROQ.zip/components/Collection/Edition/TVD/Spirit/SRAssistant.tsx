
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const spiritSRAssistantTVD: SoulTemplate[] = [
    // Future TVD Spirit Assistants will be added here
];
