
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const wispSRNarratorTVD: SoulTemplate[] = [
    // Future TVD Wisp Narrators will be added here
];
