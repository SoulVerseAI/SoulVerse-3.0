
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const wispSRScenarioTVD: SoulTemplate[] = [
    // Future TVD Wisp Scenarios will be added here
];
