
import { SoulTemplate, Gender, SoulRole } from '../../../../../types';

export const wispSRAssistantTVD: SoulTemplate[] = [
    // Future TVD Wisp Assistants will be added here
];
