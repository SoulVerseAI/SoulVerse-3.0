

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { AccountSettings, Soul, SoulRole, SoulTemplate, TemplateQuality, BoosterPack, GroupedTemplate } from '../../types';
import { SearchIcon, PlusIcon, EllipsisVerticalIcon, TrashIcon, DocumentTextIcon, StarIcon } from '../icons/Icons';
import { ContextMenu } from '../ui/ContextMenu';
import { QualityWispIcon, QualitySpiritIcon, QualityAscendIcon, QualityEternalIcon, RoleCharacterIcon, RoleAssistantIcon, RoleNarratorIcon, RoleScenarioIcon } from './IconsCollection';
import { getSubscriptionBenefits } from '../../services/subscriptionService';
import { getTVDFrame } from './Edition/TVD/TVDFrames';
import { getMarvelFrame } from './Edition/Marvel/MarvelFrames';

interface CollectionPageProps {
    accountSettings: AccountSettings;
    setAccountSettings: (updater: (prev: AccountSettings) => AccountSettings) => void;
    onCloseDrawer: () => void;
    setToast: (toast: { title: string; message: React.ReactNode } | null) => void;
    templates: SoulTemplate[];
    onOpenBooster: (pack: BoosterPack) => void;
    onOpenDiscoverModal: () => void;
    onViewTemplate: (template: SoulTemplate) => void;
    onPinSoul: (soulId: string) => void;
    onOpenDeletionModal: (soulId: string) => void;
    onCancelDeletion: (soulId: string) => void;
    onImmediateDelete: (soulId: string) => void;
    activeTab: 'My Souls' | 'Collection' | 'Boosters';
    searchTerm: string;
    onInitiateAuction: (card: GroupedTemplate) => void;
    onFindInMarketplace: (template: SoulTemplate) => void;
    onCreateSoulFromTemplate: (template: SoulTemplate, instanceId: string) => void;
    onUnlockTemplate: (instanceId: string, name: string) => void;
    dnd: any;
}

type QualityFilter = TemplateQuality;
type RoleFilter = SoulRole;

const getUpgradeLevelFromQuality = (quality: TemplateQuality): number => {
    switch (quality) {
        case 'Spirit': return 1;
        case 'Ascend': return 2;
        case 'Eternal': return 3;
        default: return 0; // Wisp and default
    }
};

// FIX: Export getQualityStyles to be used in App.tsx
export const getQualityStyles = (quality: TemplateQuality) => {
    // FIX: Changed quality strings to match TemplateQuality enum ('Wisp', 'Spirit', 'Ascend', 'Eternal')
    switch (quality) {
        case 'Wisp': return { border: 'border-neutral-400', shadow: 'hover:shadow-neutral-400/30', bg: 'bg-neutral-700', text: 'text-neutral-200', label: 'Wisp', animation: '', gradientFrom: 'from-black/80' };
        case 'Spirit': return { border: 'border-cyan-400', shadow: 'hover:shadow-cyan-400/30', bg: 'bg-cyan-800/80', text: 'text-cyan-200', label: 'Spirit', animation: 'card-effect-spirit', gradientFrom: 'from-cyan-900/80' };
        case 'Ascend': return { border: 'border-purple-400', shadow: 'hover:shadow-purple-400/30', bg: 'bg-purple-800/80', text: 'text-purple-200', label: 'Ascend', animation: 'card-effect-ascend', gradientFrom: 'from-purple-900/80' };
        case 'Eternal': return { border: 'border-yellow-400', shadow: 'hover:shadow-yellow-400/30', bg: 'bg-yellow-800/80', text: 'text-yellow-200', label: 'Eternal', animation: 'card-effect-eternal', gradientFrom: 'from-amber-900/80' };
        default: return { border: 'border-neutral-700', shadow: '', bg: 'bg-neutral-700', text: 'text-neutral-200', label: 'Wisp', animation: '', gradientFrom: 'from-black/80' };
    }
};

// FIX: Add and export StackedCollectionCardPreview for use in App.tsx DragLayer
export const StackedCollectionCardPreview: React.FC<{ template: SoulTemplate, quality: TemplateQuality }> = ({ template, quality }) => {
    const qualityStyles = getQualityStyles(quality);

    const getImageUrl = (tpl: SoulTemplate): string => {
        if (tpl.bgImageUrls && tpl.bgImageUrls.length > 0) {
            const firstImage = tpl.bgImageUrls[0];
            if (typeof firstImage === 'string') {
                return firstImage;
            }
            if (firstImage && typeof firstImage === 'object' && 'url' in firstImage && typeof firstImage.url === 'string') {
                return firstImage.url;
            }
        }
        return tpl.smallAvatarUrl || '';
    };

    const imageUrl = getImageUrl(template);

    return (
        <div className={`w-24 aspect-[3/4] rounded-lg border-2 ${qualityStyles.border} bg-black flex flex-col items-center justify-end relative overflow-hidden p-1 shadow-lg ${qualityStyles.shadow}`}>
            <img src={imageUrl} alt={template.name} className="absolute inset-0 w-full h-full object-cover" />
            <div className={`absolute inset-0 bg-gradient-to-t ${qualityStyles.gradientFrom} to-transparent`}></div>
            <h4 className="relative font-semibold text-white text-xs truncate text-center z-10">{template.name}</h4>
        </div>
    );
};

interface StackedCollectionCardProps {
    groupedTemplate: GroupedTemplate;
    onAddToDock: (template: SoulTemplate, instanceId: string) => void;
    onInitiateAuction: (groupedTemplate: GroupedTemplate) => void;
    onFindInMarketplace: (template: SoulTemplate) => void;
    onViewTemplate: (template: SoulTemplate) => void;
    onUnlockTemplate: (instanceId: string, name: string) => void;
}

const StackedCollectionCard: React.FC<StackedCollectionCardProps> = ({ groupedTemplate, onAddToDock, onInitiateAuction, onViewTemplate, onFindInMarketplace, onUnlockTemplate }) => {
    const { template, instances } = groupedTemplate;
    const copies = instances.length;
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const triggerRef = useRef<HTMLButtonElement>(null);
    const CASCADING_OFFSET_PX = 30; // Tighter stack for full cards
    const [isBeingDragged, setIsBeingDragged] = useState(false);
    const cardRef = useRef<HTMLDivElement>(null);
    
    // This effect handles resetting the visual state *after* the parent component
    // has processed the drop and updated the `copies` prop.


    const hasTradableInstance = instances.some(inst => inst.tradable !== false);

    const qualityOrder: TemplateQuality[] = ['Eternal', 'Ascend', 'Spirit', 'Wisp'];
    const sortedInstances = [...instances].sort((a, b) => {
        const aIsTradable = a.tradable !== false;
        const bIsTradable = b.tradable !== false;
        if (aIsTradable && !bIsTradable) return -1;
        if (!aIsTradable && bIsTradable) return 1;
        return qualityOrder.indexOf(a.quality) - qualityOrder.indexOf(b.quality);
    });

    const topCardInstance = sortedInstances[0];

    const menuItems = [
        { label: 'Detail', icon: <DocumentTextIcon className="w-5 h-5" />, action: () => onViewTemplate(template) },
        { label: 'Add to Dock', icon: <PlusIcon className="w-5 h-5" />, action: () => onAddToDock(template, topCardInstance.instanceId) },
    ];

    if (hasTradableInstance) {
        menuItems.push(
            { label: 'Find in Marketplace', icon: <SearchIcon className="w-5 h-5" />, action: () => onFindInMarketplace(template) },
            { label: 'Sell Soul', icon: <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fdiamond%20(1).png?alt=media&token=e8d63963-5192-4b63-ad9e-42b627d45a02" className="w-5 h-5" />, action: () => onInitiateAuction(groupedTemplate) }
        );
    }
    
    const topCardQuality = topCardInstance.quality;
    const topCardStyles = getQualityStyles(topCardQuality);
    const isTVD = template.edition === 'TVD';
    const isMarvel = template.edition === 'Marvel';
    const isFramed = isTVD || isMarvel;
    const frameUrl = isFramed ? (isTVD ? getTVDFrame(topCardQuality) : getMarvelFrame(topCardQuality)) : null;
    const isCollectible = template.edition === 'Marvel' || template.edition === 'TVD';
    const isTradable = topCardInstance.tradable !== false;
    
    const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
        const dragData = {
            instanceId: topCardInstance.instanceId,
            template: template,
        };
        e.dataTransfer.setData("application/json", JSON.stringify(dragData));
        e.dataTransfer.effectAllowed = "move";

        if (cardRef.current) {
            const clone = cardRef.current.cloneNode(true) as HTMLElement;
            clone.style.position = "absolute";
            clone.style.top = "-9999px";
            clone.style.width = cardRef.current.offsetWidth + 'px';
            clone.style.height = cardRef.current.offsetHeight + 'px';
            document.body.appendChild(clone);
            e.dataTransfer.setDragImage(clone, cardRef.current.offsetWidth / 2, cardRef.current.offsetHeight / 2);
            setTimeout(() => {
                if (clone.parentNode) {
                    clone.parentNode.removeChild(clone);
                }
            }, 0);
        }
        
        setTimeout(() => setIsBeingDragged(true), 0);
    };

    const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
        setIsBeingDragged(false);
    };
    
    const getImageUrl = (tpl: SoulTemplate): string => {
        if (tpl.bgImageUrls && tpl.bgImageUrls.length > 0) {
            const firstImage = tpl.bgImageUrls[0];
            if (typeof firstImage === 'string') {
                return firstImage;
            }
            if (firstImage && typeof firstImage === 'object' && 'url' in firstImage && typeof firstImage.url === 'string') {
                return firstImage.url;
            }
        }
        return tpl.smallAvatarUrl || '';
    };

    const imageUrl = getImageUrl(template);
    
    return (
        <div 
            draggable={copies > 0} 
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            className="relative w-full aspect-[3/4] group cursor-grab active:cursor-grabbing"
        >
            <ContextMenu isOpen={isMenuOpen} items={menuItems} onClose={() => setIsMenuOpen(false)} triggerRef={triggerRef} />
            
            {copies > 1 && (
                <div
                    className="absolute w-full h-full rounded-xl"
                    style={{
                        transform: `translate(0, -${CASCADING_OFFSET_PX}px)`, 
                        zIndex: 2,
                    }}
                >
                    {isFramed && frameUrl ? (
                        <>
                            <img src={imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover rounded-xl" />
                            <img src={frameUrl} alt="" className="absolute inset-0 w-full h-full z-[1]" />
                        </>
                    ) : (
                        <div
                            className={`w-full h-full card-dark-glass rounded-xl border-2 bg-cover bg-center ${topCardStyles.border}`}
                            style={{ backgroundImage: `url(${imageUrl})` }}
                        />
                    )}
                    <div className="absolute top-2 left-2 bg-black/70 text-white text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full shadow-lg z-10">
                        {copies - 1}
                    </div>
                </div>
            )}
            
            <div 
                ref={cardRef}
                className={`relative w-full h-full rounded-xl transition-opacity duration-200 ${!isFramed ? `card-dark-glass border-2 bg-cover bg-center ${topCardStyles.border} ${topCardStyles.shadow} ${topCardStyles.animation}` : ''}`}
                style={{
                    ...(!isFramed && { backgroundImage: `url(${imageUrl})` }),
                    zIndex: 3,
                    opacity: isBeingDragged ? 0.3 : 1,
                }}
            >
                {isFramed && frameUrl && (
                    <>
                        <img src={imageUrl} alt={template.name} className="absolute inset-0 w-full h-full object-cover rounded-xl" />
                        <img src={frameUrl} alt="" className="absolute inset-0 w-full h-full z-[1]" />
                    </>
                )}
                {isCollectible && isTradable && (
                    <div className="absolute top-2 left-2 z-[4] group-hover:opacity-100 opacity-75 transition-opacity">
                        <button onClick={(e) => { e.stopPropagation(); onUnlockTemplate(topCardInstance.instanceId, template.name); }} title="Unlock for editing (removes tradable status)">
                            <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/padlock.png?alt=media&token=d02915b4-cde4-4d20-a742-b61ab372a28f" alt="Locked" className="w-6 h-6 drop-shadow-lg" />
                        </button>
                    </div>
                )}
                <div className="absolute top-1 right-1 z-[4] opacity-0 group-hover:opacity-100 transition-opacity">
                    <button ref={triggerRef} onClick={(e) => { e.stopPropagation(); setIsMenuOpen(p => !p); }} className="p-1.5 rounded-full bg-black/40 hover:bg-black/60 transition-colors">
                        <EllipsisVerticalIcon className="w-5 h-5" />
                    </button>
                </div>
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-3 text-white z-[2]">
                    {hasTradableInstance && !isFramed && (
                        <div className="absolute top-2 left-2">
                           <img src="https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/padlock.png?alt=media&token=d02915b4-cde4-4d20-a742-b61ab372a28f" alt="Locked" className="w-5 h-5 drop-shadow-lg" />
                        </div>
                    )}

                    {template.label && !isFramed && (
                        <p className={`text-xs font-semibold uppercase tracking-wider -mb-1 ${template.label === 'Villain' ? 'text-red-400' : 'text-cyan-400'}`}>
                            {template.label}
                        </p>
                    )}
                    <h3 className="font-bold truncate">{template.name}</h3>
                </div>
            </div>

            {isBeingDragged && (
                 <div className="absolute inset-0 w-full h-full bg-black/60 border-2 border-dashed border-neutral-600 rounded-xl" style={{ zIndex: 3 }}></div>
            )}
        </div>
    );
};

const BoosterCard: React.FC<{ booster: BoosterPack; onOpen: () => void }> = ({ booster, onOpen }) => (
    <div className="w-full aspect-[4/5] relative group">
        <button onClick={onOpen} className="w-full h-full">
            <img src={booster.imageUrl} alt={booster.name} className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300 drop-shadow-lg"/>
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                <span className="font-bold text-white text-xl bg-black/50 px-4 py-2 rounded-md">Open Pack</span>
            </div>
        </button>
    </div>
);


export const CollectionPage: React.FC<CollectionPageProps> = ({ 
    accountSettings, 
    setAccountSettings, 
    onCloseDrawer, 
    setToast, 
    templates, 
    onOpenBooster,
    onOpenDiscoverModal,
    onViewTemplate,
    onPinSoul,
    onOpenDeletionModal,
    onCancelDeletion,
    onImmediateDelete,
    activeTab,
    searchTerm,
    onInitiateAuction,
    onFindInMarketplace,
    onCreateSoulFromTemplate,
    onUnlockTemplate,
}) => {
    const CARD_CONTAINER_HEIGHT_PX = 210;
    // FIX: Changed quality strings to match TemplateQuality enum ('Wisp', 'Spirit', 'Ascend', 'Eternal')
    const [qualityFilters, setQualityFilters] = useState<QualityFilter[]>(['Wisp', 'Spirit', 'Ascend', 'Eternal']);
    const [roleFilters, setRoleFilters] = useState<RoleFilter[]>([]);

    const collectedSouls = useMemo(() => {
        const grouped = new Map<string, GroupedTemplate>();

        (accountSettings.ownedTemplates || []).forEach(owned => {
            const template = templates.find(t => t.name === owned.name);
            if (template) {
                const isCollectible = template.edition === 'Marvel' || template.edition === 'TVD';
                const isTradable = isCollectible && owned.tradable !== false;
                
                const groupKey = `${owned.name}_${isTradable}`;
                
                if (!grouped.has(groupKey)) {
                    grouped.set(groupKey, { template, instances: [] });
                }
                grouped.get(groupKey)!.instances.push({ quality: owned.quality, instanceId: owned.instanceId, tradable: owned.tradable });
            }
        });
        
        return Array.from(grouped.values());
    }, [accountSettings.ownedTemplates, templates]);
    
    const filteredAndSortedSouls = useMemo(() => {
        return collectedSouls
            .map(item => {
                const { template, instances } = item;

                const filteredInstances = instances.filter(instance => 
                    qualityFilters.length === 4 ? true : qualityFilters.includes(instance.quality)
                );

                if (filteredInstances.length === 0) {
                    return null;
                }

                const roleMatch = roleFilters.length === 0 || (template.role && roleFilters.includes(template.role));
                const searchMatch = !searchTerm || template.name.toLowerCase().includes(searchTerm.toLowerCase());
                
                if (searchMatch && roleMatch) {
                    return { ...item, instances: filteredInstances };
                }
                return null;
            })
            .filter((item): item is GroupedTemplate => item !== null)
            .sort((a, b) => {
                if (a.template.name < b.template.name) return -1;
                if (a.template.name > b.template.name) return 1;
                // Secondary sort: tradable (locked) items first
                const aIsTradable = a.instances[0]?.tradable !== false;
                const bIsTradable = b.instances[0]?.tradable !== false;
                if (aIsTradable && !bIsTradable) return -1;
                if (!aIsTradable && bIsTradable) return 1;
                return 0;
            });
    }, [collectedSouls, searchTerm, qualityFilters, roleFilters]);
    
    const handleRoleFilterChange = (role: RoleFilter) => {
        setRoleFilters(prev => 
            prev.includes(role) ? prev.filter(r => r !== role) : [...prev, role]
        );
    };
    
    const handleQualityFilterChange = (quality: QualityFilter) => {
        setQualityFilters(prev => 
            prev.includes(quality)
                ? prev.filter(q => q !== quality)
                : [...prev, quality]
        );
    };

    // FIX: Changed quality strings to match TemplateQuality enum ('Wisp', 'Spirit', 'Ascend', 'Eternal')
    const qualityIcons: { quality: QualityFilter, Icon: React.FC<any> }[] = [
        { quality: 'Wisp', Icon: QualityWispIcon },
        { quality: 'Spirit', Icon: QualitySpiritIcon },
        { quality: 'Ascend', Icon: QualityAscendIcon },
        { quality: 'Eternal', Icon: QualityEternalIcon },
    ];
    
    const roleIcons: { role: RoleFilter, Icon: React.FC<any> }[] = [
        { role: SoulRole.CHARACTER, Icon: RoleCharacterIcon },
        { role: SoulRole.ASSISTANT, Icon: RoleAssistantIcon },
        { role: SoulRole.NARRATOR, Icon: RoleNarratorIcon },
        { role: SoulRole.SCENARIO, Icon: RoleScenarioIcon },
    ];
    
    const sidebarVisible = ['Collection'].includes(activeTab);
    const minSlots = 12;

    return (
        <div className="h-full flex flex-col font-inter overflow-hidden">
            <div className="flex-1 flex min-h-0">
                {/* Filters Sidebar */}
                <aside className={`w-16 flex-shrink-0 bg-black/20 p-2 flex flex-col items-center space-y-4 overflow-y-auto transition-all duration-300 ${sidebarVisible ? 'opacity-100' : 'opacity-0 -translate-x-full w-0 p-0'}`}>
                    <div className="space-y-2">
                        {qualityIcons.map(({ quality, Icon }) => (
                            <button
                                key={quality}
                                onClick={() => handleQualityFilterChange(quality)}
                                className={`w-10 h-10 flex items-center justify-center rounded-full transition-all duration-200 ${qualityFilters.includes(quality) ? '' : 'opacity-60 hover:opacity-100'}`}
                                title={quality.charAt(0).toUpperCase() + quality.slice(1)}
                            >
                                <Icon className="w-8 h-8"/>
                            </button>
                        ))}
                    </div>
                    <div className="w-full border-t border-neutral-700/60 !my-4"></div>
                    <div className="space-y-2">
                        {roleIcons.map(({ role, Icon }) => (
                            <button
                                key={role}
                                onClick={() => handleRoleFilterChange(role)}
                                className={`w-10 h-10 p-2 flex items-center justify-center rounded-lg transition-all duration-200 ${roleFilters.includes(role) ? 'bg-purple-500/30 text-white' : 'bg-neutral-800/50 text-neutral-400 hover:bg-neutral-700/70 hover:text-white'}`}
                                title={role}
                            >
                                <Icon className="w-full h-full" />
                            </button>
                        ))}
                    </div>
                </aside>
                
                <main className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                        {activeTab === 'Collection' && (
                            <div className="grid grid-cols-2 gap-4">
                                {filteredAndSortedSouls.map(item => (
                                    <div 
                                        key={`${item.template.name}_${item.instances[0]?.tradable !== false}`} // More stable key
                                        className="w-full p-2 bg-black/20 border border-neutral-800 rounded-2xl flex flex-col justify-end"
                                        style={{ height: `${CARD_CONTAINER_HEIGHT_PX}px` }}
                                    >
                                        <StackedCollectionCard 
                                            groupedTemplate={item} 
                                            onViewTemplate={onViewTemplate} 
                                            onAddToDock={onCreateSoulFromTemplate} 
                                            onInitiateAuction={onInitiateAuction} 
                                            onFindInMarketplace={onFindInMarketplace}
                                            onUnlockTemplate={onUnlockTemplate}
                                        />
                                    </div>
                                ))}
                                {Array.from({ length: Math.max(0, minSlots - filteredAndSortedSouls.length) }).map((_, i) => (
                                    <div 
                                        key={`empty-${i}`} 
                                        className="w-full p-2 bg-black/20 border border-neutral-800 rounded-2xl"
                                        style={{ height: `${CARD_CONTAINER_HEIGHT_PX}px` }}
                                    />
                                ))}
                            </div>
                        )}
                        {activeTab === 'Boosters' && (
                            <div className="grid grid-cols-2 gap-4">
                                {(accountSettings.boosterPacks || []).map(pack => (
                                    <div key={pack.id} className="w-full aspect-[3/4]">
                                        <BoosterCard booster={pack} onOpen={() => onOpenBooster(pack)} />
                                    </div>
                                ))}
                                {(accountSettings.boosterPacks || []).length === 0 && (
                                    <div className="col-span-full text-center py-16 text-neutral-500">
                                        <p>No booster packs.</p>
                                        <p className="text-sm">You can buy them in the Vault of Essence.</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </main>
            </div>
        </div>
    );
};
