import React from 'react';
import {jsx as _jsx, jsxs as _jsxs} from "react/jsx-runtime";
export const UserCircleIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z"
    })
}));
export const UsersIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-4.664v.015a6.375 6.375 0 01-1.352 4.496zM10.5 8.25a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zM10.5 8.25V6"
    })
}));
export const BookOpenIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25"
    })
}));
export const CogIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: [_jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.26.716.53.966l.898.898c.444.444.625 1.08.482 1.664l-.398 1.592a2.103 2.103 0 01-1.08.918l-1.28.427a1.945 1.945 0 00-1.542.946l-.8 1.603a2.103 2.103 0 01-1.83.946h-2.12a2.103 2.103 0 01-1.83-.946l-.8-1.603a1.945 1.945 0 00-1.542-.946l-1.28-.427a2.103 2.103 0 01-1.08-.918l-.398-1.592a2.103 2.103 0 01.482-1.664l.898-.898a1.945 1.945 0 00.53-.966l.213-1.281z"
    }), _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
    })]
}));
export const ShareIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 103.935 2.186 2.25 2.25 0 00-3.935-2.186zm0-12.814a2.25 2.25 0 103.933-2.186 2.25 2.25 0 00-3.933 2.186z"
    })
}));
export const CreditCardIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3.375m-3.375 0h10.5a2.25 2.25 0 002.25-2.25v-3.75a2.25 2.25 0 00-2.25-2.25h-10.5a2.25 2.25 0 00-2.25 2.25v3.75a2.25 2.25 0 002.25 2.25z"
    })
}));
export const SparklesIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 22.5l-.648-1.938a3.375 3.375 0 00-2.672-2.672L11.25 18l1.938-.648a3.375 3.375 0 002.672-2.672L16.25 13.5l.648 1.938a3.375 3.375 0 002.672 2.672L21 18l-1.938.648a3.375 3.375 0 00-2.672 2.672z"
    })
}));
export const BrainIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fbrainstorm.png?alt=media&token=c0777ee2-e62b-4deb-a39c-3f207c410c43", alt: "Recall Messages", ...props }));
export const PlusIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fplus.png?alt=media&token=80942a7d-ae42-4817-89d2-a40dd39a3f8c", alt: "Add", ...props }));
export const WandSparklesIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fmagic-tool.png?alt=media&token=e64e73c3-a23b-43db-99a8-3da63be2f07a", alt: "Magic Suggestion", ...props }));
export const MicrophoneIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: [_jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 013-3 3 3 0 013 3v8.25a3 3 0 01-3 3z"
    })]
}));
export const PlayCircleIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: [_jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
    }), _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15.91 11.672a.375.375 0 010 .656l-5.603 3.113a.375.375 0 01-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112z"
    })]
}));
export const HeartIcon = ({ filled = false, ...props }: {filled?: boolean} & React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    fill: filled ? 'currentColor' : 'none',
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"
    })
}));
export const UserIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
    })
}));
export const ArrowLeftIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
    })
}));
export const RegenerateIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Freload.png?alt=media&token=3856745c-26c6-4f85-9ceb-18347441bfee", alt: "Regenerate", ...props }));
export const ArrowLeftIconV2 = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fleft-arrow.png?alt=media&token=ba4c64d1-cf0c-463b-a39c-e040fd68f4f3", alt: "Hide Avatar", ...props }));
export const ArrowRightIconV2 = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Farrow-right.png?alt=media&token=19ebb279-c87c-4ea8-8909-d70d99deae0d", alt: "Show Avatar", ...props }));
export const PencilIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fpencil.png?alt=media&token=f4bf38c4-e0ba-4537-b563-35745e21323d", alt: "Edit", ...props }));
export const SendIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5"
    })
}));
export const ChevronLeftIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15.75 19.5L8.25 12l7.5-7.5"
    })
}));
export const PhotoIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fpictures.png?alt=media&token=e4bebbe6-cb26-4927-b143-c9caad070315", alt: "Upload Image", ...props }));
export const GlobeAltIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fearth-grid.png?alt=media&token=8c8a12f3-8162-4791-9046-1a92346db9d2", alt: "Internet Connection", ...props }));
export const LinkIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Flink.png?alt=media&token=9749098b-8bb2-4c0c-a9f3-b1fe0714e3d1", alt: "Link", ...props }));
export const XMarkIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M6 18L18 6M6 6l12 12"
    })
}));
export const RssIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12.75 19.5v-.75a7.5 7.5 0 00-7.5-7.5H4.5m0-6.75h.75c7.87 0 14.25 6.38 14.25 14.25v.75M6 18.75a3 3 0 01-3-3v-1.5a3 3 0 013-3h1.5a3 3 0 013 3v1.5a3 3 0 01-3 3H6z"
    })
}));
export const ContinueMessageIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fchevron.png?alt=media&token=2ff15e19-23c9-4c1d-b611-2d0a34f19a3c", alt: "Continue Message", ...props }));
export const LoadingSpinner = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    className: "animate-spin -ml-1 mr-3 h-5 w-5 text-white",
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    ...props,
    children: _jsx("circle", {
        className: "opacity-25",
        cx: "12",
        cy: "12",
        r: "10",
        stroke: "currentColor",
        strokeWidth: "4"
    })
}));
export const ArrowDownIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3"
    })
}));
export const ExclamationTriangleIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
    })
}));
export const ScissorsIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M7.848 8.25l1.536.887M7.848 8.25a3 3 0 11-5.196-3 3 3 0 015.196 3zM12 12.75H3M16.152 8.25l-1.536.887M16.152 8.25a3 3 0 10-5.196-3 3 3 0 005.196 3zM12 12.75h9M12 12.75a3 3 0 110 6 3 3 0 010-6z"
    })
}));
export const SoulProfileIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z"
    })
}));
export const ChevronDownIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M19.5 8.25l-7.5 7.5-7.5-7.5"
    })
}));
export const Bars3Icon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
    })
}));
export const CameraIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: [_jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z"
    }), _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z"
    })]
}));
export const PhoneIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Ftelephone.png?alt=media&token=5983c602-c22f-4102-ab53-b75a0207ed89", alt: "Voice Call", ...props }));
export const GiftIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12.75 15l3-3m0 0l-3-3m3 3h-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
    })
}));
export const DiscordIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2FDS.png?alt=media&token=aeba31d0-702c-4c14-860e-05b21dd2f9f4", alt: "Discord", ...props }));
export const RedditIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    className: "w-6 h-6",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...props,
    children: _jsx("path", {
        d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-12h2v2h-2v-2zm0 4h2v6h-2v-6zm4.24-5.24c-.39-.39-1.02-.39-1.41 0l-1.83 1.83c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l1.83-1.83c.39-.39.39-1.02 0-1.41zm-6.07 0c-.39-.39-1.02-.39-1.41 0l-1.83 1.83c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l1.83-1.83c.39-.39.39-1.02 0-1.41z"
    })
}));
export const DiamondIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("img", { src: "https://firebasestorage.googleapis.com/v0/b/soulverse-storage.firebasestorage.app/o/Soulverse%20icon%20topbar%2Fsubscribe-diamond.png?alt=media&token=685d55d7-c5bc-4dca-a116-b658bd2da389", alt: "Subscription", ...props }));
export const DatabaseIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M4.5 12.75l6 6 9-13.5"
    })
}));
export const BellIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"
    })
}));
export const UserIconSolid = UserIcon;
export const GridIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 8.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 018.25 20.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6A2.25 2.25 0 0115.75 3.75h2.25A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25A2.25 2.25 0 0113.5 8.25V6zM13.5 15.75A2.25 2.25 0 0115.75 13.5h2.25a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z"
    })
}));
export const ChatBubbleBottomCenterTextIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.76 9.76 0 01-2.53-0.417m-4.754-4.212a9.753 9.753 0 01-4.496-4.496C3.375 12.103 3 10.875 3 9.75c0-4.556 4.03-8.25 9-8.25 4.97 0 9 3.694 9 8.25z"
    })
}));
export const EllipsisVerticalIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12 6.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 12.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 18.75a.75.75 0 110-1.5.75.75 0 010 1.5z"
    })
}));
export const BookmarkIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.5 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z"
    })
}));
export const ChevronRightIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M8.25 4.5l7.5 7.5-7.5 7.5"
    })
}));
export const CheckIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M4.5 12.75l6 6 9-13.5"
    })
}));
export const ClipboardIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a8.25 8.25 0 01-8.25 8.25h-2.25a2.25 2.25 0 01-2.25-2.25v-6.75a2.25 2.25 0 012.25-2.25H6.75a2.25 2.25 0 012.25 2.25v6.75a2.25 2.25 0 002.25 2.25H13.5"
    })
}));
export const TrashIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
    })
}));
export const DocumentTextIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"
    })
}));
export const PinIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M4.5 4.5l15 15m0 0V8.25m0 11.25H8.25"
    })
}));
export const InformationCircleIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"
    })
}));
export const SpeakerWaveIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z"
    })
}));
export const PauseIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M15.75 5.25v13.5m-6-13.5v13.5"
    })
}));
export const EnvelopeIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.91"
    })
}));
export const ArrowDownTrayIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3"
    })
}));
export const SearchIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", className: "w-6 h-6", ...props, children: _jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" }) }));
export const MoonIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", className: "w-6 h-6", ...props, children: _jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" }) }));
export const SunIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", className: "w-6 h-6", ...props, children: _jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" }) }));
export const GoogleIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", { className: "w-6 h-6", viewBox: "0 0 48 48", ...props, children: [_jsx("path", { fill: "#FFC107", d: "M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z" }), _jsx("path", { fill: "#FF3D00", d: "M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z" }), _jsx("path", { fill: "#4CAF50", d: "M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0124 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20z" }), _jsx("path", { fill: "#1976D2", d: "M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8-1.42 0-2.774-.22-4.053-.61l-6.522 5.025C15.96 43.182 19.82 44 24 44c11.045 0 20-8.955 20-20 0-1.341-.138-2.65-.389-3.917z" })] }));
export const TiktokIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", className: "w-6 h-6", viewBox: "0 0 24 24", fill: "currentColor", ...props, children: _jsx("path", { d: "M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-2.43.03-4.83-1-6.7-2.9-1.31-1.31-2.12-3.04-2.22-4.81-.02-.78-.01-1.56.04-2.33.08-1.34.46-2.65 1.14-3.88.91-1.61 2.32-2.9 4.07-3.66.57-.26 1.16-.45 1.73-.66.01-2.87-.01-5.74.02-8.61.02-1.05.3-2.13.88-3.01.76-1.14 1.96-1.94 3.32-2.11.17-.02.34-.03.51-.05z" }) }));
export const InstagramIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", className: "w-6 h-6", viewBox: "0 0 24 24", fill: "currentColor", ...props, children: _jsx("path", { d: "M7.337 2.813c-1.18-.04-2.373-.004-3.543.004C2.61.295 1.61.75 1.017 1.343c-.594.594-1.05 1.594-1.026 2.777C-.02 5.3 0 6.48 0 7.34c0 1.29.013 2.58.025 3.868.016 1.15.42 2.223 1.3 3.104.88.88 1.956 1.284 3.105 1.3.18.004.362.007.542.007.94 0 1.88-.002 2.818-.002 1.28.002 2.56.002 3.842 0 .8-.003 1.597-.007 2.396-.025 1.2-.027 2.316-.45 3.17-1.31.855-.853 1.283-1.97 1.31-3.17.024-.798.028-1.597.028-2.395 0-1.28-.002-2.562-.002-3.842 0-.94.002-1.88.002-2.818 0-.18-.003-.362-.007-.542-.025-1.19-.445-2.31-1.31-3.17-.864-.863-1.98-1.283-3.17-1.31-.798-.02-1.597-.024-2.395-.024-1.28 0-2.56 0-3.84 0zm6.286 1.423c.89-.01 1.78-.003 2.67.003.88.006 1.636.27 2.227.86.59.59.854 1.348.86 2.228.005.89.003 1.78.003 2.67 0 .88-.002 1.77-.003 2.66-.006.88-.27 1.636-.86 2.227-.59.59-.854 1.348-.86-2.228-.005-.89-.003-1.78-.003-2.67 0-.88.002-1.77.003-2.66.006-.88.27-1.636.86-2.227.59-.59 1.348-.854 2.228-.86.89-.005 1.78-.003 2.67-.003zm0 1.46c-2.08 0-3.766 1.687-3.766 3.765 0 2.08 1.687 3.766 3.766 3.766 2.08 0 3.766-1.687 3.766-3.766 0-2.078-1.686-3.765-3.766-3.765zm0 1.35c1.334 0 2.416 1.082 2.416 2.416 0 1.334-1.082 2.416-2.416 2.416s-2.416-1.082-2.416-2.416c0-1.334 1.082-2.416 2.416-2.416z" }) }));
export const XIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", className: "w-6 h-6", viewBox: "0 0 24 24", fill: "currentColor", ...props, children: _jsx("path", { d: "M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z" }) }));
export const GooglePlayIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", { viewBox: "0 0 512 512", fill: "currentColor", ...props, children: _jsx("path", { d: "M99.617 8.057a50.191 50.191 0 00-38.815-6.713l230.932 230.933 74.846-74.846L99.617 8.057zM32.139 20.116c-6.441 8.563-10.148 19.077-10.148 30.199v411.358c0 11.123 3.708 21.636 10.148 30.199l235.877-235.877L32.139 20.116zM421.196 272.602l-57.51 57.51L230.932 197.355 43.056 8.384A50.191 50.191 0 0048.192 1.579l372.992 271.023zM479.861 228.648l-69.643 69.644-235.877-235.877 69.644-69.644a50.19 50.19 0 00-3.235-5.222L102.358 8.057 479.861 228.648z" }) }));
export const AppleAppStoreIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", { viewBox: "0 0 512 512", fill: "currentColor", ...props, children: [_jsx("path", { d: "M417.4 256c0-62.3-39.1-118.4-95.2-140.9C281.3 90.5 243.6 112 243.6 112s-34.9-20-73.4-18.4c-47.3 2-83.3 42.8-83.3 89.2 0 42.3 33.2 81.7 82.5 81.7 24.3 0 45.3-13.2 59.1-23.2 13.8 10 34.8 23.2 59.1 23.2 49.3 0 82.5-39.4 82.5-81.7z" }), _jsx("path", { d: "M133.5 124.3c23-2.3 45.9-4.8 68.8-5.1 22.8-.3 45.9 2.5 68.8 4.8C359.1 127.3 350 106.8 333 93.3c-17-13.5-39.7-22.3-64.2-24.1-12.2-.8-24.4-.3-36.6-.3-12.2 0-24.4-.5-36.6.3-24.5 1.8-47.2 10.5-64.2 24.1-17 13.5-26.1 34-17.7 51z" })] }));
export const EyeIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", className: "w-6 h-6", ...props, children: [
        _jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" }),
        _jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z" })
    ]
}));

export const QuestionIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z"
    })
}));

export const MinusIcon = (props: React.HTMLProps<HTMLImageElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M19.5 12h-15"
    })
}));

// FIX: Add missing icons
export const HangUpIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    style: { transform: 'rotate(135deg)', ...props.style },
    children: _jsx("path", {
        fillRule: "evenodd",
        d: "M1.5 4.5a3 3 0 013-3h1.372c.86 0 1.61.586 1.819 1.42l1.105 4.423a1.875 1.875 0 01-.694 1.955l-1.293.97c-.135.101-.164.298-.083.465a7.48 7.48 0 003.429 3.429c.167.081.364.052.465-.083l.97-1.293a1.875 1.875 0 011.955-.694l4.423 1.105c.834.209 1.42.959 1.42 1.82V19.5a3 3 0 01-3 3h-2.25C8.552 22.5 1.5 15.448 1.5 6.75V4.5z",
        clipRule: "evenodd"
    })
}));

export const PreviousTrackIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        d: "M6 6h2v12H6zm3.5 6l8.5 6V6z"
    })
}));

export const NextTrackIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        d: "M16 6h2v12h-2zm-4.5 6l-8.5 6V6z"
    })
}));

export const USFlagIcon = (props: React.HTMLProps<SVGSVGElement>) => (
    _jsx("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 5 3", ...props, children: _jsxs("g", { children: [_jsx("rect", { width: "5", height: "3", fill: "#B22234" }), _jsx("rect", { width: "2.5", height: "1.5", fill: "#3C3B6E" })] }) })
);

export const ClockIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 1.5,
    stroke: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
    })
}));

export const VerifiedIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        fillRule: "evenodd",
        d: "M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12c0 1.357-.6 2.573-1.549 3.397a4.49 4.49 0 01-1.307 3.498 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.491 4.491 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z",
        clipRule: "evenodd"
    })
}));

export const StarIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        fillRule: "evenodd",
        d: "M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.007z",
        clipRule: "evenodd"
    })
}));

export const PuzzlePieceIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", {
        fillRule: "evenodd",
        d: "M11.484 2.172a.75.75 0 011.032 0l2.033 2.033a.75.75 0 001.032-.027l1.833-1.833a.75.75 0 011.23.53v3.423a.75.75 0 00.343.62c1.37.893 2.17 2.44 2.17 4.088v.002a5.25 5.25 0 01-5.25 5.25h-2.121a.75.75 0 00-.75.75v3.121a.75.75 0 01-1.357.424l-2.033-2.033a.75.75 0 00-1.032.027l-1.833 1.833a.75.75 0 01-1.23-.53V15.75a.75.75 0 00-.343-.62c-1.37-.893-2.17-2.44-2.17-4.088v-.002a5.25 5.25 0 015.25-5.25h2.121a.75.75 0 00.75-.75V3.121a.75.75 0 011.357-.424l2.033-2.033a.75.75 0 001.032.027l1.833-1.833z",
        clipRule: "evenodd"
    })
}));

export const TriangleUpIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", { d: "M7 14l5-5 5 5H7z" })
}));

export const TriangleDownIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    className: "w-6 h-6",
    ...props,
    children: _jsx("path", { d: "M7 10l5 5 5-5H7z" })
}));

export const LockedPadlockIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...props,
    children: _jsx("path", {
        fillRule: "evenodd",
        d: "M12 1.5a5.25 5.25 0 00-5.25 5.25v3a3 3 0 00-3 3v6.75a3 3 0 003 3h10.5a3 3 0 003-3v-6.75a3 3 0 00-3-3v-3A5.25 5.25 0 0012 1.5zM8.25 6.75v3h7.5v-3a3.75 3.75 0 00-7.5 0z",
        clipRule: "evenodd"
    })
}));

export const UnlockedPadlockIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    ...props,
    children: _jsx("path", {
        d: "M18 1.5c2.9 0 5.25 2.35 5.25 5.25v3.75a.75.75 0 01-1.5 0V6.75a3.75 3.75 0 10-7.5 0v3a3 3 0 01-3 3v6.75a3 3 0 01-3 3H3.75a3 3 0 01-3-3v-6.75a3 3 0 013-3h9V6.75A5.25 5.25 0 0118 1.5z"
    })
}));

export const ResizerArrowsIcon = (props: React.HTMLProps<SVGSVGElement>) => (_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    strokeWidth: 2,
    stroke: "currentColor",
    ...props,
    children: _jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9"
    })
}));
