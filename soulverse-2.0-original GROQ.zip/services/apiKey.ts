// This file holds the API key for the application.
// In a production environment, this should be handled via environment variables
// or a secure key management service.
export const API_KEY = "AIzaSyBmwDy60mBZRCvFvsFcj3l1X_mJPLBKbmI";
